@echo off
setlocal EnableExtensions
cd /d "%~dp0"

:menu
cls
echo ============================================================
echo                 OT Pocket Android v0.2
echo ============================================================
echo.
echo [1] Doctor / environment check
echo [2] Build debug APK
echo [3] Install APK with ADB
echo [4] Open APK output folder
echo [5] View Android logs
echo [0] Exit
echo.
set /p choice=Choose: 
if "%choice%"=="1" goto doctor
if "%choice%"=="2" goto build
if "%choice%"=="3" goto install
if "%choice%"=="4" goto output
if "%choice%"=="5" goto logs
if "%choice%"=="0" exit /b 0
goto menu

:doctor
echo.
where java
java -version
where gradle
where adb
pause
goto menu

:build
echo.
gradle --no-daemon :app:assembleDebug
pause
goto menu

:install
echo.
adb install -r "app\build\outputs\apk\debug\app-debug.apk"
pause
goto menu

:output
if not exist "app\build\outputs\apk\debug" mkdir "app\build\outputs\apk\debug"
start "" "app\build\outputs\apk\debug"
goto menu

:logs
adb logcat -s OTPocket:V chromium:V AndroidRuntime:E
pause
goto menu
