# Pocket OT v0.4.8 storage migration

## What changed

- Android app state now saves through native SQLite instead of WebView localStorage.
- Photo bytes are saved as individual private app files; state contains only lightweight photo references.
- Existing v0.4.7 Base64 activity photos and Remember-item photos migrate automatically on first launch after a compatible in-place update.
- The v0.4.7 localStorage copy is not removed until every legacy photo is archived and the native state commit succeeds.
- The 12-photo Remember-item cap and 5,000 routine-update truncation were removed.
- Photo grids use lazy image decoding; the Capture history renders 120 thumbnails at a time while keeping all records.
- Settings reports archive photo count, archive size, and free device space.
- Native backup export is a streaming ZIP containing manifest.json, state.json, and photos/.
- Old v0.4.7 JSON backups can be imported; embedded photos are migrated into the native archive during restore.

## Upgrade safety

The recovered v0.4.7 APK certificate fingerprint is:

SHA-256: c1edd76b7d7c5a4fa75a894527763c2986e9c7de156c79e8301504842120104d

The corresponding private debug signing key was not present in the recovered project/library artifacts. Android requires the same signing key for a direct update that preserves app-private data.

If a future v0.4.8 APK is signed with that same key, install it directly and the automatic migration handles the old data.

If Android reports UPDATE_INCOMPATIBLE / a signing mismatch, do NOT uninstall v0.4.7 first. Open v0.4.7 and use Export backup while the data is still present. Then install the newly signed v0.4.8 and use Settings > Import old JSON backup. The importer archives the embedded legacy photos and commits the restored state to native storage.

## Build

The project still targets Android SDK 35 / Java 17 and uses Android Gradle Plugin 8.9.2. Build with a machine that has the Android SDK and Gradle configured:

    gradle --no-daemon :app:assembleDebug

This execution environment does not contain the Android SDK/Gradle toolchain, so this package contains the verified source changes rather than a newly built APK.


## v0.4.8.1 file-picker fix

- Fixes Android WebView file chooser incorrectly forcing `image/*` for every file input.
- Backup restore now uses the normal Android document picker and shows all file types.
- Legacy `.json` backups are validated after selection instead of being hidden by unreliable MIME metadata.
- Camera/gallery behavior remains unchanged for photo inputs.


## v0.4.8.2 backup compatibility fix

- Removes the incorrect requirement that every legacy JSON backup already contain both `timeline` and `photos` arrays.
- Accepts raw Pocket OT state, common wrapper objects, and double-encoded JSON.
- Strips UTF-8 BOM before parsing.
- Normalizes collections added by later Pocket OT versions to empty arrays instead of rejecting older exports.
- Prevents missing legacy flags from turning a restored personal profile into demo data.
- Restore errors now display the real rejection reason while preserving the current profile.
