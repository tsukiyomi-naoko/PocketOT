# OT Pocket Android v0.4.8

Installable offline Android development build for patients and occupational therapists.

## v0.4 additions

- First-launch language prompt
- Phone/app language detection with English fallback
- English and French Canadian interface
- App, notification, and report language controls
- French Canadian Android notification actions and channel labels
- Android 13+ per-app language declaration
- Language-neutral stored statuses; changing language does not replace records
- Real profile onboarding and temporary **Skip to demo** path
- Adaptive launcher icon and status/gesture-navigation inset handling

The current APK remains a development build and must not be used as the sole clinical record.

## Build

Requires JDK 17, Android SDK 35, Build Tools 35.0.0, and Gradle 8.11.1.

```bash
gradle :app:assembleDebug
```

## v0.4.3 launcher icon

Uses the approved OT Human Loop launcher artwork with adaptive, round, monochrome, and legacy-density assets.


## v0.4.5 report history and preview

- On-screen weekly report library with current and past-week navigation
- Full report preview before Print / PDF export
- Week-specific CSV export
- Historical report generation from timestamped activities, photos, and notes
- Archived demo-week summaries remain selectable even when item-level demo records are unavailable

## v0.4.5 preparation, counters, and PDF fixes

- Countable routines now use dedicated **− / count / +** controls instead of cycling through generic statuses
- Water is available as an 8-per-day starter counter; Coffee keeps its configurable counter
- Every increment creates a timestamped report entry, while decrement removes the latest same-day count entry
- **Prepare next week** items can be viewed or edited by tapping or holding the item
- Preparation items support custom name, icon, note, status, creation, and deletion
- Android **Print / PDF** now opens the native system print dialog through `PrintManager`, including the **Save as PDF** destination


## v0.4.5 additions
- Full seven-day report timeline grouped by the configured 6 a.m.–3 a.m. tracking day.
- Exact tracker update timestamps for routines and counters.
- Dedicated Remind items page with location notes, compact icon tiles, expandable latest-photo cards, and local photo history.
- Working Today / Yesterday / Tomorrow filtering on the daily timeline.


## v0.4.6 approved launcher icon

- Replaces the previous launcher artwork with the approved circular OT Habit icon.
- Uses the supplied approved 256 px launcher asset as the adaptive foreground and the supplied monochrome themed icon, stored as pixel-identical lossless WebP resources.
- Keeps the approved warm-white background and existing standard/round launcher references.

## v0.4.7
- Remembered-item editor now accepts an optional camera or gallery picture before the item is saved.
- Selected picture is previewed and can be removed or replaced before saving.
- Existing item photo history remains available.


## v0.4.8 native archive storage

- Replaces WebView `localStorage` as the primary Android persistence layer with a native SQLite-backed state store.
- Moves activity and Remember-item photo bytes out of JSON and into individual private app files.
- Migrates v0.4.7 Base64 photos automatically on first launch after an in-place update.
- Keeps the old WebView state untouched until the native migration commits successfully.
- Removes the 12-photo Remember-item retention cap and the 5,000 routine-update truncation.
- Lazily decodes archived images and batches the Capture photo list to avoid rendering years of thumbnails at once.
- Adds photo archive size/free-space status in Settings.
- Adds old JSON-backup import for migration/recovery.
- Native **Export backup** now produces a streaming ZIP containing `state.json`, a manifest, and the complete private photo archive.

Designed for sustained high-volume capture (including tens of photos per day); practical retention is now governed by actual device free space rather than WebView local-storage quota.
