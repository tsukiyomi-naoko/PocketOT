(() => {
  'use strict';

  const STORAGE_KEY = 'ot-pocket-state-v0.1';
  const APP_VERSION = '0.4.8';
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const now = new Date();
  const nativeBridge = window.OTPocketNative || null;
  const isNativeApp = (() => { try { return !!nativeBridge?.isNative?.(); } catch { return false; } })();


  const SUPPORTED_LANGUAGES = ['en', 'fr-CA'];
  const PHONE_LANGUAGE = (() => {
    let nativeLanguage = '';
    try { nativeLanguage = nativeBridge?.getPreferredLanguage?.() || ''; } catch { nativeLanguage = ''; }
    const browserLanguages = Array.isArray(navigator.languages) && navigator.languages.length ? navigator.languages : [navigator.language || 'en'];
    const candidates = nativeLanguage ? [nativeLanguage, ...browserLanguages] : browserLanguages;
    for (const raw of candidates) {
      const tag = String(raw || '').toLowerCase();
      if (tag.startsWith('fr')) return 'fr-CA';
      if (tag.startsWith('en')) return 'en';
    }
    return 'en';
  })();
  let uiLanguage = PHONE_LANGUAGE;
  const FR_CA = {
  "Passive routine companion": "Compagnon passif des routines",
  "Patient view": "Vue patient",
  "Patient view · Demo": "Vue patient · Démo",
  "Occupational therapist view": "Vue de l’ergothérapeute",
  "Occupational therapist view · Demo": "Vue de l’ergothérapeute · Démo",
  "Switch view": "Changer de vue",
  "Switch between patient and OT view": "Basculer entre la vue patient et la vue ergo",
  "Open occupational therapist view": "Ouvrir la vue de l’ergothérapeute",
  "Open patient view": "Ouvrir la vue patient",
  "Settings": "Paramètres",
  "Preferences": "Préférences",
  "Profile, languages, reminders, notifications, and local data.": "Profil, langues, rappels, notifications et données locales.",
  "Profile & planner": "Profil et planificateur",
  "Identity and schedule used throughout the app.": "Identité et horaire utilisés dans toute l’application.",
  "Languages": "Langues",
  "Choose app, report, and notification languages independently.": "Choisissez séparément la langue de l’application, des rapports et des notifications.",
  "Routine prompts": "Rappels de routine",
  "Control how often Pocket OT asks for missing information.": "Contrôlez à quelle fréquence Pocket OT demande les informations manquantes.",
  "Ask what is happening throughout the active day.": "Demander ce qui se passe pendant la période active.",
  "Quiet hours": "Heures silencieuses",
  "Keep prompts outside the selected rest period.": "Éviter les rappels pendant la période de repos sélectionnée.",
  "App & data": "Application et données",
  "Permissions, exports, testing controls, and profile reset.": "Autorisations, exportations, contrôles de test et réinitialisation du profil.",
  "Open settings": "Ouvrir les paramètres",
  "Primary navigation": "Navigation principale",
  "Today": "Aujourd’hui",
  "Timeline": "Chronologie",
  "Record": "Saisir",
  "Week": "Semaine",
  "Reports": "Rapports",
  "Report library": "Bibliothèque de rapports",
  "Browse current and past weeks, then open a complete report before exporting.": "Parcourez la semaine actuelle et les semaines précédentes, puis ouvrez un rapport complet avant de l’exporter.",
  "Preview report": "Aperçu du rapport",
  "Full report preview": "Aperçu complet du rapport",
  "Back to reports": "Retour aux rapports",
  "Previous week": "Semaine précédente",
  "Next week": "Semaine suivante",
  "This week": "Cette semaine",
  "Past week": "Semaine précédente",
  "Past weeks": "Semaines précédentes",
  "Select any week to review its saved activity records and report summary.": "Sélectionnez une semaine pour consulter ses activités enregistrées et son résumé.",
  "Recorded activities": "Activités enregistrées",
  "Confirmed records": "Données confirmées",
  "Photo context": "Contexte des photos",
  "Notes recorded": "Notes enregistrées",
  "Activity summary": "Résumé des activités",
  "Detailed activity records": "Données détaillées des activités",
  "No detailed activity records are available for this week.": "Aucune donnée détaillée d’activité n’est disponible pour cette semaine.",
  "An archived summary is available, but this older demonstration week does not contain item-by-item records.": "Un résumé archivé est disponible, mais cette ancienne semaine de démonstration ne contient pas de données détaillées.",
  "No activity was recorded during this week.": "Aucune activité n’a été enregistrée pendant cette semaine.",
  "No photo evidence was captured during this week.": "Aucune photo n’a été prise pendant cette semaine.",
  "No notes were recorded during this week.": "Aucune note n’a été enregistrée pendant cette semaine.",
  "Report period": "Période du rapport",
  "Generated": "Généré",
  "Archived weekly completion": "Achèvement hebdomadaire archivé",
  "Context complete": "Contexte complété",
  "Open week": "Ouvrir la semaine",
  "records": "données",
  "photos": "photos",
  "No records": "Aucune donnée",
  "Current supply status": "État actuel des fournitures",
  "Supply status is shown only for the current week because earlier supply states were not historically snapshotted.": "L’état des fournitures est affiché seulement pour la semaine actuelle, car les états précédents n’étaient pas archivés.",
  "Report preview is based on timestamped local records. Review it before using it as a clinical document.": "L’aperçu du rapport repose sur les données locales horodatées. Révisez-le avant de l’utiliser comme document clinique.",
  "Welcome": "Bienvenue",
  "Set up your profile": "Configurer votre profil",
  "Create a clean personal profile. Demonstration patients and sample records will not be mixed into it.": "Créez un profil personnel propre. Les patients de démonstration et les données d’exemple n’y seront pas mélangés.",
  "Previous demo detected": "Ancienne démo détectée",
  "Creating your profile replaces the old sample data. Export anything you need before continuing.": "La création du profil remplacera les anciennes données d’exemple. Exportez ce que vous souhaitez conserver avant de continuer.",
  "Language": "Langue",
  "App language": "Langue de l’application",
  "Use phone language": "Utiliser la langue du téléphone",
  "English": "English",
  "Français (Canada)": "Français (Canada)",
  "Full name or patient label": "Nom complet ou identifiant du patient",
  "Example: Alex R.": "Exemple : Alex R.",
  "Preferred first name": "Prénom préféré",
  "optional": "facultatif",
  "Shown in greetings": "Affiché dans les salutations",
  "How will this profile be used?": "Comment ce profil sera-t-il utilisé?",
  "Personal use": "Usage personnel",
  "Track routines and create my own reports.": "Suivre mes routines et créer mes propres rapports.",
  "Working with an OT": "Avec un ergothérapeute",
  "Include therapist and clinical-review context.": "Inclure l’ergothérapeute et le contexte de révision clinique.",
  "Occupational therapist": "Ergothérapeute",
  "Name or healthcare center": "Nom ou centre de santé",
  "Continue": "Continuer",
  "Skip to demo": "Passer à la démo",
  "The demo is temporary test data and should not be used as a clinical record.": "La démo contient des données de test temporaires et ne doit pas servir de dossier clinique.",
  "Profile setup": "Configuration du profil",
  "Planner & prompts": "Planificateur et rappels",
  "Fit the day to the patient": "Adapter la journée au patient",
  "The original planner defaults to 6:00 a.m.–3:00 a.m. the following day.": "Le planificateur original va par défaut de 6 h à 3 h le lendemain.",
  "Day begins": "Début de la journée",
  "Day ends": "Fin de la journée",
  "next day": "lendemain",
  "Routine reminders": "Rappels de routine",
  "Ask at the right time without requiring the app to stay open.": "Poser la question au bon moment sans que l’application reste ouverte.",
  "Ask about missing periods": "Demander pour les périodes manquantes",
  "Only prompt when a useful timeline gap remains.": "Demander seulement lorsqu’une période importante demeure vide.",
  "Remind me to describe photos": "Me rappeler de décrire les photos",
  "Capture now, add context when hands are clean.": "Capturer maintenant et ajouter le contexte lorsque les mains sont propres.",
  "Persistent quick-capture notification": "Notification permanente de saisie rapide",
  "Keep Photo, Text, Done, and Later one tap away.": "Garder Photo, Texte, Fait et Plus tard à un toucher.",
  "Back": "Retour",
  "Starter routines": "Routines de départ",
  "Choose what to track": "Choisir quoi suivre",
  "These are only starting items. Every routine can be changed or removed afterward.": "Ce ne sont que des éléments de départ. Chaque routine pourra ensuite être modifiée ou supprimée.",
  "Medication reminder": "Rappel de médicament",
  "Add one medication now; more can be added later.": "Ajouter un médicament maintenant; d’autres pourront être ajoutés plus tard.",
  "Brush teeth — morning": "Brossage des dents — matin",
  "Daily personal-care check.": "Suivi quotidien des soins personnels.",
  "Brush teeth — evening": "Brossage des dents — soir",
  "Separate evening completion.": "Suivi séparé pour le soir.",
  "Shower": "Douche",
  "Flexible personal-care item.": "Élément flexible de soins personnels.",
  "Eating": "Repas",
  "Breakfast, lunch, and supper.": "Déjeuner, dîner et souper.",
  "Coffee": "Café",
  "Drinking water": "Eau potable",
  "Daily water counter with minus and plus controls.": "Compteur quotidien d’eau avec boutons moins et plus.",
  "Optional count rather than simple done/not done.": "Compteur facultatif plutôt qu’un simple fait/non fait.",
  "Daily target": "Objectif quotidien",
  "Count": "Compteur",
  "Tap and hold an item to view or edit it.": "Touchez longuement un élément pour le consulter ou le modifier.",
  "Add preparation item": "Ajouter un élément de préparation",
  "Edit preparation item": "Modifier l’élément de préparation",
  "Item name": "Nom de l’élément",
  "Note": "Note",
  "Delete item": "Supprimer l’élément",
  "Open Android print / Save as PDF": "Ouvrir l’impression Android / Enregistrer en PDF",
  "Opening Android print and Save as PDF…": "Ouverture de l’impression Android et de l’option Enregistrer en PDF…",
  "Surface cleaning": "Nettoyage des surfaces",
  "Kitchen, bathroom, or work surface.": "Cuisine, salle de bain ou surface de travail.",
  "Litterbox": "Litière",
  "Recurring household/pet-care task.": "Tâche récurrente d’entretien ou de soins à l’animal.",
  "Prepare next week": "Préparer la semaine prochaine",
  "Check water, food, groceries, medication, and supplies.": "Vérifier l’eau, la nourriture, l’épicerie, les médicaments et les fournitures.",
  "First medication": "Premier médicament",
  "Medication label": "Nom du médicament",
  "Use the patient’s preferred label": "Utiliser le nom préféré du patient",
  "Dose": "Dose",
  "Example: 1 tablet": "Exemple : 1 comprimé",
  "Reminder time": "Heure du rappel",
  "Create profile": "Créer le profil",
  "Enter a medication label or turn off the medication starter item.": "Entrez un nom de médicament ou désactivez cet élément de départ.",
  "Your profile is ready": "Votre profil est prêt",
  "Add a routine or record an activity whenever you are ready.": "Ajoutez une routine ou saisissez une activité lorsque vous êtes prêt.",
  "Add first item": "Ajouter un premier élément",
  "Done": "Fait",
  "Photo": "Photo",
  "Text": "Texte",
  "Later": "Plus tard",
  "Next": "À venir",
  "Today’s routines": "Routines d’aujourd’hui",
  "completed": "terminé",
  "partial": "partiel",
  "remaining": "restant",
  "Add routine": "Ajouter une routine",
  "No routines yet": "Aucune routine pour le moment",
  "Use Add routine to create the first item for this profile.": "Utilisez Ajouter une routine pour créer le premier élément de ce profil.",
  "Context inbox": "Boîte de contexte",
  "photos need context": "photos nécessitent un contexte",
  "Review now": "Réviser maintenant",
  "Daily timeline": "Chronologie quotidienne",
  "Confirmed": "Confirmé",
  "Suggested": "Suggéré",
  "Calendar": "Calendrier",
  "No timeline entries yet": "Aucune entrée dans la chronologie",
  "Record an activity, complete a routine, or add a photo to begin.": "Saisissez une activité, terminez une routine ou ajoutez une photo pour commencer.",
  "Quick record": "Saisie rapide",
  "Capture what is happening now. The time is saved automatically.": "Saisissez ce qui se passe maintenant. L’heure est enregistrée automatiquement.",
  "Take photo": "Prendre une photo",
  "Choose photos": "Choisir des photos",
  "Quick text": "Texte rapide",
  "Voice note": "Note vocale",
  "Voice": "Voix",
  "Voice context": "Contexte vocal",
  "Speak naturally; review the text before saving.": "Parlez naturellement; révisez le texte avant de l’enregistrer.",
  "Voice recognition is not available on this device.": "La reconnaissance vocale n’est pas disponible sur cet appareil.",
  "Transcription": "Transcription",
  "Your spoken note will appear here.": "Votre note dictée apparaîtra ici.",
  "Start listening": "Commencer l’écoute",
  "Stop listening": "Arrêter l’écoute",
  "Cancel listening": "Annuler l’écoute",
  "Save note": "Enregistrer la note",
  "Requesting microphone permission…": "Demande d’autorisation du microphone…",
  "Starting voice recognition…": "Démarrage de la reconnaissance vocale…",
  "Listening…": "Écoute en cours…",
  "Processing speech…": "Traitement de la parole…",
  "Switching to the phone speech service…": "Passage au service vocal du téléphone…",
  "Voice recognition cancelled.": "Reconnaissance vocale annulée.",
  "Voice recognition complete.": "Reconnaissance vocale terminée.",
  "Voice recognition could not start. You can type instead.": "La reconnaissance vocale n’a pas pu démarrer. Vous pouvez utiliser le texte.",
  "Add a voice or text note first.": "Ajoutez d’abord une note vocale ou du texte.",
  "Voice context saved.": "Contexte vocal enregistré.",
  "🎙 Start listening": "🎙 Commencer l’écoute",
  "■ Stop listening": "■ Arrêter l’écoute",
  "Install the Android APK to enable hourly background check-ins.": "Installez l’APK Android pour activer les rappels horaires en arrière-plan.",
  "Activity saved from the notification.": "Activité enregistrée à partir de la notification.",
  "Reminder completed": "Rappel terminé",
  "Quick completion": "Saisie rapide",
  "Recorded from Android notification action": "Enregistré à partir d’une action de notification Android",
  "Entered with Android notification quick reply": "Saisi avec la réponse rapide d’une notification Android",
  "Start timed activity": "Démarrer une activité chronométrée",
  "Weekly planner": "Planificateur hebdomadaire",
  "Prepare for next week": "Préparer la semaine prochaine",
  "Check supplies": "Vérifier les fournitures",
  "Weekly report": "Rapport hebdomadaire",
  "Monthly report": "Rapport mensuel",
  "Print / PDF": "Imprimer / PDF",
  "Export CSV": "Exporter en CSV",
  "Context not provided — see picture / add context": "Contexte non fourni — voir la photo / ajouter du contexte",
  "Profile": "Profil",
  "Identity and planner settings used throughout reports and greetings.": "Identité et paramètres du planificateur utilisés dans les rapports et les salutations.",
  "Full name / patient label": "Nom complet / identifiant du patient",
  "Preferred name": "Prénom préféré",
  "Profile use": "Utilisation du profil",
  "Occupational therapist / center": "Ergothérapeute / centre",
  "Save profile": "Enregistrer le profil",
  "Profile updated.": "Profil mis à jour.",
  "Start a new profile? Export a backup first if you need the current local data.": "Créer un nouveau profil? Exportez d’abord une sauvegarde si vous devez conserver les données locales actuelles.",
  "Patient-facing controls remain simple; advanced configuration can be managed by the OT.": "Les commandes destinées au patient restent simples; la configuration avancée peut être gérée par l’ergothérapeute.",
  "Demonstration profile": "Profil de démonstration",
  "Personal profile": "Profil personnel",
  "Edit": "Modifier",
  "Reminders": "Rappels",
  "Scheduled routine prompts": "Rappels de routines planifiés",
  "Targeted prompts only when useful": "Questions ciblées seulement lorsque nécessaire",
  "Photo context reminder": "Rappel de contexte des photos",
  "Hourly activity check-ins": "Rappels horaires d’activité",
  "Ask what I am doing throughout the active day.": "Demander ce que je fais pendant la période active.",
  "Check-in frequency": "Fréquence des rappels",
  "Every 30 minutes": "Toutes les 30 minutes",
  "Every hour": "Toutes les heures",
  "Every 2 hours": "Toutes les 2 heures",
  "Active check-in window": "Période active des rappels",
  "Check-ins start": "Début des rappels",
  "Check-ins end": "Fin des rappels",
  "Skip when an activity was recorded recently": "Ignorer lorsqu’une activité a été consignée récemment",
  "Avoid asking again after a recent photo, text, voice, or completion.": "Éviter de redemander après une photo, un texte, une note vocale ou une activité récente.",
  "Recent-entry window": "Période considérée comme récente",
  "Test hourly check-in now": "Tester le rappel horaire maintenant",
  "Hourly check-ins enabled.": "Rappels horaires activés.",
  "Hourly check-ins disabled.": "Rappels horaires désactivés.",
  "Hourly check-in settings updated.": "Paramètres des rappels horaires mis à jour.",
  "An hourly check-in notification was shown.": "Une notification de rappel horaire a été affichée.",
  "Uses exact alarms when Android allows them; otherwise delivery may be slightly delayed.": "Utilise des alarmes exactes lorsque Android les autorise; sinon la notification peut être légèrement retardée.",
  "Review unlabeled photos later": "Réviser plus tard les photos sans description",
  "Quiet hours start": "Début des heures silencieuses",
  "Quiet hours end": "Fin des heures silencieuses",
  "Enable notifications": "Activer les notifications",
  "Export backup": "Exporter une sauvegarde",
  "Show quick notification": "Afficher la notification rapide",
  "Refresh quick notification": "Actualiser la notification rapide",
  "Hide quick notification": "Masquer la notification rapide",
  "Test reminder in 1 minute": "Tester un rappel dans 1 minute",
  "Exact alarms ready": "Alarmes exactes prêtes",
  "Allow exact alarms": "Autoriser les alarmes exactes",
  "Install app": "Installer l’application",
  "Start a new profile": "Créer un nouveau profil",
  "Load demonstration profile": "Charger le profil de démonstration",
  "Android foundation active": "Fondation Android active",
  "Web mode": "Mode Web",
  "Offline app files, private local storage, native voice recognition, hourly check-ins, camera capture, actionable notifications, alarm restoration after reboot, and Android Downloads export are enabled. Passive activity recognition and clinic synchronization remain later production layers.": "Les fichiers hors ligne, le stockage local privé, la caméra, les notifications interactives, la restauration des alarmes après redémarrage et l’exportation vers Téléchargements sont actifs. La reconnaissance passive d’activité et la synchronisation clinique viendront plus tard.",
  "Install the Android APK for native reminders, camera shortcuts, reboot recovery, and offline operation without a PC.": "Installez l’APK Android pour les rappels natifs, les raccourcis caméra, la reprise après redémarrage et l’utilisation hors ligne sans ordinateur.",
  "Follow app language": "Suivre la langue de l’application",
  "Report language": "Langue des rapports",
  "Notification language": "Langue des notifications",
  "System / phone": "Système / téléphone",
  "Language changed.": "Langue modifiée.",
  "Quick Photo / Text / Done / Later notification enabled.": "Notification rapide Photo / Texte / Fait / Plus tard activée.",
  "Quick Photo / Text / Voice notification enabled.": "Notification rapide Photo / Texte / Voix activée.",
  "Quick notification hidden.": "Notification rapide masquée.",
  "A native reminder is scheduled in one minute.": "Un rappel natif est prévu dans une minute.",
  "Exact alarms are already allowed.": "Les alarmes exactes sont déjà autorisées.",
  "Android notification permission requested.": "Autorisation des notifications Android demandée.",
  "Notifications are not supported in this browser.": "Les notifications ne sont pas prises en charge dans ce navigateur.",
  "Use your browser menu and choose “Install app” or “Add to Home screen.”": "Utilisez le menu du navigateur et choisissez « Installer l’application » ou « Ajouter à l’écran d’accueil ».",
  "Replace the current local profile with the Alex demonstration data? Export a backup first if needed.": "Remplacer le profil local actuel par les données de démonstration d’Alex? Exportez d’abord une sauvegarde au besoin.",
  "Demonstration profile loaded.": "Profil de démonstration chargé.",
  "Activity": "Activité",
  "Household task": "Tâche domestique",
  "Personal care": "Soins personnels",
  "Medication": "Médicament",
  "Work / school": "Travail / école",
  "Appointment": "Rendez-vous",
  "Transportation": "Transport",
  "Physical activity": "Activité physique",
  "Rest": "Repos",
  "Social": "Social",
  "Leisure": "Loisir",
  "Other": "Autre",
  "What were you doing?": "Que faisiez-vous?",
  "The current time is saved automatically.": "L’heure actuelle est enregistrée automatiquement.",
  "Save": "Enregistrer",
  "Cancel": "Annuler",
  "Close": "Fermer",
  "Add context": "Ajouter du contexte",
  "Context": "Contexte",
  "Notes": "Notes",
  "Morning": "Matin",
  "Evening": "Soir",
  "Flexible": "Flexible",
  "As needed": "Au besoin",
  "Midday": "Midi",
  "End of week": "Fin de semaine",
  "Breakfast": "Déjeuner",
  "Lunch": "Dîner",
  "Supper": "Souper",
  "Meal check-in": "Suivi du repas",
  "Morning routine": "Routine du matin",
  "Evening routine": "Routine du soir",
  "No fixed time": "Aucune heure fixe",
  "Once today": "Une fois aujourd’hui",
  "Add medication details": "Ajouter les détails du médicament",
  "Dose not entered": "Dose non saisie",
  "0 of 2 recorded": "0 sur 2 enregistré",
  "With breakfast": "Avec le déjeuner",
  "Morning medication": "Médicament du matin",
  "Evening medication": "Médicament du soir",
  "Vitamin D": "Vitamine D",
  "1 tablet": "1 comprimé",
  "1 dose": "1 dose",
  "Food / groceries": "Nourriture / épicerie",
  "Drinking water": "Eau potable",
  "Pet food": "Nourriture pour animaux",
  "Litter": "Litière",
  "Cleaning products": "Produits nettoyants",
  "Personal-care items": "Articles de soins personnels",
  "Enough": "Suffisant",
  "Low": "Bas",
  "Check": "À vérifier",
  "Unsure": "Incertain",
  "See pictures / add context": "Voir les photos / ajouter du contexte",
  "Context missing": "Contexte manquant",
  "Awaiting confirmation": "En attente de confirmation",
  "Possible transportation": "Transport possible",
  "Calendar match": "Correspondance au calendrier",
  "Quick completion": "Achèvement rapide",
  "Recorded from Android notification action": "Enregistré depuis une action de notification Android",
  "No entry was made recently. Add a photo, text, or mark it done.": "Aucune entrée récente. Ajoutez une photo, du texte ou marquez l’activité comme faite.",
  "What are you doing?": "Que faites-vous?",
  "Photo, text, or record completion without searching for the app.": "Photo, texte ou confirmation sans devoir chercher l’application.",
  "Recorded actions": "Actions enregistrées",
  "Routine reminders and quick actions for Pocket OT routines.": "Rappels et actions rapides pour les routines d’Pocket OT.",
  "Storage is full. Export a backup or remove large photos.": "Le stockage est plein. Exportez une sauvegarde ou supprimez de grandes photos.",
  "Profile created for": "Profil créé pour",
  "recorded from the notification.": "enregistré depuis la notification.",
  "Not assigned": "Non assigné",
  "Not scheduled": "Non planifié",
  "Thursday": "Jeudi",
  "Friday": "Vendredi",
  "Monday": "Lundi",
  "Tuesday": "Mardi",
  "Wednesday": "Mercredi",
  "Saturday": "Samedi",
  "Sunday": "Dimanche"
};
  Object.assign(FR_CA, {
    'Defaults to the phone language. English is used when the phone language is not supported.': 'La langue du téléphone est utilisée par défaut. L’anglais sert de solution de repli si elle n’est pas prise en charge.',
    'Date': 'Date', 'Start': 'Début', 'End': 'Fin', 'Category': 'Catégorie', 'Source': 'Source', 'Confidence': 'Confiance', 'Photo count': 'Nombre de photos',
    'English is used when the phone language is not supported.': 'L’anglais est utilisé lorsque la langue du téléphone n’est pas prise en charge.',
    'Follow app language': 'Suivre la langue de l’application'
  });
  Object.assign(FR_CA, {
    'Hello, Alex': 'Bonjour, Alex',
    'Your day is already partly organized. Confirm only what needs attention.': 'Votre journée est déjà partiellement organisée. Confirmez seulement ce qui demande votre attention.',
    'Review': 'Réviser', 'today completed': 'terminé aujourd’hui', 'routines done': 'routines terminées', 'suggestions to confirm': 'suggestions à confirmer',
    'More options': 'Plus d’options', 'Add item': 'Ajouter un élément', 'Brush teeth': 'Brossage des dents',
    'Before 10:00 AM': 'Avant 10 h', 'Meal recorded': 'Repas enregistré', '1 of 2 recorded': '1 sur 2 enregistré', 'Kitchen or bathroom': 'Cuisine ou salle de bain',
    'Demo profile loaded. Sample records are clearly marked as demonstration data.': 'Profil de démonstration chargé. Les données d’exemple sont clairement identifiées comme telles.',
    '6:00 AM–3:00 AM': '6 h–3 h', 'Confirmed activities, suggestions, photos, and gaps remain visibly different.': 'Les activités confirmées, les suggestions, les photos et les périodes vides demeurent clairement distinctes.',
    'Add activity': 'Ajouter une activité', 'Yesterday': 'Hier', 'Tomorrow': 'Demain', 'confirmed': 'confirmé', 'calendar': 'calendrier', 'confirm': 'confirmer',
    'CAPTURE FIRST': 'CAPTURER D’ABORD', 'Record what happened': 'Saisir ce qui s’est passé', 'Save the time immediately. Details can be added later when your hands are free.': 'Enregistrez l’heure immédiatement. Les détails pourront être ajoutés plus tard lorsque vos mains seront libres.',
    'Take a photo': 'Prendre une photo', 'Camera opens immediately': 'La caméra s’ouvre immédiatement', 'A sentence or a few words': 'Une phrase ou quelques mots',
    'Voice context': 'Contexte vocal', 'Dictate instead of typing': 'Dicter plutôt que taper', 'Start an activity': 'Démarrer une activité', 'Track duration from now': 'Mesurer la durée à partir de maintenant',
    'waiting': 'en attente', 'No activity photos yet': 'Aucune photo d’activité pour le moment', 'Photos will be timestamped and placed here for optional context.': 'Les photos seront horodatées et placées ici afin d’ajouter un contexte facultatif.',
    'WEEKLY PLANNER': 'PLANIFICATEUR HEBDOMADAIRE', 'This week': 'Cette semaine', 'The familiar 6:00 AM–3:00 AM structure, summarized for quick review.': 'La structure familière de 6 h à 3 h, résumée pour une révision rapide.',
    'Day': 'Jour', 'Completion': 'Achèvement', 'Photos': 'Photos', 'Needs review': 'À réviser', 'Habit overview': 'Aperçu des habitudes', 'Configure': 'Configurer', 'Target': 'Cible', 'pending': 'en attente', 'done': 'fait',
    'WEEKLY REPORT': 'RAPPORT HEBDOMADAIRE', 'Review and report': 'Réviser et produire le rapport', 'Unconfirmed information remains clearly labelled and is never turned into a clinical fact.': 'Les informations non confirmées demeurent clairement identifiées et ne deviennent jamais automatiquement un fait clinique.',
    'Week at a glance': 'La semaine en un coup d’œil', 'routine completion': 'achèvement des routines', 'timeline confirmed': 'chronologie confirmée', 'photos missing context': 'photos sans contexte',
    'Report readiness': 'État de préparation du rapport', 'All captured photos have context.': 'Toutes les photos capturées ont un contexte.', 'Daily living activities': 'Activités de la vie quotidienne',
    'Not confirmed': 'Non confirmé', 'Completed': 'Terminé', 'Partial': 'Partiel', 'Review supply': 'Vérifier la réserve', 'Add to grocery list': 'Ajouter à la liste d’épicerie',
    'Open preparation checklist': 'Ouvrir la liste de préparation', 'Activity evidence': 'Preuves d’activité', 'No photo evidence was captured this week.': 'Aucune preuve photographique n’a été capturée cette semaine.',
    'Automatically prepared summary': 'Résumé préparé automatiquement', 'Clinician review required': 'Révision clinique requise',
    'CARE TEAM WORKSPACE': 'ESPACE DE L’ÉQUIPE DE SOINS', 'Patient review': 'Révision des patients', 'Prioritize missing information, changes, and report readiness—not raw sensor noise.': 'Prioriser les informations manquantes, les changements et l’état des rapports, plutôt que les données brutes des capteurs.',
    'Generate report': 'Générer le rapport', 'Patients': 'Patients', 'complete': 'terminé', 'missing': 'manquant', 'attention': 'attention',
    'SELECTED PATIENT': 'PATIENT SÉLECTIONNÉ', 'weekly completion': 'achèvement hebdomadaire', 'missing entries': 'entrées manquantes', 'attention items': 'éléments à surveiller', 'confirmed data': 'données confirmées',
    'patient confirmation required': 'confirmation du patient requise', 'Weekly trend': 'Tendance hebdomadaire', 'Clinical report preview': 'Aperçu du rapport clinique', 'Open full report': 'Ouvrir le rapport complet', 'Source transparency': 'Transparence des sources',
    'Week of Jul 20': 'Semaine du 20 juill.', 'Week of Jul 27': 'Semaine du 27 juill.', 'Week of Aug 3': 'Semaine du 3 août', 'context complete': 'contexte complété',
    'Assigned to Morgan, OT': 'Assigné à Morgan, erg.', 'Review due Today': 'Révision prévue aujourd’hui',
    'This summary is generated from patient-confirmed and visibly labelled unconfirmed records. Review before adding it to a patient file.': 'Ce résumé est produit à partir des données confirmées par le patient et des données non confirmées clairement identifiées. Révisez-le avant de l’ajouter au dossier du patient.',
    'Start activity': 'Démarrer l’activité', 'Voice note': 'Note vocale', 'Add item': 'Ajouter un élément', '✎ Text': '✎ Texte', '✓ Done': '✓ Fait'
  });
  Object.assign(FR_CA, {
    'Remind items': 'Objets à retrouver',
    'Remember where important items were left.': 'Mémorisez l’endroit où les objets importants ont été laissés.',
    'Open all': 'Tout ouvrir',
    'Add remembered item': 'Ajouter un objet à retrouver',
    'No remembered items yet.': 'Aucun objet mémorisé pour le moment.',
    'Add keys, glasses, tools, documents, or anything easy to misplace.': 'Ajoutez des clés, des lunettes, des outils, des documents ou tout objet facile à égarer.',
    'Item name': 'Nom de l’objet',
    'Last known location': 'Dernier emplacement connu',
    'Example: Entryway bowl': 'Exemple : bol dans l’entrée',
    'Save item': 'Enregistrer l’objet',
    'Most recent picture': 'Photo la plus récente',
    'No picture yet': 'Aucune photo pour le moment',
    'Take new photo': 'Prendre une nouvelle photo',
    'Choose photo': 'Choisir une photo',
    'Edit item': 'Modifier l’objet',
    'Delete item': 'Supprimer l’objet',
    'Photo history': 'Historique des photos',
    'Last updated': 'Dernière mise à jour',
    'Location not entered': 'Emplacement non saisi',
    'Week timeline': 'Chronologie de la semaine',
    'The full week is grouped by your tracking day.': 'La semaine complète est regroupée selon votre journée de suivi.',
    'Tracker updates': 'Mises à jour du suivi',
    'No entries': 'Aucune entrée',
    'Marked done': 'Marqué comme fait',
    'Marked partial': 'Marqué comme partiel',
    'Marked pending': 'Marqué comme en attente',
    'Added one': 'Ajout d’une unité',
    'Removed one': 'Retrait d’une unité',
    'next day': 'lendemain',
    'View item': 'Voir l’objet',
    'Remembered item photo saved.': 'Photo de l’objet mémorisé enregistrée.',
    'Remembered item saved.': 'Objet mémorisé enregistré.',
    'Remembered item deleted.': 'Objet mémorisé supprimé.',
    'Picture (optional)': 'Photo (facultative)',
    'Add a recognition picture now or leave it empty and add one later.': 'Ajoutez maintenant une photo pour reconnaître l’objet, ou laissez ce champ vide et ajoutez-en une plus tard.',
    'No picture selected': 'Aucune photo sélectionnée',
    'Selected picture': 'Photo sélectionnée',
    'Current picture': 'Photo actuelle',
    'Remove selected picture': 'Retirer la photo sélectionnée',
    'Picture selected. It will be saved with the item.': 'Photo sélectionnée. Elle sera enregistrée avec l’objet.',
    'This picture will be added when the item is saved.': 'Cette photo sera ajoutée lors de l’enregistrement de l’objet.',
    'Choose another picture to add a newer one.': 'Choisissez une autre photo pour en ajouter une plus récente.',
    'A picture can make the item easier to recognize.': 'Une photo peut aider à reconnaître l’objet plus facilement.',
    'Open remembered items': 'Ouvrir les objets mémorisés'
  });
  FR_CA['Pocket OT'] = 'Ergo de Poche';
  const FR_SUBSTRINGS = [
    ['Before 10:00 AM', 'Avant 10 h'], ['8:00 AM', '8 h'], ['10:00 AM', '10 h'],
    ['Vitamin D', 'Vitamine D'], ['1 tablet', '1 comprimé'], ['Morning routine', 'Routine du matin'], ['Evening routine', 'Routine du soir'],
    ['Meal recorded', 'Repas enregistré'], ['As needed', 'Au besoin'], ['Kitchen or bathroom', 'Cuisine ou salle de bain'], ['Once today', 'Une fois aujourd’hui'], ['No fixed time', 'Aucune heure fixe'],
    ['Food / groceries', 'Nourriture / épicerie'], ['Personal-care items', 'Articles de soins personnels'], ['Pet food', 'Nourriture pour animaux'], ['Cleaning products', 'Produits nettoyants'],
    ['Morning', 'Matin'], ['Evening', 'Soir'], ['Midday', 'Midi'], ['Today', 'Aujourd’hui'], ['Flexible', 'Flexible'],
    ['Start activity', 'Démarrer l’activité'], ['Done', 'Fait'], ['1 of 2 recorded', '1 sur 2 enregistré'], ['Coffee', 'Café'], ['Litter', 'Litière']
  ];
  const currentLocale = () => uiLanguage === 'fr-CA' ? 'fr-CA' : 'en-CA';
  const normalizeLanguage = value => value === 'fr-CA' || String(value || '').toLowerCase().startsWith('fr') ? 'fr-CA' : 'en';
  const translateExact = (value, language = uiLanguage) => language === 'fr-CA' ? (FR_CA[value] || value) : value;
  function translateDynamic(value, language = uiLanguage) {
    let text = translateExact(String(value ?? ''), language);
    if (language !== 'fr-CA') return text;
    for (const [english, french] of FR_SUBSTRINGS) text = text.replaceAll(english, french);
    text = text.replace(/^Profile created for (.+)\.$/, 'Profil créé pour $1.');
    text = text.replace(/^(.+) recorded from the notification\.$/, '$1 enregistré depuis la notification.');
    text = text.replace(/^Working with (.+)$/, 'Avec $1');
    text = text.replace(/^(\d+) of (\d+) recorded$/, '$1 sur $2 enregistré');
    text = text.replace(/^(\d+) photos need context$/, '$1 photos nécessitent un contexte');
    text = text.replace(/^Hello, (.+)$/, 'Bonjour, $1');
    text = text.replace(/^Review (\d+)$/, 'Réviser $1');
    text = text.replace(/^(\d+)% confidence · confirm$/, '$1 % de confiance · confirmer');
    text = text.replace(/^(.+) · (\d+)% confidence · confirm$/, '$1 · $2 % de confiance · confirmer');
    text = text.replace(/^Target (\d+) · (.+)$/, 'Cible $1 · $2');
    text = text.replace(/^(\d+)% complete · (\d+) missing$/, '$1 % terminé · $2 manquantes');
    text = text.replace(/^(\d+) attention$/, '$1 à surveiller');
    text = text.replace(/^(\d+)% confirmed · (\d+)% context complete$/, '$1 % confirmé · $2 % du contexte complété');
    text = text.replace(/^Review due Today · Assigned to (.+)$/, 'Révision prévue aujourd’hui · Assigné à $1');
    text = text.replace(/^Routine completion is currently (\d+)%. (\d+) periods remain unconfirmed. All photo records include context\.$/, 'L’achèvement des routines est actuellement de $1 %. $2 périodes demeurent non confirmées. Toutes les photos comprennent un contexte.');
    text = text.replace(/^(.+) recorded (\d+) completed routines out of (\d+)\. Timeline confirmation is (\d+)%\. All attached photographs include context\.$/, '$1 a enregistré $2 routines terminées sur $3. La chronologie est confirmée à $4 %. Toutes les photos jointes comprennent un contexte.');
    text = text.replace(/^(\d+) supply items require attention before next week\.$/, '$1 fournitures nécessitent une attention avant la semaine prochaine.');
    text = text.replace(/^(\d+):(\d+) AM$/, (_, h, m) => `${Number(h)} h${m === '00' ? '' : ' ' + m}`);
    text = text.replace(/^(\d+):(\d+) PM$/, (_, h, m) => `${(Number(h) % 12) + 12} h${m === '00' ? '' : ' ' + m}`);
    text = text.replace(/^(\d+) AM$/, (_, h) => `${Number(h)} h`);
    text = text.replace(/^(\d+) PM$/, (_, h) => `${(Number(h) % 12) + 12} h`);
    return text;
  }
  function applyTranslations(root = document, language = uiLanguage) {
    if (root === document) document.documentElement.lang = uiLanguage === 'fr-CA' ? 'fr-CA' : 'en';
    if (language !== 'fr-CA' || !root) return;
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    const nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    for (const node of nodes) {
      const parent = node.parentElement;
      if (!parent || parent.closest('script,style,[data-no-i18n]')) continue;
      const raw = node.nodeValue;
      const trimmed = raw.trim();
      if (!trimmed) continue;
      const translated = translateDynamic(trimmed, language);
      if (translated !== trimmed) node.nodeValue = raw.replace(trimmed, translated);
    }
    root.querySelectorAll?.('[placeholder],[title],[aria-label]').forEach(el => {
      for (const attr of ['placeholder','title','aria-label']) {
        if (!el.hasAttribute(attr)) continue;
        const raw = el.getAttribute(attr);
        el.setAttribute(attr, translateDynamic(raw, language));
      }
    });
  }

  const uid = (prefix = 'id') => `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
  const pad = n => String(n).padStart(2, '0');
  const localDateKey = (date = new Date()) => `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
  const timeLabel = date => date.toLocaleTimeString(currentLocale(), { hour: 'numeric', minute: '2-digit' });
  const dateLabel = date => date.toLocaleDateString(currentLocale(), { weekday: 'long', month: 'long', day: 'numeric' });
  const shortDay = date => date.toLocaleDateString(currentLocale(), { weekday: 'short' });
  const escapeHtml = value => String(value ?? '').replace(/[&<>'"]/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[ch]));

  const appLogoMarkup = (className = '') => `<img class="${className}" src="assets/icon-approved.webp" alt="" aria-hidden="true" />`;

  function startOfWeek(date = new Date()) {
    const copy = new Date(date);
    const day = (copy.getDay() + 6) % 7;
    copy.setDate(copy.getDate() - day);
    copy.setHours(0, 0, 0, 0);
    return copy;
  }


  function localDateFromKey(key) {
    const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(key || ''));
    if (!match) return startOfWeek();
    return new Date(Number(match[1]), Number(match[2]) - 1, Number(match[3]), 0, 0, 0, 0);
  }

  function addLocalDays(date, days) {
    const copy = new Date(date);
    copy.setDate(copy.getDate() + days);
    return copy;
  }

  function weekStartKey(date = new Date()) {
    return localDateKey(startOfWeek(date));
  }

  function reportLanguage() {
    return state.settings.reportLanguage === 'app' ? uiLanguage : normalizeLanguage(state.settings.reportLanguage);
  }

  function reportLocale() {
    return reportLanguage() === 'fr-CA' ? 'fr-CA' : 'en-CA';
  }

  function selectedReportWeekKey() {
    const value = /^\d{4}-\d{2}-\d{2}$/.test(state.reportWeekStart || '') ? state.reportWeekStart : weekStartKey();
    return weekStartKey(localDateFromKey(value));
  }

  function reportWeekLabel(key, includeYear = true) {
    const start = localDateFromKey(key);
    const end = addLocalDays(start, 6);
    const sameMonth = start.getMonth() === end.getMonth();
    const options = includeYear ? { month: 'short', day: 'numeric', year: 'numeric' } : { month: 'short', day: 'numeric' };
    if (sameMonth) {
      const month = start.toLocaleDateString(reportLocale(), { month: 'short' });
      return `${month} ${start.getDate()}–${end.getDate()}${includeYear ? `, ${end.getFullYear()}` : ''}`;
    }
    return `${start.toLocaleDateString(reportLocale(), options)} – ${end.toLocaleDateString(reportLocale(), options)}`;
  }

  function historyWeekKey(item) {
    if (/^\d{4}-\d{2}-\d{2}$/.test(item?.weekStart || '')) return weekStartKey(localDateFromKey(item.weekStart));
    const match = /^([A-Za-z]{3,9})\s+(\d{1,2})$/.exec(String(item?.week || '').trim());
    if (!match) return '';
    const months = { jan:0, feb:1, mar:2, apr:3, may:4, jun:5, jul:6, aug:7, sep:8, oct:9, nov:10, dec:11 };
    const month = months[match[1].slice(0, 3).toLowerCase()];
    if (month === undefined) return '';
    let year = new Date().getFullYear();
    let date = new Date(year, month, Number(match[2]));
    if (date.getTime() > Date.now() + 45 * 86400000) date = new Date(year - 1, month, Number(match[2]));
    return weekStartKey(date);
  }

  function trackingDayDate(value) {
    const date = value instanceof Date ? new Date(value) : new Date(value || Date.now());
    if (Number.isNaN(date.getTime())) return new Date(NaN);
    if (date.getHours() < Number(state?.profile?.dayStartsAt ?? 6)) date.setDate(date.getDate() - 1);
    date.setHours(12, 0, 0, 0);
    return date;
  }

  function trackingDayKey(value) {
    const date = trackingDayDate(value);
    return Number.isNaN(date.getTime()) ? '' : localDateKey(date);
  }

  function weekContains(value, start, end) {
    const tracked = trackingDayDate(value);
    return !Number.isNaN(tracked.getTime()) && tracked >= start && tracked < end;
  }

  function buildWeekReport(key = selectedReportWeekKey()) {
    const normalizedKey = weekStartKey(localDateFromKey(key));
    const start = localDateFromKey(normalizedKey);
    const end = addLocalDays(start, 7);
    const entries = state.timeline.filter(entry => weekContains(entry.start, start, end)).slice().sort((a, b) => Date.parse(a.start) - Date.parse(b.start));
    const routineUpdates = state.routineUpdates.filter(update => weekContains(update.at, start, end) && !['Removed one','Marked pending'].includes(update.action)).slice().sort((a, b) => Date.parse(a.at) - Date.parse(b.at));
    const photos = state.photos.filter(photo => weekContains(photo.capturedAt, start, end)).slice().sort((a, b) => Date.parse(a.capturedAt) - Date.parse(b.capturedAt));
    const notes = state.notes.filter(note => weekContains(note.at, start, end)).slice().sort((a, b) => Date.parse(a.at) - Date.parse(b.at));
    const missingPhotos = photos.filter(photo => !photo.context?.trim());
    const confirmed = entries.filter(entry => entry.source !== 'suggested').length;
    const confirmationRate = entries.length ? Math.round((confirmed / entries.length) * 100) : 0;
    const contextRate = photos.length ? Math.round(((photos.length - missingPhotos.length) / photos.length) * 100) : 100;
    const archive = state.weeklyHistory.find(item => historyWeekKey(item) === normalizedKey) || null;
    const groups = new Map();
    entries.forEach(entry => {
      const label = entry.title?.trim() || entry.category?.trim() || 'Activity';
      const current = groups.get(label) || { title: label, category: entry.category || 'Other', count: 0, confirmed: 0, suggested: 0, photoCount: 0 };
      current.count += 1;
      current.confirmed += entry.source === 'suggested' ? 0 : 1;
      current.suggested += entry.source === 'suggested' ? 1 : 0;
      current.photoCount += entry.photoIds?.length || 0;
      groups.set(label, current);
    });
    const activitySummary = [...groups.values()].sort((a, b) => b.count - a.count || a.title.localeCompare(b.title));
    return {
      key: normalizedKey,
      start,
      end,
      entries,
      routineUpdates,
      photos,
      notes,
      missingPhotos,
      confirmed,
      confirmationRate,
      contextRate,
      archive,
      activitySummary,
      isCurrent: normalizedKey === weekStartKey(),
      label: reportWeekLabel(normalizedKey),
    };
  }

  function availableReportWeekKeys() {
    const keys = new Set();
    const current = startOfWeek();
    for (let i = 0; i < 12; i++) keys.add(weekStartKey(addLocalDays(current, -7 * i)));
    state.timeline.forEach(entry => { const date = trackingDayDate(entry.start); if (!Number.isNaN(date.getTime())) keys.add(weekStartKey(date)); });
    state.routineUpdates.forEach(update => { const date = trackingDayDate(update.at); if (!Number.isNaN(date.getTime())) keys.add(weekStartKey(date)); });
    state.photos.forEach(photo => { const date = trackingDayDate(photo.capturedAt); if (!Number.isNaN(date.getTime())) keys.add(weekStartKey(date)); });
    state.notes.forEach(note => { const date = trackingDayDate(note.at); if (!Number.isNaN(date.getTime())) keys.add(weekStartKey(date)); });
    state.weeklyHistory.forEach(item => { const key = historyWeekKey(item); if (key) keys.add(key); });
    return [...keys].sort((a, b) => b.localeCompare(a)).slice(0, 52);
  }

  function selectReportWeek(key) {
    state.reportWeekStart = weekStartKey(localDateFromKey(key));
    save();
    render();
    main.focus({ preventScroll: true });
  }

  function shiftReportWeek(days) {
    const next = addLocalDays(localDateFromKey(selectedReportWeekKey()), days);
    const current = startOfWeek();
    state.reportWeekStart = weekStartKey(next > current ? current : next);
    save(); render();
  }

  function buildDemoState() {
    const today = localDateKey();
    const stamp = (hour, minute = 0) => `${today}T${pad(hour)}:${pad(minute)}:00`;
    return {
      version: 2,
      setupCompleted: true,
      isDemo: true,
      dataModelVersion: 2,
      mode: 'patient',
      route: 'today',
      profile: {
        id: 'demo-alex',
        name: 'Alex',
        preferredName: 'Alex',
        useMode: 'ot',
        therapist: 'Morgan, OT',
        dayStartsAt: 6,
        dayEndsAt: 27,
      },
      settings: {
        reminders: true,
        missingEntryPrompts: true,
        photoContextReminder: true,
        quietStart: '22:30',
        quietEnd: '07:00',
        largeText: false,
        quickCaptureNotification: false,
        hourlyCheckIns: false,
        hourlyIntervalMinutes: 60,
        hourlyStart: '06:00',
        hourlyEnd: '03:00',
        hourlySkipRecent: true,
        hourlyRecentMinutes: 50,
        appLanguage: PHONE_LANGUAGE,
        reportLanguage: 'app',
        notificationLanguage: 'app',
      },
      routines: [
        { id: 'med_morning', icon: '💊', name: 'Morning medication', type: 'medication', schedule: '8:00 AM', target: 1, count: 0, status: 'pending', detail: 'Vitamin D · 1 tablet' },
        { id: 'teeth_morning', icon: '🪥', name: 'Brush teeth', type: 'personal-care', schedule: 'Morning', target: 1, count: 1, status: 'done', detail: 'Morning routine' },
        { id: 'breakfast', icon: '🍽️', name: 'Breakfast', type: 'meal', schedule: 'Before 10:00 AM', target: 1, count: 1, status: 'done', detail: 'Meal recorded' },
        { id: 'water', icon: '💧', name: 'Drinking water', type: 'count', schedule: 'Throughout the day', target: 8, count: 3, status: 'partial', detail: '3 of 8 recorded' },
        { id: 'coffee', icon: '☕', name: 'Coffee', type: 'count', schedule: 'As needed', target: 2, count: 1, status: 'partial', detail: '1 of 2 recorded' },
        { id: 'surface', icon: '🧽', name: 'Surface cleaning', type: 'maintenance', schedule: 'Today', target: 1, count: 0, status: 'pending', detail: 'Kitchen or bathroom' },
        { id: 'litterbox', icon: '🐾', name: 'Litterbox', type: 'maintenance', schedule: 'Evening', target: 1, count: 0, status: 'pending', detail: 'Once today' },
        { id: 'shower', icon: '🚿', name: 'Shower', type: 'personal-care', schedule: 'Flexible', target: 1, count: 0, status: 'pending', detail: 'No fixed time' },
        { id: 'teeth_evening', icon: '🪥', name: 'Brush teeth', type: 'personal-care', schedule: 'Evening', target: 1, count: 0, status: 'pending', detail: 'Evening routine' },
      ],
      medications: [
        { id: 'med1', name: 'Vitamin D', dosage: '1 tablet', times: ['08:00'], instructions: 'With breakfast', supplyDays: 12, active: true },
        { id: 'med2', name: 'Evening medication', dosage: '1 dose', times: ['20:00'], instructions: '', supplyDays: 8, active: true },
      ],
      routineUpdates: [],
      remindItems: [
        { id: 'memory-keys', name: 'Keys', icon: '🔑', location: 'Small bowl by the front door', note: 'Spare set is kept in the top drawer.', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(), photos: [] },
      ],
      timeline: [
        { id: 't1', start: stamp(6, 45), end: stamp(7, 30), title: 'Morning routine', category: 'Personal care', source: 'confirmed', confidence: 100, notes: '' },
        { id: 't2', start: stamp(7, 35), end: stamp(8, 0), title: 'Breakfast', category: 'Eating', source: 'confirmed', confidence: 100, notes: '' },
        { id: 't3', start: stamp(9, 10), end: stamp(9, 42), title: 'Possible transportation', category: 'Transportation', source: 'suggested', confidence: 78, notes: 'Awaiting confirmation' },
        { id: 't4', start: stamp(10, 0), end: stamp(11, 10), title: 'Appointment', category: 'Appointment', source: 'calendar', confidence: 92, notes: 'Calendar match' },
      ],
      photos: [],
      notes: [],
      supplies: [
        { id: 's1', name: 'Medication', icon: '💊', state: 'enough', note: '' },
        { id: 's2', name: 'Food / groceries', icon: '🛒', state: 'check', note: '' },
        { id: 's3', name: 'Drinking water', icon: '💧', state: 'enough', note: '' },
        { id: 's4', name: 'Coffee', icon: '☕', state: 'low', note: 'Add to grocery list' },
        { id: 's5', name: 'Pet food', icon: '🐾', state: 'enough', note: '' },
        { id: 's6', name: 'Litter', icon: '◻️', state: 'check', note: '' },
        { id: 's7', name: 'Cleaning products', icon: '🧴', state: 'enough', note: '' },
        { id: 's8', name: 'Personal-care items', icon: '🧼', state: 'check', note: '' },
      ],
      reportWeekStart: localDateKey(startOfWeek()),
      weeklyHistory: [
        { week: 'Jul 20', weekStart: '2026-07-20', completion: 62, confirmed: 71, context: 58 },
        { week: 'Jul 27', weekStart: '2026-07-27', completion: 73, confirmed: 79, context: 75 },
        { week: 'Aug 3', weekStart: '2026-08-03', completion: 68, confirmed: 81, context: 80 },
      ],
      patients: [
        { id: 'p1', name: 'Alex R.', completion: 68, missing: 3, flags: 1, review: 'Today' },
        { id: 'p2', name: 'Jamie L.', completion: 84, missing: 1, flags: 0, review: 'Thursday' },
        { id: 'p3', name: 'Sam P.', completion: 51, missing: 8, flags: 2, review: 'Friday' },
      ],
      selectedPatient: 'p1',
    };
  }

  function buildInitialState() {
    const base = buildDemoState();
    return {
      ...base,
      setupCompleted: false,
      isDemo: false,
      legacyDetected: false,
      mode: 'patient',
      route: 'today',
      profile: {
        id: '',
        name: '',
        preferredName: '',
        useMode: 'personal',
        therapist: '',
        dayStartsAt: 6,
        dayEndsAt: 27,
      },
      routines: [],
      medications: [],
      routineUpdates: [],
      remindItems: [],
      timeline: [],
      photos: [],
      notes: [],
      supplies: base.supplies.map(item => ({ ...item, state: 'check', note: '' })),
      weeklyHistory: [],
      reportWeekStart: localDateKey(startOfWeek()),
      patients: [],
      selectedPatient: null,
    };
  }

  function starterRoutineTemplates(draft) {
    const medicationName = draft.medicationName?.trim();
    const medicationDose = draft.medicationDose?.trim() || 'Dose not entered';
    const medicationTime = draft.medicationTime || '08:00';
    const displayTime = new Date(`2000-01-01T${medicationTime}:00`).toLocaleTimeString(currentLocale(), { hour: 'numeric', minute: '2-digit' });
    return {
      medication: { id: uid('routine'), icon: '💊', name: medicationName || 'Medication', type: 'medication', schedule: displayTime, target: 1, count: 0, status: 'pending', detail: medicationName ? `${medicationName} · ${medicationDose}` : 'Add medication details' },
      teethMorning: { id: uid('routine'), icon: '🪥', name: 'Brush teeth', type: 'personal-care', schedule: 'Morning', target: 1, count: 0, status: 'pending', detail: 'Morning routine' },
      teethEvening: { id: uid('routine'), icon: '🪥', name: 'Brush teeth', type: 'personal-care', schedule: 'Evening', target: 1, count: 0, status: 'pending', detail: 'Evening routine' },
      shower: { id: uid('routine'), icon: '🚿', name: 'Shower', type: 'personal-care', schedule: 'Flexible', target: 1, count: 0, status: 'pending', detail: 'No fixed time' },
      meals: [
        { id: uid('routine'), icon: '🍽️', name: 'Breakfast', type: 'meal', schedule: 'Morning', target: 1, count: 0, status: 'pending', detail: 'Meal check-in' },
        { id: uid('routine'), icon: '🍽️', name: 'Lunch', type: 'meal', schedule: 'Midday', target: 1, count: 0, status: 'pending', detail: 'Meal check-in' },
        { id: uid('routine'), icon: '🍽️', name: 'Supper', type: 'meal', schedule: 'Evening', target: 1, count: 0, status: 'pending', detail: 'Meal check-in' },
      ],
      water: { id: uid('routine'), icon: '💧', name: 'Drinking water', type: 'count', schedule: 'Throughout the day', target: 8, count: 0, status: 'pending', detail: '0 of 8 recorded' },
      coffee: { id: uid('routine'), icon: '☕', name: 'Coffee', type: 'count', schedule: 'As needed', target: 2, count: 0, status: 'pending', detail: '0 of 2 recorded' },
      surface: { id: uid('routine'), icon: '🧽', name: 'Surface cleaning', type: 'maintenance', schedule: 'Flexible', target: 1, count: 0, status: 'pending', detail: 'Kitchen, bathroom, or work surface' },
      litterbox: { id: uid('routine'), icon: '🐾', name: 'Litterbox', type: 'maintenance', schedule: 'Evening', target: 1, count: 0, status: 'pending', detail: 'Once today' },
      weekPrep: { id: uid('routine'), icon: '🧺', name: 'Prepare next week', type: 'maintenance', schedule: 'End of week', target: 1, count: 0, status: 'pending', detail: 'Check groceries, water, medication, and supplies' },
    };
  }

  function buildCleanState(draft) {
    const base = buildInitialState();
    const templates = starterRoutineTemplates(draft);
    const selected = new Set(draft.routines || []);
    const routines = [];
    if (selected.has('medication')) routines.push(templates.medication);
    if (selected.has('teethMorning')) routines.push(templates.teethMorning);
    if (selected.has('teethEvening')) routines.push(templates.teethEvening);
    if (selected.has('shower')) routines.push(templates.shower);
    if (selected.has('meals')) routines.push(...templates.meals);
    if (selected.has('water')) routines.push(templates.water);
    if (selected.has('coffee')) routines.push(templates.coffee);
    if (selected.has('surface')) routines.push(templates.surface);
    if (selected.has('litterbox')) routines.push(templates.litterbox);
    if (selected.has('weekPrep')) routines.push(templates.weekPrep);

    const medicationName = draft.medicationName?.trim();
    const medications = selected.has('medication') && medicationName ? [{
      id: uid('med'),
      name: medicationName,
      dosage: draft.medicationDose?.trim() || '',
      times: [draft.medicationTime || '08:00'],
      instructions: '',
      supplyDays: 0,
      active: true,
    }] : [];

    const name = draft.name.trim();
    const preferredName = draft.preferredName?.trim() || name.split(/\s+/)[0];
    const profileId = uid('profile');
    return {
      ...base,
      setupCompleted: true,
      isDemo: false,
      legacyDetected: false,
      profile: {
        id: profileId,
        name,
        preferredName,
        useMode: draft.useMode || 'personal',
        therapist: draft.useMode === 'ot' ? (draft.therapist?.trim() || 'Not assigned') : 'Personal use',
        dayStartsAt: Number(draft.dayStartsAt ?? 6),
        dayEndsAt: Number(draft.dayEndsAt ?? 27),
      },
      settings: {
        ...base.settings,
        reminders: !!draft.reminders,
        missingEntryPrompts: !!draft.missingEntryPrompts,
        photoContextReminder: !!draft.photoContextReminder,
        quickCaptureNotification: !!draft.quickCaptureNotification,
        appLanguage: normalizeLanguage(draft.language || PHONE_LANGUAGE),
        reportLanguage: 'app',
        notificationLanguage: 'app',
      },
      routines,
      medications,
      patients: [{ id: profileId, name, completion: 0, missing: 0, flags: 0, review: 'Not scheduled', local: true }],
      selectedPatient: profileId,
    };
  }

  function hydrateState(parsed) {
    const base = buildDemoState();
    const setupCompleted = parsed.setupCompleted === undefined ? false : !!parsed.setupCompleted;
    return {
      ...base,
      ...parsed,
      setupCompleted,
      isDemo: parsed.isDemo === undefined ? true : !!parsed.isDemo,
      legacyDetected: parsed.setupCompleted === undefined,
      profile: { ...base.profile, ...(parsed.profile || {}) },
      settings: { ...base.settings, ...(parsed.settings || {}) },
      routines: Array.isArray(parsed.routines) ? parsed.routines : base.routines,
      medications: Array.isArray(parsed.medications) ? parsed.medications : base.medications,
      routineUpdates: Array.isArray(parsed.routineUpdates) ? parsed.routineUpdates : [],
      remindItems: Array.isArray(parsed.remindItems) ? parsed.remindItems.map(item => ({ ...item, photos: Array.isArray(item.photos) ? item.photos : [] })) : [],
      timeline: Array.isArray(parsed.timeline) ? parsed.timeline : base.timeline,
      photos: Array.isArray(parsed.photos) ? parsed.photos : [],
      notes: Array.isArray(parsed.notes) ? parsed.notes : [],
      supplies: Array.isArray(parsed.supplies) ? parsed.supplies : base.supplies,
      weeklyHistory: Array.isArray(parsed.weeklyHistory) ? parsed.weeklyHistory : base.weeklyHistory,
      reportWeekStart: /^\d{4}-\d{2}-\d{2}$/.test(parsed.reportWeekStart || '') ? parsed.reportWeekStart : localDateKey(startOfWeek()),
      patients: Array.isArray(parsed.patients) ? parsed.patients : base.patients,
    };
  }


  function isEmbeddedPhoto(value) {
    return typeof value === 'string' && value.startsWith('data:image/');
  }

  function archivePhotoData(value, id) {
    if (!isEmbeddedPhoto(value) || !isNativeApp || !nativeBridge?.storePhotoDataUrl) return value;
    const stored = nativeBridge.storePhotoDataUrl(String(id || uid('photo')), value);
    if (!stored) throw new Error('Native photo archive write failed.');
    return stored;
  }

  function deleteArchivedPhoto(reference) {
    if (!isNativeApp || !nativeBridge?.deleteArchivedPhoto || !reference || isEmbeddedPhoto(reference)) return;
    try { nativeBridge.deleteArchivedPhoto(reference); } catch (error) { console.warn('Could not remove archived photo', error); }
  }

  function migrateEmbeddedPhotos(parsed) {
    let migrated = 0;
    (parsed.photos || []).forEach(photo => {
      if (!photo || !isEmbeddedPhoto(photo.dataUrl)) return;
      photo.dataUrl = archivePhotoData(photo.dataUrl, photo.id || uid('photo'));
      migrated += 1;
    });
    (parsed.remindItems || []).forEach(item => {
      (item?.photos || []).forEach(photo => {
        if (!photo || !isEmbeddedPhoto(photo.dataUrl)) return;
        photo.dataUrl = archivePhotoData(photo.dataUrl, photo.id || uid('memory-photo'));
        migrated += 1;
      });
    });
    return migrated;
  }

  function loadState() {
    try {
      if (isNativeApp && nativeBridge?.loadStateJson) {
        const nativeRaw = nativeBridge.loadStateJson();
        if (nativeRaw) return hydrateState(JSON.parse(nativeRaw));

        // One-time v0.4.7 -> v0.4.8 migration.  The old state remains in
        // localStorage until every embedded photo has been archived and the
        // native SQLite state row has committed successfully.
        const legacyRaw = localStorage.getItem(STORAGE_KEY);
        if (!legacyRaw) return buildInitialState();
        const parsed = JSON.parse(legacyRaw);
        const migrated = migrateEmbeddedPhotos(parsed);
        const hydrated = hydrateState(parsed);
        if (!nativeBridge.saveStateJson(JSON.stringify(hydrated))) {
          throw new Error('Native state migration could not be committed.');
        }
        try {
          localStorage.removeItem(STORAGE_KEY);
          localStorage.setItem('ot-pocket-native-migration-v0.4.8', String(Date.now()));
        } catch (cleanupError) {
          console.warn('Legacy WebView storage could not be cleaned after migration', cleanupError);
        }
        if (migrated) console.info(`Archived ${migrated} legacy Pocket OT photo(s).`);
        return hydrated;
      }

      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return buildInitialState();
      return hydrateState(JSON.parse(raw));
    } catch (error) {
      console.warn('Could not restore data', error);
      // Never hide a readable v0.4.7 profile just because the native migration
      // could not finish.  The legacy copy stays untouched until migration
      // commits, so fall back to it instead of presenting an empty profile.
      try {
        const legacyRaw = localStorage.getItem(STORAGE_KEY);
        if (legacyRaw) return hydrateState(JSON.parse(legacyRaw));
      } catch (legacyError) {
        console.warn('Legacy Pocket OT data is also unreadable', legacyError);
      }
      return buildInitialState();
    }
  }

  let state = loadState();
  uiLanguage = normalizeLanguage(state.settings?.appLanguage || PHONE_LANGUAGE);
  try {
    const notificationLanguage = state.settings?.notificationLanguage === 'app' ? uiLanguage : normalizeLanguage(state.settings?.notificationLanguage || uiLanguage);
    nativeBridge?.setPreferredLanguage?.(notificationLanguage);
  } catch (error) { console.warn(error); }
  const main = $('#mainContent');
  const modalRoot = $('#modalRoot');
  const cameraInput = $('#cameraInput');
  const galleryInput = $('#galleryInput');
  const backupInput = $('#backupInput');
  const PATIENT_ROUTES = ['today', 'timeline', 'capture', 'week', 'reports', 'report-preview'];
  const navigationStack = [];
  let lastContentRoute = state.route && state.route !== 'settings' ? state.route : 'today';

  let onboardingStep = 1;
  let prepareWeekDraftNote = '';
  let expandedRemindItemId = '';
  let memoryEditorDraftPhoto = null;
  let memoryEditorEditingId = '';
  let timelineDayOffset = 0;
  let capturePhotoLimit = 120;
  let onboardingDraft = {
    name: state.setupCompleted || state.isDemo ? '' : (state.profile.name || ''),
    preferredName: '',
    useMode: 'personal',
    therapist: '',
    dayStartsAt: 6,
    dayEndsAt: 27,
    reminders: true,
    missingEntryPrompts: true,
    photoContextReminder: true,
    quickCaptureNotification: false,
    routines: ['teethMorning', 'teethEvening', 'shower', 'meals', 'water', 'surface', 'litterbox', 'weekPrep'],
    medicationName: '',
    medicationDose: '',
    medicationTime: '08:00',
    language: normalizeLanguage(state.settings?.appLanguage || PHONE_LANGUAGE),
  };

  function latestRecordedTimestamp() {
    const values = [
      ...(state.timeline || []).map(entry => Date.parse(entry.start || '')),
      ...(state.routineUpdates || []).map(update => Date.parse(update.at || '')),
      ...(state.photos || []).map(photo => Date.parse(photo.capturedAt || '')),
      ...(state.notes || []).map(note => Date.parse(note.at || '')),
    ].filter(Number.isFinite);
    return values.length ? Math.max(...values) : 0;
  }

  function syncNativeActivityTimestamp() {
    if (!isNativeApp || !nativeBridge?.markActivityRecorded) return;
    const timestamp = latestRecordedTimestamp();
    try { nativeBridge.markActivityRecorded(timestamp); } catch (error) { console.warn(error); }
  }

  function applyHourlyCheckInSettings() {
    if (!isNativeApp || !nativeBridge?.configureHourlyCheckIns) return;
    try {
      nativeBridge.configureHourlyCheckIns(
        !!state.settings.hourlyCheckIns,
        Number(state.settings.hourlyIntervalMinutes || 60),
        state.settings.hourlyStart || '06:00',
        state.settings.hourlyEnd || '03:00',
        state.settings.hourlySkipRecent !== false,
        Number(state.settings.hourlyRecentMinutes || 50),
      );
    } catch (error) {
      console.warn('Could not configure hourly check-ins', error);
    }
  }

  function save() {
    try {
      const json = JSON.stringify(state);
      if (isNativeApp && nativeBridge?.saveStateJson) {
        if (!nativeBridge.saveStateJson(json)) throw new Error('Native SQLite save failed.');
      } else {
        localStorage.setItem(STORAGE_KEY, json);
      }
      syncNativeActivityTimestamp();
      return true;
    } catch (error) {
      toast('Pocket OT could not save this change. Check available device storage.');
      console.error(error);
      return false;
    }
  }

  function toast(message) {
    const node = document.createElement('div');
    node.className = 'toast';
    node.textContent = translateDynamic(message);
    $('#toastRoot').appendChild(node);
    setTimeout(() => node.remove(), 3200);
  }

  function setRoute(route, options = {}) {
    const nextRoute = route || 'today';
    const current = { route: state.route || 'today', mode: state.mode || 'patient' };
    if (!options.replace && (current.route !== nextRoute || (options.mode && current.mode !== options.mode))) {
      navigationStack.push(current);
      if (navigationStack.length > 30) navigationStack.shift();
    }
    if (options.mode) state.mode = options.mode;
    state.route = nextRoute;
    if (nextRoute !== 'settings') lastContentRoute = nextRoute;
    save();
    render();
    main.focus({ preventScroll: true });
  }

  function navigateBack() {
    if (modalRoot.children.length) {
      closeModal();
      return true;
    }
    if (!state.setupCompleted) {
      if (onboardingStep > 1) {
        onboardingStep -= 1;
        render();
        return true;
      }
      return false;
    }
    if (state.route === 'settings') {
      const previous = navigationStack.pop();
      if (previous) {
        state.mode = previous.mode || 'patient';
        state.route = previous.route === 'settings' ? lastContentRoute : previous.route;
      } else {
        state.route = lastContentRoute || 'today';
      }
      save(); render();
      return true;
    }
    const previous = navigationStack.pop();
    if (previous && previous.route !== state.route) {
      state.mode = previous.mode || 'patient';
      state.route = previous.route || 'today';
      if (state.route !== 'settings') lastContentRoute = state.route;
      save(); render();
      return true;
    }
    if (state.mode === 'ot') {
      state.mode = 'patient';
      state.route = lastContentRoute || 'today';
      save(); render();
      return true;
    }
    if (state.route !== 'today') {
      state.route = 'today';
      lastContentRoute = 'today';
      save(); render();
      return true;
    }
    return false;
  }

  window.OTPocketHandleBack = navigateBack;

  function completionStats() {
    const done = state.routines.filter(item => item.status === 'done').length;
    const partial = state.routines.filter(item => item.status === 'partial').length;
    const total = state.routines.length;
    const percent = total ? Math.round(((done + partial * 0.5) / total) * 100) : 0;
    return { done, partial, total, percent };
  }

  function contextualPhotos() {
    return state.photos.filter(photo => !photo.context?.trim());
  }

  function dayEntryHours(entry) {
    const date = new Date(entry.start);
    let hour = date.getHours();
    if (hour < state.profile.dayStartsAt) hour += 24;
    return hour;
  }


  function plannerHourOptions(selected, isEnd = false) {
    const values = isEnd ? [22, 23, 24, 25, 26, 27, 28, 29, 30] : [4, 5, 6, 7, 8, 9, 10];
    return values.map(value => {
      const hour = value % 24;
      const suffix = value >= 24 ? ' next day' : '';
      const label = new Date(`2000-01-01T${pad(hour)}:00:00`).toLocaleTimeString(currentLocale(), { hour: 'numeric' }) + suffix;
      return `<option value="${value}" ${Number(selected) === value ? 'selected' : ''}>${escapeHtml(label)}</option>`;
    }).join('');
  }

  function renderOnboarding() {
    const progress = `<div class="setup-progress" aria-label="Setup step ${onboardingStep} of 3"><span class="${onboardingStep >= 1 ? 'active' : ''}"></span><span class="${onboardingStep >= 2 ? 'active' : ''}"></span><span class="${onboardingStep >= 3 ? 'active' : ''}"></span></div>`;
    if (onboardingStep === 1) {
      return `<section class="setup-shell">
        <div class="setup-card">
          <div class="setup-brand">${appLogoMarkup('setup-logo')}<div><b>Pocket OT</b><small>Passive routine companion</small></div></div>
          ${progress}
          <div class="eyebrow">Welcome</div>
          <h1>Set up your profile</h1>
          <p class="subtle">Create a clean personal profile. Demonstration patients and sample records will not be mixed into it.</p>
          ${state.legacyDetected ? '<div class="callout"><strong>Previous demo detected</strong>Creating your profile replaces the old sample data. Export anything you need before continuing.</div>' : ''}
          <form id="setupBasicsForm" class="setup-form">
            <div class="form-group language-first"><label for="setupLanguage">Language</label><select id="setupLanguage" class="input"><option value="en" ${onboardingDraft.language === 'en' ? 'selected' : ''}>English</option><option value="fr-CA" ${onboardingDraft.language === 'fr-CA' ? 'selected' : ''}>Français (Canada)</option></select><small class="field-help">Defaults to the phone language. English is used when the phone language is not supported.</small></div>
            <div class="form-group"><label for="setupName">Full name or patient label</label><input id="setupName" class="input large-input" autocomplete="name" value="${escapeHtml(onboardingDraft.name)}" placeholder="Example: Alex R." required /></div>
            <div class="form-group"><label for="setupPreferredName">Preferred first name <span class="optional">optional</span></label><input id="setupPreferredName" class="input" value="${escapeHtml(onboardingDraft.preferredName)}" placeholder="Shown in greetings" /></div>
            <fieldset class="setup-fieldset"><legend>How will this profile be used?</legend>
              <label class="choice-card"><input type="radio" name="useMode" value="personal" ${onboardingDraft.useMode === 'personal' ? 'checked' : ''}/><span><b>Personal use</b><small>Track routines and create my own reports.</small></span></label>
              <label class="choice-card"><input type="radio" name="useMode" value="ot" ${onboardingDraft.useMode === 'ot' ? 'checked' : ''}/><span><b>Working with an OT</b><small>Include therapist and clinical-review context.</small></span></label>
            </fieldset>
            <div id="therapistField" class="form-group ${onboardingDraft.useMode === 'ot' ? '' : 'hidden'}"><label for="setupTherapist">Occupational therapist <span class="optional">optional</span></label><input id="setupTherapist" class="input" value="${escapeHtml(onboardingDraft.therapist)}" placeholder="Name or healthcare center" /></div>
            <button class="btn primary full setup-primary" type="submit">Continue</button>
          </form>
          <button id="skipDemoSetup" class="setup-skip" type="button">Skip to demo</button>
          <p class="setup-footnote">The demo is temporary test data and should not be used as a clinical record.</p>
        </div>
      </section>`;
    }
    if (onboardingStep === 2) {
      return `<section class="setup-shell"><div class="setup-card">
        <div class="setup-brand compact">${appLogoMarkup('setup-logo')}<div><b>Pocket OT</b><small>Profile setup</small></div></div>
        ${progress}
        <div class="eyebrow">Planner & prompts</div><h1>Fit the day to the patient</h1>
        <p class="subtle">The original planner defaults to 6:00 a.m.–3:00 a.m. the following day.</p>
        <form id="setupPlannerForm" class="setup-form">
          <div class="form-row"><div class="form-group"><label for="setupDayStart">Day begins</label><select id="setupDayStart" class="input">${plannerHourOptions(onboardingDraft.dayStartsAt)}</select></div><div class="form-group"><label for="setupDayEnd">Day ends</label><select id="setupDayEnd" class="input">${plannerHourOptions(onboardingDraft.dayEndsAt, true)}</select></div></div>
          <label class="toggle-card"><input id="setupReminders" type="checkbox" ${onboardingDraft.reminders ? 'checked' : ''}/><span><b>Routine reminders</b><small>Ask at the right time without requiring the app to stay open.</small></span></label>
          <label class="toggle-card"><input id="setupMissing" type="checkbox" ${onboardingDraft.missingEntryPrompts ? 'checked' : ''}/><span><b>Ask about missing periods</b><small>Only prompt when a useful timeline gap remains.</small></span></label>
          <label class="toggle-card"><input id="setupPhotoContext" type="checkbox" ${onboardingDraft.photoContextReminder ? 'checked' : ''}/><span><b>Remind me to describe photos</b><small>Capture now, add context when hands are clean.</small></span></label>
          <label class="toggle-card"><input id="setupQuickNotification" type="checkbox" ${onboardingDraft.quickCaptureNotification ? 'checked' : ''}/><span><b>Persistent quick-capture notification</b><small>Keep Photo, Text, Done, and Later one tap away.</small></span></label>
          <div class="setup-actions"><button id="setupBack1" class="btn ghost" type="button">Back</button><button class="btn primary" type="submit">Continue</button></div>
        </form>
      </div></section>`;
    }
    const routineChoices = [
      ['medication','💊','Medication reminder','Add one medication now; more can be added later.'],
      ['teethMorning','🪥','Brush teeth — morning','Daily personal-care check.'],
      ['teethEvening','🪥','Brush teeth — evening','Separate evening completion.'],
      ['shower','🚿','Shower','Flexible personal-care item.'],
      ['meals','🍽️','Eating','Breakfast, lunch, and supper.'],
      ['water','💧','Drinking water','Daily water counter with minus and plus controls.'],
      ['coffee','☕','Coffee','Optional count rather than simple done/not done.'],
      ['surface','🧽','Surface cleaning','Kitchen, bathroom, or work surface.'],
      ['litterbox','🐾','Litterbox','Recurring household/pet-care task.'],
      ['weekPrep','🧺','Prepare next week','Check water, food, groceries, medication, and supplies.'],
    ];
    return `<section class="setup-shell"><div class="setup-card wide">
      <div class="setup-brand compact">${appLogoMarkup('setup-logo')}<div><b>Pocket OT</b><small>Profile setup</small></div></div>
      ${progress}
      <div class="eyebrow">Starter routines</div><h1>Choose what to track</h1>
      <p class="subtle">These are only starting items. Every routine can be changed or removed afterward.</p>
      <form id="setupRoutinesForm" class="setup-form">
        <div id="starterRoutines" class="starter-grid">${routineChoices.map(([key, icon, title, description]) => `<label class="starter-card"><input type="checkbox" value="${key}" ${onboardingDraft.routines.includes(key) ? 'checked' : ''}/><span class="starter-icon">${icon}</span><span><b>${title}</b><small>${description}</small></span></label>`).join('')}</div>
        <div id="setupMedicationFields" class="medication-setup ${onboardingDraft.routines.includes('medication') ? '' : 'hidden'}">
          <h2>First medication</h2>
          <div class="form-row"><div class="form-group"><label for="setupMedicationName">Medication label</label><input id="setupMedicationName" class="input" value="${escapeHtml(onboardingDraft.medicationName)}" placeholder="Use the patient’s preferred label" /></div><div class="form-group"><label for="setupMedicationDose">Dose <span class="optional">optional</span></label><input id="setupMedicationDose" class="input" value="${escapeHtml(onboardingDraft.medicationDose)}" placeholder="Example: 1 tablet" /></div></div>
          <div class="form-group"><label for="setupMedicationTime">Reminder time</label><input id="setupMedicationTime" class="input" type="time" value="${escapeHtml(onboardingDraft.medicationTime)}" /></div>
        </div>
        <div class="setup-actions"><button id="setupBack2" class="btn ghost" type="button">Back</button><button class="btn primary" type="submit">Create profile</button></div>
      </form>
    </div></section>`;
  }

  function bindOnboardingEvents() {
    if (onboardingStep === 1) {
      $('#setupLanguage')?.addEventListener('change', event => { onboardingDraft.language = normalizeLanguage(event.target.value); uiLanguage = onboardingDraft.language; render(); });
      $$('input[name="useMode"]').forEach(input => input.addEventListener('change', () => $('#therapistField').classList.toggle('hidden', input.value !== 'ot' || !input.checked)));
      $('#setupBasicsForm').addEventListener('submit', event => {
        event.preventDefault();
        onboardingDraft.language = normalizeLanguage($('#setupLanguage')?.value || onboardingDraft.language);
        uiLanguage = onboardingDraft.language;
        onboardingDraft.name = $('#setupName').value.trim();
        onboardingDraft.preferredName = $('#setupPreferredName').value.trim();
        onboardingDraft.useMode = $('input[name="useMode"]:checked')?.value || 'personal';
        onboardingDraft.therapist = $('#setupTherapist').value.trim();
        onboardingStep = 2; render();
      });
      $('#skipDemoSetup').addEventListener('click', () => {
        state = buildDemoState();
        state.settings.appLanguage = normalizeLanguage(onboardingDraft.language || PHONE_LANGUAGE);
        state.settings.reportLanguage = 'app'; state.settings.notificationLanguage = 'app';
        uiLanguage = state.settings.appLanguage;
        try { nativeBridge?.setPreferredLanguage?.(uiLanguage); } catch (error) { console.warn(error); }
        onboardingStep = 1;
        save(); render();
        toast('Demo profile loaded. Sample records are clearly marked as demonstration data.');
      });
      return;
    }
    if (onboardingStep === 2) {
      $('#setupBack1').addEventListener('click', () => { onboardingStep = 1; render(); });
      $('#setupPlannerForm').addEventListener('submit', event => {
        event.preventDefault();
        onboardingDraft.dayStartsAt = Number($('#setupDayStart').value);
        onboardingDraft.dayEndsAt = Number($('#setupDayEnd').value);
        onboardingDraft.reminders = $('#setupReminders').checked;
        onboardingDraft.missingEntryPrompts = $('#setupMissing').checked;
        onboardingDraft.photoContextReminder = $('#setupPhotoContext').checked;
        onboardingDraft.quickCaptureNotification = $('#setupQuickNotification').checked;
        onboardingStep = 3; render();
      });
      return;
    }
    const syncMedicationVisibility = () => {
      const selected = [...$$('#starterRoutines input:checked')].map(input => input.value);
      $('#setupMedicationFields').classList.toggle('hidden', !selected.includes('medication'));
    };
    $$('#starterRoutines input').forEach(input => input.addEventListener('change', syncMedicationVisibility));
    $('#setupBack2').addEventListener('click', () => { onboardingStep = 2; render(); });
    $('#setupRoutinesForm').addEventListener('submit', event => {
      event.preventDefault();
      onboardingDraft.routines = [...$$('#starterRoutines input:checked')].map(input => input.value);
      onboardingDraft.medicationName = $('#setupMedicationName')?.value.trim() || '';
      onboardingDraft.medicationDose = $('#setupMedicationDose')?.value.trim() || '';
      onboardingDraft.medicationTime = $('#setupMedicationTime')?.value || '08:00';
      if (onboardingDraft.routines.includes('medication') && !onboardingDraft.medicationName) {
        $('#setupMedicationName').focus();
        return toast('Enter a medication label or turn off the medication starter item.');
      }
      state = buildCleanState(onboardingDraft);
      uiLanguage = normalizeLanguage(state.settings.appLanguage);
      try { nativeBridge?.setPreferredLanguage?.(uiLanguage); } catch (error) { console.warn(error); }
      onboardingStep = 1;
      save(); render();
      if (isNativeApp && state.settings.quickCaptureNotification) {
        try { nativeBridge.requestNotificationPermission(); nativeBridge.showQuickCaptureNotification(); } catch (error) { console.warn(error); }
      }
      toast(`Profile created for ${state.profile.preferredName || state.profile.name}.`);
    });
  }

  function render() {
    const setupMode = !state.setupCompleted;
    const settingsMode = state.setupCompleted && state.route === 'settings';
    document.documentElement.lang = uiLanguage === 'fr-CA' ? 'fr-CA' : 'en';
    document.body.classList.toggle('setup-mode', setupMode);
    document.body.classList.toggle('settings-mode', settingsMode);
    if (setupMode) {
      main.innerHTML = renderOnboarding();
      applyTranslations(document);
      bindOnboardingEvents();
      return;
    }

    const modeSwitch = $('#modeSwitch');
    const settingsButton = $('#settingsButton');
    modeSwitch.hidden = settingsMode;
    settingsButton.textContent = settingsMode ? '←' : '⚙';
    settingsButton.classList.toggle('active', settingsMode);
    settingsButton.setAttribute('aria-label', settingsMode ? 'Back' : 'Open settings');
    $('#modeLabel').textContent = settingsMode
      ? 'Settings'
      : (state.mode === 'patient' ? `Patient view${state.isDemo ? ' · Demo' : ''}` : `Occupational therapist view${state.isDemo ? ' · Demo' : ''}`);
    modeSwitch.setAttribute('aria-label', state.mode === 'patient' ? 'Open occupational therapist view' : 'Open patient view');
    const activeNavRoute = state.route === 'report-preview' ? 'reports' : state.route === 'items' ? 'today' : state.route;
    $$('.nav-item').forEach(item => item.classList.toggle('active', item.dataset.route === activeNavRoute));

    if (settingsMode) {
      main.innerHTML = renderSettings();
      applyTranslations(document.querySelector('.topbar'));
      applyTranslations(main);
      bindSettingsEvents();
      return;
    }

    if (state.mode === 'ot') {
      main.innerHTML = renderOTDashboard();
      applyTranslations(document);
      bindOTEvents();
      return;
    }

    const renderers = {
      today: renderToday,
      items: renderRemindItems,
      timeline: renderTimeline,
      capture: renderCapture,
      week: renderWeek,
      reports: renderReports,
      'report-preview': renderReportPreview,
    };
    main.innerHTML = (renderers[state.route] || renderToday)();
    applyTranslations(document.querySelector('.topbar'));
    applyTranslations(document.querySelector('#bottomNav'));
    const contentLanguage = ['reports', 'report-preview'].includes(state.route) ? (state.settings.reportLanguage === 'app' ? uiLanguage : normalizeLanguage(state.settings.reportLanguage)) : uiLanguage;
    applyTranslations(main, contentLanguage);
    bindRouteEvents();
  }

  function renderToday() {
    const stats = completionStats();
    const next = state.routines.find(item => item.status !== 'done') || state.routines[0];
    const nextBlock = next ? `
      <section class="card hero">
        <div class="hero-row"><div class="hero-main">
          <div class="hero-time">${timeLabel(new Date())}</div>
          <div class="hero-title">${escapeHtml(next.name)}</div>
          <div class="subtle">${escapeHtml(next.schedule)} · ${escapeHtml(next.detail)}</div>
          <div class="hero-actions">
            ${next.type === 'count'
              ? `<button class="btn light count-hero-button" data-routine-count="${next.id}" data-delta="-1" ${next.count <= 0 ? 'disabled' : ''}>−</button><span class="hero-count">${next.count}/${next.target}</span><button class="btn light count-hero-button" data-routine-count="${next.id}" data-delta="1">＋</button>`
              : `<button class="btn light" data-routine="${next.id}" data-status="done">✓ Done</button>`}
            <button class="btn light" data-action="photo" data-linked="${next.id}">📷 Photo</button>
            <button class="btn light" data-action="quick-text" data-linked="${next.id}">✎ Text</button>
            <button class="btn ghost" style="color:white;border-color:rgba(255,255,255,.36)" data-action="later">Later</button>
          </div>
        </div></div>
      </section>` : `
      <section class="card hero"><div class="hero-row"><div class="hero-main">
        <div class="hero-time">${timeLabel(new Date())}</div><div class="hero-title">Your profile is ready</div>
        <div class="subtle">Add a routine or record an activity whenever you are ready.</div>
        <div class="hero-actions"><button class="btn light" data-action="add-routine">＋ Add first item</button><button class="btn light" data-action="photo">📷 Photo</button><button class="btn light" data-action="quick-text">✎ Text</button></div>
      </div></div></section>`;
    return `
      <div class="page-head">
        <div>
          <div class="eyebrow">${escapeHtml(dateLabel(now))}</div>
          <h1>Hello, ${escapeHtml(state.profile.preferredName || state.profile.name)}</h1>
          <p class="subtle">Your day is already partly organized. Confirm only what needs attention.</p>
        </div>
        <button class="btn secondary no-print" data-action="review">Review ${contextualPhotos().length + state.timeline.filter(e => e.source === 'suggested').length}</button>
      </div>

      ${nextBlock}

      <div class="summary-strip">
        <div class="summary-stat"><b>${stats.percent}%</b><span>today completed</span></div>
        <div class="summary-stat"><b>${stats.done}/${stats.total}</b><span>routines done</span></div>
        <div class="summary-stat"><b>${contextualPhotos().length}</b><span>photos need context</span></div>
        <div class="summary-stat"><b>${state.timeline.filter(e => e.source === 'suggested').length}</b><span>suggestions to confirm</span></div>
      </div>

      <section class="section">
        <div class="section-head"><h2>Quick record</h2><button class="link-button" data-route-link="capture">More options</button></div>
        <div class="quick-grid">
          <button class="quick-action" data-action="photo"><span>📷</span>Photo</button>
          <button class="quick-action" data-action="quick-text"><span>✎</span>Text</button>
          <button class="quick-action" data-action="voice"><span>🎙</span>Voice note</button>
          <button class="quick-action" data-action="current"><span>▶</span>Start activity</button>
        </div>
      </section>

      ${renderRemindItemsStrip()}

      <section class="section">
        <div class="section-head"><h2>Today</h2><div class="chip-row"><button class="link-button" data-action="reorder-routines">Reorder</button><button class="link-button" data-action="add-routine">Add item</button></div></div>
        <div class="routine-list">${state.routines.length ? state.routines.map(renderRoutineRow).join('') : '<div class="empty-state"><div class="empty-icon">✓</div><b>No routines selected</b><p>Add only what is useful for this profile.</p></div>'}</div>
      </section>

      ${state.photos.length ? `
      <section class="section">
        <div class="section-head"><h2>Context pictures</h2><button class="link-button" data-route-link="capture">Open pictures</button></div>
        <div class="photo-grid">${state.photos.slice(-3).reverse().map(renderPhotoCard).join('')}</div>
      </section>` : ''}
    `;
  }

  function latestRoutineLog(item) {
    return state.timeline
      .filter(entry => entry.routineId === item.id && trackingDayKey(entry.start) === trackingDayKey(new Date()))
      .slice()
      .sort((a, b) => Date.parse(b.start) - Date.parse(a.start))[0] || null;
  }

  function renderRoutineRow(item) {
    const statusLabel = item.status === 'done' ? 'Undo' : item.status === 'partial' ? `${item.count}/${item.target}` : 'Done';
    const latest = latestRoutineLog(item);
    const loggedMeta = latest ? ` · Last updated ${timeLabel(new Date(latest.start))}` : '';
    const control = item.type === 'count'
      ? `<div class="count-control" aria-label="${escapeHtml(item.name)} count">
          <button class="count-button" data-routine-count="${item.id}" data-delta="-1" aria-label="Decrease ${escapeHtml(item.name)}" ${item.count <= 0 ? 'disabled' : ''}>−</button>
          <output class="count-value" aria-live="polite"><b>${item.count}</b><small>/${item.target}</small></output>
          <button class="count-button primary" data-routine-count="${item.id}" data-delta="1" aria-label="Increase ${escapeHtml(item.name)}">＋</button>
        </div>`
      : `<button class="status-button ${item.status}" data-routine-cycle="${item.id}">${statusLabel}</button>`;
    return `
      <div class="routine-row ${item.type === 'count' ? 'count-routine-row' : ''}">
        <div class="routine-icon" aria-hidden="true">${item.icon}</div>
        <div class="routine-copy">
          <div class="routine-title">${escapeHtml(item.name)}</div>
          <div class="routine-meta">${escapeHtml(item.schedule)} · ${escapeHtml(item.detail)}${escapeHtml(loggedMeta)}</div>
        </div>
        ${control}
      </div>`;
  }

  function latestRemindItemPhoto(item) {
    return (item.photos || []).slice().sort((a, b) => Date.parse(a.capturedAt) - Date.parse(b.capturedAt)).at(-1) || null;
  }

  function renderRemindItemTile(item) {
    const photo = latestRemindItemPhoto(item);
    return `<button class="memory-tile ${expandedRemindItemId === item.id ? 'active' : ''}" data-memory-item="${item.id}" aria-label="View item ${escapeHtml(item.name)}">
      <span class="memory-tile-visual">${photo ? `<img src="${photo.dataUrl}" loading="lazy" decoding="async" alt="Most recent picture of ${escapeHtml(item.name)}" />` : `<span class="memory-tile-icon">${escapeHtml(item.icon || '📍')}</span>`}</span>
      <span class="memory-tile-name">${escapeHtml(item.name)}</span>
      <small>${escapeHtml(item.location || 'Location not entered')}</small>
    </button>`;
  }

  function renderRemindItemDetail(item, compact = false) {
    const photo = latestRemindItemPhoto(item);
    const updated = item.updatedAt ? new Date(item.updatedAt).toLocaleString(currentLocale(), { dateStyle: 'medium', timeStyle: 'short' }) : '';
    return `<section class="card memory-detail ${compact ? 'compact-memory-detail' : ''}">
      <div class="memory-detail-head">
        <div class="memory-detail-icon">${escapeHtml(item.icon || '📍')}</div>
        <div><div class="eyebrow">Last known location</div><h2>${escapeHtml(item.name)}</h2><p class="memory-location">${escapeHtml(item.location || 'Location not entered')}</p></div>
        ${compact ? '<button class="close-button no-print" data-action="close-memory-item" aria-label="Close">×</button>' : ''}
      </div>
      <div class="memory-detail-grid">
        <div class="memory-photo-frame">${photo ? `<img src="${photo.dataUrl}" loading="lazy" decoding="async" alt="Most recent picture of ${escapeHtml(item.name)}" />` : `<div class="memory-photo-empty"><span>${escapeHtml(item.icon || '📍')}</span><b>No picture yet</b></div>`}</div>
        <div class="memory-detail-copy">
          <h3>Most recent picture</h3>
          <p class="subtle">${photo ? `${dateLabel(new Date(photo.capturedAt))} · ${timeLabel(new Date(photo.capturedAt))}` : 'Take a photo to make this item easier to recognize later.'}</p>
          ${item.note ? `<p>${escapeHtml(item.note)}</p>` : ''}
          ${updated ? `<p class="routine-meta">Last updated ${escapeHtml(updated)}</p>` : ''}
          <div class="chip-row no-print">
            <button class="btn primary" data-action="memory-photo" data-memory="${item.id}">📷 Take new photo</button>
            <button class="btn secondary" data-action="memory-gallery" data-memory="${item.id}">▧ Choose photo</button>
            <button class="btn ghost" data-action="edit-memory-item" data-memory="${item.id}">✎ Edit item</button>
          </div>
        </div>
      </div>
      ${(item.photos || []).length > 1 ? `<div class="memory-history"><h3>Photo history</h3><div class="memory-history-strip">${item.photos.slice().reverse().map(entry => `<img src="${entry.dataUrl}" loading="lazy" decoding="async" alt="Earlier picture of ${escapeHtml(item.name)}" />`).join('')}</div></div>` : ''}
    </section>`;
  }

  function renderRemindItemsStrip() {
    const items = state.remindItems || [];
    const expanded = items.find(item => item.id === expandedRemindItemId);
    return `<section class="section memory-section">
      <div class="section-head"><div><h2>Remind items</h2><p class="subtle memory-section-subtitle">Remember where important items were left.</p></div><button class="link-button" data-route-link="items">Open all</button></div>
      <div class="memory-tile-strip">
        ${items.slice(0, 5).map(renderRemindItemTile).join('')}
        <button class="memory-tile add-memory-tile" data-action="add-memory-item"><span class="memory-tile-visual"><span class="memory-tile-icon">＋</span></span><span class="memory-tile-name">Add remembered item</span><small>Keys, glasses, tools…</small></button>
      </div>
      ${expanded ? renderRemindItemDetail(expanded, true) : ''}
    </section>`;
  }

  function renderRemindItems() {
    const items = state.remindItems || [];
    const expanded = items.find(item => item.id === expandedRemindItemId) || items[0] || null;
    if (expanded && !expandedRemindItemId) expandedRemindItemId = expanded.id;
    return `<div class="page-head">
      <div><div class="eyebrow">Item memory</div><h1>Remind items</h1><p class="subtle">Remember where important items were left.</p></div>
      <button class="btn primary no-print" data-action="add-memory-item">＋ Add remembered item</button>
    </div>
    ${items.length ? `<div class="memory-page-layout"><aside class="memory-page-list"><div class="memory-tile-grid">${items.map(renderRemindItemTile).join('')}</div></aside><div>${expanded ? renderRemindItemDetail(expanded) : ''}</div></div>` : `<div class="empty-state"><div class="empty-icon">🔑</div><b>No remembered items yet.</b><p>Add keys, glasses, tools, documents, or anything easy to misplace.</p><button class="btn primary" data-action="add-memory-item">＋ Add remembered item</button></div>`}`;
  }

  function renderTimeline() {
    const selectedDay = addLocalDays(new Date(), timelineDayOffset);
    const selectedKey = localDateKey(selectedDay);
    const hours = [];
    for (let h = state.profile.dayStartsAt; h <= state.profile.dayEndsAt; h++) {
      const display = h % 24;
      const entries = state.timeline.filter(entry => trackingDayKey(entry.start) === selectedKey && dayEntryHours(entry) === h);
      hours.push(`
        <div class="timeline-hour">
          <div class="timeline-label">${display === 0 ? '12 AM' : display < 12 ? `${display} AM` : display === 12 ? '12 PM' : `${display - 12} PM`}</div>
          <div class="timeline-slot" data-add-hour="${h}" role="button" tabindex="0" aria-label="Add activity at ${display === 0 ? '12 AM' : display < 12 ? `${display} AM` : display === 12 ? '12 PM' : `${display - 12} PM`}">
            ${entries.map(entry => `
              <button class="timeline-entry ${entry.source === 'suggested' ? 'suggested' : ''} ${entry.photoIds?.length ? 'photo-only' : ''}" data-entry="${entry.id}" style="width:100%;border-top:0;border-right:0;border-bottom:0;text-align:left">
                <b>${escapeHtml(entry.title)}</b>
                <small>${escapeHtml(entry.category)} · ${entry.source === 'suggested' ? `${entry.confidence}% confidence · confirm` : escapeHtml(entry.source)}</small>
              </button>`).join('')}
          </div>
        </div>`);
    }
    return `
      <div class="page-head">
        <div><div class="eyebrow">6:00 AM–3:00 AM</div><h1>Daily timeline</h1><p class="subtle">Confirmed activities, suggestions, photos, and gaps remain visibly different.</p></div>
        <button class="btn primary no-print" data-action="current">＋ Add activity</button>
      </div>
      <div class="chip-row no-print" style="margin-bottom:13px">
        <button class="chip ${timelineDayOffset === 0 ? 'active' : ''}" data-timeline-offset="0">Today</button><button class="chip ${timelineDayOffset === -1 ? 'active' : ''}" data-timeline-offset="-1">Yesterday</button><button class="chip ${timelineDayOffset === 1 ? 'active' : ''}" data-timeline-offset="1">Tomorrow</button>
      </div>
      <div class="card timeline">${hours.join('')}</div>
    `;
  }

  function renderCapture() {
    const visiblePhotos = state.photos.slice().reverse().slice(0, capturePhotoLimit);
    return `
      <div class="page-head">
        <div><div class="eyebrow">Capture first</div><h1>Record what happened</h1><p class="subtle">Save the time immediately. Details can be added later when your hands are free.</p></div>
      </div>
      <div class="grid two">
        <button class="card quick-action" style="min-height:170px" data-action="photo"><span style="font-size:42px">📷</span><h2 style="margin:0">Take a photo</h2><div class="subtle">Camera opens immediately</div></button>
        <button class="card quick-action" style="min-height:170px" data-action="quick-text"><span style="font-size:42px">✎</span><h2 style="margin:0">Quick text</h2><div class="subtle">A sentence or a few words</div></button>
        <button class="card quick-action" style="min-height:170px" data-action="voice"><span style="font-size:42px">🎙</span><h2 style="margin:0">Voice context</h2><div class="subtle">Dictate instead of typing</div></button>
        <button class="card quick-action" style="min-height:170px" data-action="current"><span style="font-size:42px">▶</span><h2 style="margin:0">Start an activity</h2><div class="subtle">Track duration from now</div></button>
      </div>
      <section class="section">
        <div class="section-head"><h2>Context inbox</h2><span class="badge warning">${contextualPhotos().length} waiting</span></div>
        ${state.photos.length ? `<div class="photo-grid">${visiblePhotos.map(renderPhotoCard).join('')}</div>${state.photos.length > visiblePhotos.length ? `<button class="btn ghost full no-print" data-action="load-older-photos" style="margin-top:12px">Load older photos (${state.photos.length - visiblePhotos.length} remaining)</button>` : ''}` : `<div class="empty-state"><div class="empty-icon">📷</div><b>No activity photos yet</b><p>Photos will be timestamped and placed here for optional context.</p></div>`}
      </section>
    `;
  }

  function renderPhotoCard(photo) {
    return `
      <button class="photo-card" data-photo="${photo.id}" style="padding:0;text-align:left;color:inherit">
        <img src="${photo.dataUrl}" loading="lazy" decoding="async" alt="Activity captured at ${escapeHtml(photo.timeLabel)}" />
        <div class="photo-info">
          <b>${escapeHtml(photo.category || 'Activity photo')}</b>
          <small>${escapeHtml(photo.timeLabel)}</small>
          ${photo.context ? `<div class="routine-meta">${escapeHtml(photo.context)}</div>` : `<div class="missing-context">See picture / add context</div>`}
        </div>
      </button>`;
  }

  function renderWeek() {
    const monday = startOfWeek();
    const days = [...Array(7)].map((_, index) => {
      const d = new Date(monday);
      d.setDate(d.getDate() + index);
      const base = Math.max(42, Math.min(100, completionStats().percent + (index - 3) * 4));
      return { d, completion: index > new Date().getDay() ? 0 : base };
    });
    return `
      <div class="page-head">
        <div><div class="eyebrow">Weekly planner</div><h1>This week</h1><p class="subtle">The familiar 6:00 AM–3:00 AM structure, summarized for quick review.</p></div>
        <button class="btn secondary no-print" data-action="prepare-week">Prepare next week</button>
      </div>
      <div class="card" style="overflow-x:auto">
        <table class="week-table">
          <thead><tr><th>Day</th><th>Completion</th><th>Photos</th><th>Needs review</th></tr></thead>
          <tbody>${days.map((day, i) => `
            <tr><td>${shortDay(day.d)} ${day.d.getDate()}</td><td><div class="progress"><span style="width:${day.completion}%"></span></div><small class="subtle">${day.completion}%</small></td><td>${i === 0 ? state.photos.length : Math.max(0, 2 - i)}</td><td>${i === 0 ? contextualPhotos().length + state.timeline.filter(e => e.source === 'suggested').length : Math.max(0, 2 - i)}</td></tr>
          `).join('')}</tbody>
        </table>
      </div>
      <section class="section">
        <div class="section-head"><h2>Habit overview</h2><button class="link-button" data-action="add-routine">Configure</button></div>
        <div class="grid two">
          ${state.routines.map(item => `
            <div class="card compact">
              <div style="display:flex;align-items:center;gap:11px"><div class="routine-icon">${item.icon}</div><div style="flex:1"><b>${escapeHtml(item.name)}</b><div class="routine-meta">Target ${item.target} · ${escapeHtml(item.schedule)}</div></div><span class="badge ${item.status === 'done' ? 'success' : 'warning'}">${item.status}</span></div>
            </div>`).join('')}
        </div>
      </section>
    `;
  }

  function reportTimelineEvents(report) {
    const updates = report.routineUpdates || [];
    const activities = report.entries.filter(entry => {
      if (!entry.routineId) return true;
      const entryTime = Date.parse(entry.start);
      return !updates.some(update => update.routineId === entry.routineId && Math.abs(Date.parse(update.at) - entryTime) < 90000);
    }).map(entry => ({
      id: entry.id,
      at: entry.start,
      title: entry.title,
      icon: state.routines.find(item => item.id === entry.routineId)?.icon || (entry.photoIds?.length ? '📷' : '•'),
      meta: `${entry.category || 'Other'} · ${entry.source || 'recorded'}${entry.notes ? ` · ${entry.notes}` : ''}`,
      source: entry.source || 'recorded',
      kind: 'activity',
    }));
    const trackerUpdates = updates.map(update => ({
      id: update.id,
      at: update.at,
      title: update.title,
      icon: update.icon || state.routines.find(item => item.id === update.routineId)?.icon || '✓',
      meta: `${update.action}${Number.isFinite(update.count) ? ` · ${update.count}/${update.target}` : ''}`,
      source: 'tracker',
      kind: 'update',
    }));
    return [...activities, ...trackerUpdates].sort((a, b) => Date.parse(a.at) - Date.parse(b.at));
  }

  function renderWeekTimeline(report) {
    const allEvents = reportTimelineEvents(report);
    const days = Array.from({ length: 7 }, (_, index) => addLocalDays(report.start, index));
    return `<section class="card section report-print-card week-timeline-card">
      <div class="section-head"><div><h2>Week timeline</h2><p class="subtle">The full week is grouped by your tracking day.</p></div><span class="badge">${allEvents.length}</span></div>
      <div class="week-timeline-list">${days.map(day => {
        const key = localDateKey(day);
        const events = allEvents.filter(event => trackingDayKey(event.at) === key);
        const label = day.toLocaleDateString(reportLocale(), { weekday: 'long', month: 'short', day: 'numeric' });
        return `<section class="week-timeline-day"><header><b>${escapeHtml(label)}</b><span>${events.length ? `${events.length} ${events.length === 1 ? 'entry' : 'entries'}` : 'No entries'}</span></header>${events.length ? `<div class="week-timeline-events">${events.map(event => {
          const date = new Date(event.at);
          const tracked = trackingDayDate(date);
          const nextDay = localDateKey(date) !== localDateKey(tracked);
          const sourceClass = event.source === 'suggested' ? 'warning' : event.source === 'tracker' ? '' : 'success';
          return `<div class="week-timeline-event"><time>${escapeHtml(timeLabel(date))}${nextDay ? `<small>next day</small>` : ''}</time><div class="week-timeline-dot">${escapeHtml(event.icon)}</div><div class="week-timeline-copy"><b>${escapeHtml(event.title)}</b><div class="routine-meta">${escapeHtml(event.meta)}</div></div><span class="badge ${sourceClass}">${event.source === 'tracker' ? 'Tracker updates' : escapeHtml(event.source)}</span></div>`;
        }).join('')}</div>` : '<div class="week-timeline-empty">No entries</div>'}</section>`;
      }).join('')}</div>
    </section>`;
  }

  function renderReportWeekNavigator(report) {
    const nextDisabled = report.isCurrent ? 'disabled aria-disabled="true"' : '';
    return `<section class="card report-week-nav no-print">
      <button class="week-nav-button" data-action="previous-report-week" aria-label="Previous week">←</button>
      <div class="week-nav-center">
        <div class="eyebrow">Report period</div>
        <strong>${escapeHtml(report.label)}</strong>
        <span class="badge ${report.isCurrent ? 'success' : ''}">${report.isCurrent ? 'This week' : 'Past week'}</span>
      </div>
      <button class="week-nav-button" data-action="next-report-week" aria-label="Next week" ${nextDisabled}>→</button>
    </section>`;
  }

  function renderReportMetrics(report) {
    const completion = report.archive?.completion;
    return `<div class="grid report-metrics">
      <div class="metric-card"><strong>${report.entries.length}</strong><small>Recorded activities</small></div>
      <div class="metric-card"><strong>${report.confirmationRate}%</strong><small>Confirmed records</small></div>
      <div class="metric-card"><strong>${report.contextRate}%</strong><small>Photo context</small></div>
      <div class="metric-card"><strong>${report.notes.length}</strong><small>Notes recorded</small></div>
      <div class="metric-card"><strong>${report.routineUpdates.length}</strong><small>Tracker updates</small></div>
      ${completion === undefined ? '' : `<div class="metric-card"><strong>${completion}%</strong><small>Archived weekly completion</small></div>`}
    </div>`;
  }

  function renderReports() {
    const report = buildWeekReport();
    const weeks = availableReportWeekKeys();
    return `
      <div class="page-head">
        <div><div class="eyebrow">Report library</div><h1>Weekly reports</h1><p class="subtle">Browse current and past weeks, then open a complete report before exporting.</p></div>
        <div class="chip-row no-print"><button class="btn secondary" data-action="export-csv">CSV</button><button class="btn primary" data-action="preview-report">Preview report</button></div>
      </div>

      ${renderReportWeekNavigator(report)}

      <section class="card section">
        <div class="section-head"><h2>${escapeHtml(report.label)}</h2>${report.isCurrent ? '' : '<button class="link-button no-print" data-action="current-report-week">This week</button>'}</div>
        ${renderReportMetrics(report)}
        ${!report.entries.length && report.archive ? '<div class="callout report-gap"><strong>No detailed activity records are available for this week.</strong>An archived summary is available, but this older demonstration week does not contain item-by-item records.</div>' : ''}
        ${!report.entries.length && !report.archive ? '<div class="empty-state report-gap"><div class="empty-icon">▤</div><b>No activity was recorded during this week.</b></div>' : ''}
      </section>

      ${renderWeekTimeline(report)}

      <div class="grid two section report-library-grid">
        <section class="card">
          <div class="section-head"><h2>Activity summary</h2><span class="subtle">${report.activitySummary.length} ${report.activitySummary.length === 1 ? 'type' : 'types'}</span></div>
          ${report.activitySummary.length ? `<div class="report-list">${report.activitySummary.slice(0, 8).map(item => `<div class="report-line"><div><b>${escapeHtml(item.title)}</b><div class="routine-meta">${escapeHtml(item.category)} · ${item.confirmed} confirmed${item.suggested ? ` · ${item.suggested} suggested` : ''}</div></div><b>${item.count}</b></div>`).join('')}</div>` : '<p class="subtle">No detailed activity records are available for this week.</p>'}
          <button class="btn secondary full no-print" style="margin-top:12px" data-action="preview-report">Preview report</button>
        </section>

        <section class="card">
          <div class="section-head"><h2>Past weeks</h2><span class="subtle">${weeks.length} weeks</span></div>
          <p class="subtle">Select any week to review its saved activity records and report summary.</p>
          <div class="report-history-list">${weeks.map(key => {
            const item = buildWeekReport(key);
            const selected = key === report.key;
            return `<button class="report-history-row ${selected ? 'active' : ''}" data-report-week="${key}">
              <span><b>${escapeHtml(item.label)}</b><small>${item.entries.length ? `${item.entries.length} records · ${item.photos.length} photos` : item.archive ? `${item.archive.completion}% complete · archived` : 'No records'}</small></span>
              <span aria-hidden="true">›</span>
            </button>`;
          }).join('')}</div>
        </section>
      </div>
    `;
  }

  function renderReportPreview() {
    const report = buildWeekReport();
    const lowSupplies = state.supplies.filter(item => item.state === 'low' || item.state === 'check');
    const generated = new Date().toLocaleString(reportLocale(), { dateStyle: 'medium', timeStyle: 'short' });
    const summary = report.entries.length
      ? `${state.profile.name} recorded ${report.entries.length} activit${report.entries.length === 1 ? 'y' : 'ies'} during this report period. ${report.confirmationRate}% of the records are confirmed. ${report.photos.length ? `${report.contextRate}% of photo records include written context.` : 'No photo evidence was captured.'}`
      : `${state.profile.name} has no detailed activity records for this report period.${report.archive ? ` The archived weekly completion value is ${report.archive.completion}%.` : ''}`;
    return `
      <div class="page-head report-preview-head">
        <div><button class="link-button no-print report-back" data-route-link="reports">← Back to reports</button><div class="eyebrow">Full report preview</div><h1>${escapeHtml(report.label)}</h1><p class="subtle">Report preview is based on timestamped local records. Review it before using it as a clinical document.</p></div>
        <div class="chip-row no-print"><button class="btn secondary" data-action="export-csv">CSV</button><button class="btn primary" data-action="print">Print / PDF</button></div>
      </div>

      ${renderReportWeekNavigator(report)}

      <article class="report-document">
        <header class="report-document-header">
          <div>${appLogoMarkup('report-logo')}<div><div class="eyebrow">Pocket OT</div><h2>Weekly activity report</h2></div></div>
          <div class="report-document-meta"><span><b>${escapeHtml(state.profile.name)}</b></span><span>Report period: ${escapeHtml(report.label)}</span><span>Generated: ${escapeHtml(generated)}</span></div>
        </header>

        <section class="card report-print-card">
          <h2>Week at a glance</h2>
          ${renderReportMetrics(report)}
          ${report.archive ? `<div class="archive-strip"><span>Archived weekly completion <b>${report.archive.completion}%</b></span><span>Confirmed <b>${report.archive.confirmed}%</b></span><span>Context complete <b>${report.archive.context}%</b></span></div>` : ''}
        </section>

        ${renderWeekTimeline(report)}

        ${!report.entries.length ? `<section class="${report.archive ? 'callout' : 'empty-state'} section"><strong>No detailed activity records are available for this week.</strong>${report.archive ? 'An archived summary is available, but this older demonstration week does not contain item-by-item records.' : 'No activity was recorded during this week.'}</section>` : ''}

        <section class="card section report-print-card">
          <div class="section-head"><h2>Detailed activity records</h2><span class="subtle">${report.entries.length} records</span></div>
          ${report.entries.length ? `<div class="report-list">${report.entries.map(entry => {
            const date = new Date(entry.start);
            const time = date.toLocaleString(reportLocale(), { weekday: 'short', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
            const sourceClass = entry.source === 'suggested' ? 'warning' : 'success';
            return `<div class="report-line report-detail-line"><div><b>${escapeHtml(entry.title)}</b><div class="routine-meta">${escapeHtml(time)} · ${escapeHtml(entry.category || 'Other')}${entry.notes ? ` · ${escapeHtml(entry.notes)}` : ''}</div></div><span class="badge ${sourceClass}">${escapeHtml(entry.source || 'recorded')}</span></div>`;
          }).join('')}</div>` : '<p class="subtle">No detailed activity records are available for this week.</p>'}
        </section>

        <div class="grid two section">
          <section class="card report-print-card">
            <div class="section-head"><h2>Activity summary</h2><span class="subtle">${report.activitySummary.length} types</span></div>
            ${report.activitySummary.length ? `<div class="report-list">${report.activitySummary.map(item => `<div class="report-line"><div><b>${escapeHtml(item.title)}</b><div class="routine-meta">${escapeHtml(item.category)} · ${item.confirmed} confirmed${item.suggested ? ` · ${item.suggested} suggested` : ''}</div></div><b>${item.count}</b></div>`).join('')}</div>` : '<p class="subtle">No activity was recorded during this week.</p>'}
          </section>
          <section class="card report-print-card">
            <div class="section-head"><h2>Notes recorded</h2><span class="subtle">${report.notes.length}</span></div>
            ${report.notes.length ? `<div class="report-list">${report.notes.map(note => `<div class="report-line"><div><b>${escapeHtml(note.text)}</b><div class="routine-meta">${escapeHtml(new Date(note.at).toLocaleString(reportLocale(), { weekday: 'short', hour: 'numeric', minute: '2-digit' }))} · ${escapeHtml(note.source || 'patient')}</div></div></div>`).join('')}</div>` : '<p class="subtle">No notes were recorded during this week.</p>'}
          </section>
        </div>

        <section class="card section report-print-card">
          <div class="section-head"><h2>Activity evidence</h2><span class="subtle">${report.photos.length} photos</span></div>
          ${report.photos.length ? `<div class="photo-grid">${report.photos.map(renderPhotoCard).join('')}</div>` : '<p class="subtle">No photo evidence was captured during this week.</p>'}
          ${report.missingPhotos.length ? `<div class="callout" style="margin-top:12px"><strong>Context still needed</strong>${report.missingPhotos.length} photo${report.missingPhotos.length === 1 ? '' : 's'} remain visibly labelled as missing context.</div>` : ''}
        </section>

        ${report.isCurrent ? `<section class="card section report-print-card"><h2>Current supply status</h2><p class="subtle">Supply status is shown only for the current week because earlier supply states were not historically snapshotted.</p><div class="report-list">${lowSupplies.map(item => `<div class="report-line"><div><b>${item.icon} ${escapeHtml(item.name)}</b><div class="routine-meta">${escapeHtml(item.note || 'Review supply')}</div></div><span class="badge warning">${item.state === 'low' ? 'Low' : 'Check'}</span></div>`).join('') || '<p class="subtle">No supply concerns recorded.</p>'}</div></section>` : ''}

        <section class="card section report-print-card">
          <h2>Automatically prepared summary</h2>
          <p>${escapeHtml(summary)}</p>
          <div class="callout"><strong>Clinician review required</strong>This summary is generated from patient-confirmed and visibly labelled unconfirmed records. Review before adding it to a patient file.</div>
        </section>
      </article>
    `;
  }

  function renderOTDashboard() {
    const patient = state.patients.find(p => p.id === state.selectedPatient) || state.patients[0];
    const missing = contextualPhotos().length;
    return `
      <div class="page-head">
        <div><div class="eyebrow">Care team workspace</div><h1>Patient review</h1><p class="subtle">Prioritize missing information, changes, and report readiness—not raw sensor noise.</p></div>
        <button class="btn primary" data-action="ot-report">Generate report</button>
      </div>
      <div class="ot-layout">
        <aside class="card">
          <div class="section-head"><h2>Patients</h2><span class="badge">${state.patients.length}</span></div>
          <div class="patient-list">${state.patients.map(p => `<button class="patient-item ${p.id === patient.id ? 'active' : ''}" data-patient="${p.id}"><b>${escapeHtml(p.name)}</b><small>${p.completion}% complete · ${p.missing} missing</small>${p.flags ? `<div style="margin-top:7px"><span class="badge warning">${p.flags} attention</span></div>` : ''}</button>`).join('')}</div>
        </aside>
        <section>
          <div class="card hero">
            <div class="hero-row"><div><div class="eyebrow" style="color:#cce3da">Selected patient</div><div class="hero-title" style="font-size:27px">${escapeHtml(patient.name)}</div><div class="subtle">Review due ${escapeHtml(patient.review)} · Assigned to ${escapeHtml(state.profile.therapist)}</div></div><div class="metric-card"><strong style="color:white">${patient.completion}%</strong><small style="color:rgba(255,255,255,.75)">weekly completion</small></div></div>
          </div>
          <div class="summary-strip">
            <div class="summary-stat"><b>${patient.missing}</b><span>missing entries</span></div>
            <div class="summary-stat"><b>${missing}</b><span>photos need context</span></div>
            <div class="summary-stat"><b>${patient.flags}</b><span>attention items</span></div>
            <div class="summary-stat"><b>81%</b><span>confirmed data</span></div>
          </div>
          <div class="grid two section">
            <div class="card">
              <div class="section-head"><h2>Needs review</h2><span class="badge warning">${missing + state.timeline.filter(e => e.source === 'suggested').length}</span></div>
              <div class="report-list">
                ${state.timeline.filter(e => e.source === 'suggested').map(e => `<div class="report-line"><div><b>${escapeHtml(e.title)}</b><div class="routine-meta">${e.confidence}% confidence · patient confirmation required</div></div><button class="btn small secondary" data-entry="${e.id}">Review</button></div>`).join('')}
                ${contextualPhotos().map(p => `<div class="report-line"><div><b>Photo at ${escapeHtml(p.timeLabel)}</b><div class="routine-meta">No patient context</div></div><button class="btn small secondary" data-photo="${p.id}">View</button></div>`).join('')}
                ${!missing && !state.timeline.some(e => e.source === 'suggested') ? '<p class="subtle">Nothing currently requires review.</p>' : ''}
              </div>
            </div>
            <div class="card">
              <h2>Weekly trend</h2>
              <div class="report-list">${state.weeklyHistory.map(w => `<div class="report-line"><div><b>Week of ${escapeHtml(w.week)}</b><div class="routine-meta">${w.confirmed}% confirmed · ${w.context}% context complete</div></div><b>${w.completion}%</b></div>`).join('')}</div>
            </div>
          </div>
          <section class="card section">
            <div class="section-head"><h2>Clinical report preview</h2><button class="link-button" data-action="ot-report">Open full report</button></div>
            <p>Routine completion is currently ${patient.completion}%. ${patient.missing} periods remain unconfirmed. ${missing ? `${missing} photo record${missing > 1 ? 's are' : ' is'} available without context and will appear as “see picture / add context.”` : 'All photo records include context.'}</p>
            <div class="callout"><strong>Source transparency</strong>Patient entries, therapist additions, calendar imports, and automatic suggestions retain separate provenance and audit history.</div>
          </section>
        </section>
      </div>
    `;
  }

  function bindRouteEvents() {
    $$('[data-route-link]').forEach(button => button.addEventListener('click', () => setRoute(button.dataset.routeLink)));
    $$('[data-report-week]').forEach(button => button.addEventListener('click', () => selectReportWeek(button.dataset.reportWeek)));
    $$('[data-memory-item]').forEach(button => button.addEventListener('click', () => {
      expandedRemindItemId = expandedRemindItemId === button.dataset.memoryItem && state.route === 'today' ? '' : button.dataset.memoryItem;
      render();
    }));
    $$('[data-timeline-offset]').forEach(button => button.addEventListener('click', () => { timelineDayOffset = Number(button.dataset.timelineOffset) || 0; render(); }));
    $$('[data-add-hour]').forEach(slot => {
      const open = event => {
        if (event.target.closest('[data-entry]')) return;
        if (event.type === 'keydown' && !['Enter',' '].includes(event.key)) return;
        event.preventDefault();
        const day = addLocalDays(new Date(), timelineDayOffset);
        day.setHours(Number(slot.dataset.addHour) % 24, 0, 0, 0);
        if (Number(slot.dataset.addHour) >= 24) day.setDate(day.getDate() + 1);
        openQuickText('', day);
      };
      slot.addEventListener('click', open);
      slot.addEventListener('keydown', open);
    });
    $$('[data-routine]').forEach(button => button.addEventListener('click', () => setRoutineStatus(button.dataset.routine, button.dataset.status)));
    $$('[data-routine-cycle]').forEach(button => button.addEventListener('click', () => cycleRoutine(button.dataset.routineCycle)));
    $$('[data-routine-count]').forEach(button => button.addEventListener('click', event => {
      event.stopPropagation();
      adjustRoutineCount(button.dataset.routineCount, Number(button.dataset.delta));
    }));
    $$('[data-photo]').forEach(button => button.addEventListener('click', () => openPhotoContext(button.dataset.photo)));
    $$('[data-entry]').forEach(button => button.addEventListener('click', () => openEntryReview(button.dataset.entry)));
    $$('[data-action]').forEach(button => button.addEventListener('click', () => handleAction(button.dataset.action, button.dataset)));
  }

  function bindOTEvents() {
    $$('[data-patient]').forEach(button => button.addEventListener('click', () => {
      state.selectedPatient = button.dataset.patient;
      save(); render();
    }));
    $$('[data-photo]').forEach(button => button.addEventListener('click', () => openPhotoContext(button.dataset.photo, true)));
    $$('[data-entry]').forEach(button => button.addEventListener('click', () => openEntryReview(button.dataset.entry, true)));
    $$('[data-action]').forEach(button => button.addEventListener('click', () => handleAction(button.dataset.action, button.dataset)));
  }

  function handleAction(action, dataset = {}) {
    const actions = {
      photo: () => { cameraInput.dataset.linked = dataset.linked || ''; cameraInput.click(); },
      'quick-text': () => openQuickText(dataset.linked),
      voice: openVoiceNote,
      current: openStartActivity,
      review: openReviewQueue,
      later: () => toast('Reminder snoozed for 30 minutes.'),
      'add-routine': openAddRoutine,
      'reorder-routines': openRoutineReorder,
      'add-memory-item': () => openRemindItemEditor(),
      'memory-photo': () => startRemindItemPhoto(dataset.memory, false),
      'memory-gallery': () => startRemindItemPhoto(dataset.memory, true),
      'edit-memory-item': () => openRemindItemEditor(dataset.memory),
      'delete-memory-item': () => deleteRemindItem(dataset.memory),
      'close-memory-item': () => { expandedRemindItemId = ''; render(); },
      'load-older-photos': () => { capturePhotoLimit += 120; render(); },
      'prepare-week': openPrepareWeek,
      'preview-report': () => setRoute('report-preview'),
      'previous-report-week': () => shiftReportWeek(-7),
      'next-report-week': () => shiftReportWeek(7),
      'current-report-week': () => selectReportWeek(weekStartKey()),
      print: printReport,
      'export-csv': exportCSV,
      'ot-report': () => { state.mode = 'patient'; state.route = 'reports'; save(); render(); },
    };
    actions[action]?.();
  }

  function recordRoutineUpdate(item, action) {
    const at = new Date();
    item.lastUpdatedAt = at.toISOString();
    state.routineUpdates.push({
      id: uid('routine-update'),
      routineId: item.id,
      at: at.toISOString(),
      title: item.name,
      icon: item.icon,
      action,
      status: item.status,
      count: Number(item.count) || 0,
      target: Number(item.target) || 1,
    });
  }

  function setRoutineStatus(id, status) {
    const item = state.routines.find(r => r.id === id);
    if (!item) return;
    item.status = status;
    if (status === 'done') item.count = item.target;
    recordRoutineUpdate(item, status === 'done' ? 'Marked done' : status === 'partial' ? 'Marked partial' : 'Marked pending');
    if (status === 'done') addTimelineFromRoutine(item);
    save(); render();
    toast(`${item.name} recorded as ${status}.`);
  }

  function updateCountRoutine(item) {
    item.count = Math.max(0, Number(item.count) || 0);
    item.target = Math.max(1, Number(item.target) || 1);
    item.status = item.count === 0 ? 'pending' : item.count >= item.target ? 'done' : 'partial';
    item.detail = `${item.count} of ${item.target} recorded`;
  }

  function addCountTimeline(item) {
    const start = new Date();
    const end = new Date(start.getTime() + 5 * 60000);
    state.timeline.push({
      id: uid('timeline'),
      routineId: item.id,
      countDelta: 1,
      start: start.toISOString(),
      end: end.toISOString(),
      title: item.name,
      category: item.type,
      source: 'confirmed',
      confidence: 100,
      notes: `Count ${item.count} of ${item.target}`,
    });
  }

  function removeLatestCountTimeline(item) {
    const today = localDateKey();
    for (let index = state.timeline.length - 1; index >= 0; index -= 1) {
      const entry = state.timeline[index];
      if (entry.routineId === item.id && entry.countDelta === 1 && localDateKey(new Date(entry.start)) === today) {
        state.timeline.splice(index, 1);
        return;
      }
    }
  }

  function adjustRoutineCount(id, delta) {
    const item = state.routines.find(routine => routine.id === id);
    if (!item || item.type !== 'count' || !Number.isFinite(delta) || delta === 0) return;
    if (delta > 0) {
      item.count = (Number(item.count) || 0) + 1;
      updateCountRoutine(item);
      recordRoutineUpdate(item, 'Added one');
      addCountTimeline(item);
    } else if ((Number(item.count) || 0) > 0) {
      item.count -= 1;
      updateCountRoutine(item);
      removeLatestCountTimeline(item);
    }
    save();
    render();
  }

  function cycleRoutine(id) {
    const item = state.routines.find(r => r.id === id);
    if (!item) return;
    if (item.type === 'count') {
      adjustRoutineCount(id, 1);
      return;
    } else if (item.type === 'medication') {
      openMedicationAction(item);
      return;
    } else {
      const undoing = item.status === 'done';
      item.status = undoing ? 'pending' : 'done';
      item.count = undoing ? 0 : item.target;
      if (undoing) {
        const todayKey = localDateKey();
        for (let index = state.timeline.length - 1; index >= 0; index -= 1) {
          const entry = state.timeline[index];
          if (entry.routineId === item.id && localDateKey(new Date(entry.start)) === todayKey) {
            state.timeline.splice(index, 1);
            break;
          }
        }
      } else {
        recordRoutineUpdate(item, 'Marked done');
        addTimelineFromRoutine(item);
      }
    }
    save(); render();
  }

  function addTimelineFromRoutine(item) {
    const exists = state.timeline.some(entry => entry.routineId === item.id && localDateKey(new Date(entry.start)) === localDateKey());
    if (exists) return;
    const start = new Date();
    const end = new Date(start.getTime() + 15 * 60000);
    state.timeline.push({ id: uid('timeline'), routineId: item.id, start: start.toISOString(), end: end.toISOString(), title: item.name, category: item.type, source: 'confirmed', confidence: 100, notes: 'Quick completion' });
  }

  function openModal(content) {
    modalRoot.innerHTML = `<div class="modal-backdrop" role="presentation"><div class="modal" role="dialog" aria-modal="true">${content}</div></div>`;
    applyTranslations(modalRoot);
    $('.modal-backdrop').addEventListener('click', event => { if (event.target.classList.contains('modal-backdrop')) closeModal(); });
    $$('[data-close]').forEach(button => button.addEventListener('click', closeModal));
  }

  function closeModal() {
    modalRoot.innerHTML = '';
    memoryEditorDraftPhoto = null;
    memoryEditorEditingId = '';
    cameraInput.dataset.remindDraft = '';
    galleryInput.dataset.remindDraft = '';
  }

  function modalHeader(title, subtitle = '') {
    return `<div class="modal-head"><div><h2>${escapeHtml(title)}</h2>${subtitle ? `<div class="subtle">${escapeHtml(subtitle)}</div>` : ''}</div><button class="close-button" data-close aria-label="Close">×</button></div>`;
  }

  function openQuickText(linkedId = '', presetStart = null) {
    const routine = state.routines.find(r => r.id === linkedId);
    const quickBase = presetStart instanceof Date && !Number.isNaN(presetStart.getTime()) ? new Date(presetStart) : new Date();
    openModal(`${modalHeader('Quick text', 'The current time is saved automatically.')}
      <form id="quickTextForm">
        <div class="form-group"><label for="quickCategory">Activity</label><select id="quickCategory" class="input">
          ${['Household task','Personal care','Eating','Medication','Work / school','Appointment','Transportation','Physical activity','Rest','Social','Leisure','Other'].map(c => `<option ${routine?.name.includes(c) ? 'selected' : ''}>${c}</option>`).join('')}
        </select></div>
        <div class="form-group"><label for="quickNote">What did you do?</label><textarea id="quickNote" class="input" placeholder="Example: Cleaned the kitchen counters and sink." required>${routine ? escapeHtml(routine.name) : ''}</textarea></div>
        <div class="form-row"><div class="form-group"><label for="quickStart">Start</label><input id="quickStart" class="input" type="time" value="${pad(quickBase.getHours())}:${pad(quickBase.getMinutes())}" /></div><div class="form-group"><label for="quickDuration">Duration</label><select id="quickDuration" class="input"><option value="15">15 min</option><option value="30" selected>30 min</option><option value="60">1 hour</option><option value="90">1.5 hours</option><option value="120">2 hours</option></select></div></div>
        <button class="btn primary full" type="submit">Save activity</button>
      </form>`);
    $('#quickTextForm').addEventListener('submit', event => {
      event.preventDefault();
      const [h, m] = $('#quickStart').value.split(':').map(Number);
      const start = new Date(quickBase); start.setHours(h, m, 0, 0);
      const end = new Date(start.getTime() + Number($('#quickDuration').value) * 60000);
      state.timeline.push({ id: uid('timeline'), start: start.toISOString(), end: end.toISOString(), title: $('#quickNote').value.trim(), category: $('#quickCategory').value, source: 'confirmed', confidence: 100, notes: '' });
      save(); closeModal(); setRoute('timeline'); toast('Activity saved at the correct time.');
    });
  }

  let browserVoiceRecognition = null;

  function voiceRecognitionLanguage() {
    return uiLanguage === 'fr-CA' ? 'fr-CA' : 'en-CA';
  }

  function voiceStatusText(stateName) {
    return ({
      permission: 'Requesting microphone permission…',
      starting: 'Starting voice recognition…',
      ready: 'Listening…',
      listening: 'Listening…',
      processing: 'Processing speech…',
      fallback: 'Switching to the phone speech service…',
      cancelled: 'Voice recognition cancelled.',
      complete: 'Voice recognition complete.',
    })[stateName] || '';
  }

  function updateVoiceModal(detail = {}) {
    const textArea = $('#voiceText');
    const status = $('#voiceStatus');
    if (!textArea || !status) return;
    if (detail.text) textArea.value = detail.text;
    if (detail.type === 'error') {
      status.textContent = detail.message || translateDynamic('Voice recognition could not start. You can type instead.');
      status.classList.add('error-text');
      toast(detail.message || 'Voice recognition could not start. You can type instead.');
    } else {
      status.classList.remove('error-text');
      status.textContent = translateDynamic(voiceStatusText(detail.state) || '');
    }
    const active = ['permission','starting','ready','listening','processing','fallback'].includes(detail.state);
    const startButton = $('#startVoice');
    const stopButton = $('#stopVoice');
    if (startButton) startButton.disabled = active;
    if (stopButton) stopButton.disabled = !active;
  }

  function stopBrowserVoice(cancel = false) {
    if (!browserVoiceRecognition) return;
    try { cancel ? browserVoiceRecognition.abort() : browserVoiceRecognition.stop(); } catch (error) { console.warn(error); }
    browserVoiceRecognition = null;
  }

  function openVoiceNote(options = {}) {
    const nativeSupported = isNativeApp && (() => {
      try { return !!nativeBridge?.isVoiceRecognitionAvailable?.(); } catch { return false; }
    })();
    const browserSupported = 'webkitSpeechRecognition' in window || 'SpeechRecognition' in window;
    const supported = nativeSupported || browserSupported;
    openModal(`${modalHeader('Voice context', supported ? 'Speak naturally; review the text before saving.' : 'Voice recognition is not available on this device.')}
      <div id="voiceStatus" class="callout" style="margin-bottom:12px">${supported ? '' : 'Voice recognition is not available on this device.'}</div>
      <div class="form-group"><label for="voiceText">Transcription</label><textarea id="voiceText" class="input" placeholder="Your spoken note will appear here."></textarea></div>
      <div class="form-row"><button id="startVoice" class="btn secondary" ${supported ? '' : 'disabled'}>🎙 Start listening</button><button id="stopVoice" class="btn ghost" disabled>■ Stop listening</button></div>
      <div class="form-row"><button id="cancelVoice" class="btn ghost">Cancel listening</button><button id="saveVoice" class="btn primary">Save note</button></div>`);

    const startListening = () => {
      if (!supported) return;
      if (nativeSupported) {
        updateVoiceModal({ state: 'starting' });
        nativeBridge.startVoiceRecognition(voiceRecognitionLanguage());
        return;
      }
      stopBrowserVoice(true);
      const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      const recognition = new Recognition();
      browserVoiceRecognition = recognition;
      recognition.lang = voiceRecognitionLanguage();
      recognition.interimResults = true;
      recognition.continuous = false;
      recognition.onstart = () => updateVoiceModal({ state: 'listening' });
      recognition.onresult = event => updateVoiceModal({
        type: event.results[event.results.length - 1]?.isFinal ? 'result' : 'partial',
        state: event.results[event.results.length - 1]?.isFinal ? 'complete' : 'listening',
        text: [...event.results].map(result => result[0].transcript).join(' '),
      });
      recognition.onerror = () => updateVoiceModal({ type: 'error', state: 'error', message: translateDynamic('Voice recognition could not start. You can type instead.') });
      recognition.onend = () => { browserVoiceRecognition = null; updateVoiceModal({ state: 'complete' }); };
      try { recognition.start(); } catch (error) { updateVoiceModal({ type: 'error', state: 'error', message: translateDynamic('Voice recognition could not start. You can type instead.') }); }
    };

    $('#startVoice').addEventListener('click', startListening);
    $('#stopVoice').addEventListener('click', () => {
      if (nativeSupported) nativeBridge.stopVoiceRecognition();
      else stopBrowserVoice(false);
      updateVoiceModal({ state: 'processing' });
    });
    $('#cancelVoice').addEventListener('click', () => {
      if (nativeSupported) nativeBridge.cancelVoiceRecognition();
      else stopBrowserVoice(true);
      updateVoiceModal({ state: 'cancelled' });
    });
    $('#saveVoice').addEventListener('click', () => {
      if (nativeSupported) nativeBridge.cancelVoiceRecognition();
      else stopBrowserVoice(true);
      const text = $('#voiceText').value.trim();
      if (!text) return toast('Add a voice or text note first.');
      const start = new Date();
      state.notes.push({ id: uid('note'), at: start.toISOString(), text, source: 'patient-voice' });
      state.timeline.push({ id: uid('timeline'), start: start.toISOString(), end: new Date(start.getTime() + 15 * 60000).toISOString(), title: text, category: 'Other', source: 'confirmed', confidence: 100, notes: 'Voice note' });
      save(); closeModal(); setRoute('timeline'); toast('Voice context saved.');
    });

    if (options.autoStart && supported) setTimeout(startListening, 180);
  }

  window.addEventListener('otPocketVoice', event => updateVoiceModal(event.detail || {}));

  function openStartActivity() {
    openModal(`${modalHeader('Start an activity', 'One tap now; stop it when you finish.')}
      <form id="startActivityForm">
        <div class="form-group"><label for="activityName">Activity</label><input id="activityName" class="input" placeholder="Example: Clean the kitchen" required /></div>
        <div class="form-group"><label for="activityCategory">Category</label><select id="activityCategory" class="input">${['Household task','Personal care','Eating','Work / school','Physical activity','Rest','Social','Leisure','Other'].map(c => `<option>${c}</option>`).join('')}</select></div>
        <button class="btn primary full" type="submit">▶ Start now</button>
      </form>`);
    $('#startActivityForm').addEventListener('submit', event => {
      event.preventDefault();
      const start = new Date();
      const entry = { id: uid('timeline'), start: start.toISOString(), end: new Date(start.getTime() + 5 * 60000).toISOString(), title: $('#activityName').value.trim(), category: $('#activityCategory').value, source: 'active', confidence: 100, notes: 'In progress' };
      state.timeline.push(entry); save(); closeModal();
      toast('Activity started. Tap the timeline entry when finished.');
      setRoute('timeline');
    });
  }

  function openMedicationAction(item) {
    openModal(`${modalHeader(item.name, `${item.schedule} · ${item.detail}`)}
      <div class="quick-grid">
        <button class="quick-action" data-med-action="taken"><span>✓</span>Taken</button>
        <button class="quick-action" data-med-action="snooze"><span>◷</span>Snooze</button>
        <button class="quick-action" data-med-action="skipped"><span>–</span>Skipped</button>
        <button class="quick-action" data-med-action="photo"><span>📷</span>Photo</button>
      </div>
      <p class="subtle" style="margin:14px 0 0">This records what the patient reports. A photograph does not automatically prove that medication was taken.</p>`);
    $$('[data-med-action]').forEach(button => button.addEventListener('click', () => {
      const action = button.dataset.medAction;
      if (action === 'photo') { cameraInput.dataset.linked = item.id; closeModal(); cameraInput.click(); return; }
      if (action === 'taken') { item.status = 'done'; item.count = 1; recordRoutineUpdate(item, 'Marked done'); addTimelineFromRoutine(item); }
      if (action === 'skipped') { item.status = 'partial'; item.detail = 'Skipped — reason not supplied'; recordRoutineUpdate(item, 'Marked partial'); }
      if (action === 'snooze') toast('Medication reminder snoozed for 15 minutes.');
      save(); closeModal(); render();
    }));
  }

  function memoryEditorPreviewMarkup(existing = null) {
    const latest = existing ? latestRemindItemPhoto(existing) : null;
    const preview = memoryEditorDraftPhoto || latest;
    const label = memoryEditorDraftPhoto ? 'Selected picture' : latest ? 'Current picture' : 'No picture selected';
    return `<div class="memory-editor-photo-preview ${preview ? 'has-photo' : ''}" id="memoryEditorPhotoPreview">
      ${preview ? `<img src="${preview.dataUrl}" alt="${escapeHtml(label)}" />` : `<div class="memory-editor-photo-empty"><span>📷</span></div>`}
      <div class="memory-editor-photo-caption"><b>${escapeHtml(label)}</b><small>${memoryEditorDraftPhoto ? 'This picture will be added when the item is saved.' : latest ? 'Choose another picture to add a newer one.' : 'A picture can make the item easier to recognize.'}</small></div>
    </div>`;
  }

  function refreshMemoryEditorPhotoPreview(existing = null) {
    if (!existing && memoryEditorEditingId) existing = state.remindItems.find(item => item.id === memoryEditorEditingId) || null;
    const preview = $('#memoryEditorPhotoPreview');
    if (!preview) return;
    const wrapper = document.createElement('div');
    wrapper.innerHTML = memoryEditorPreviewMarkup(existing);
    preview.replaceWith(wrapper.firstElementChild);
    const remove = $('#removeMemoryEditorPhoto');
    if (remove) remove.hidden = !memoryEditorDraftPhoto;
  }

  function openRemindItemEditor(id = '') {
    const existing = state.remindItems.find(item => item.id === id) || null;
    memoryEditorEditingId = existing?.id || '';
    memoryEditorDraftPhoto = null;
    openModal(`${modalHeader(existing ? 'Edit item' : 'Add remembered item', 'Save the last known location and an optional recognition photo.')}
      <form id="memoryItemForm">
        <div class="form-row"><div class="form-group"><label for="memoryItemName">Item name</label><input id="memoryItemName" class="input" value="${escapeHtml(existing?.name || '')}" placeholder="Keys" required /></div><div class="form-group"><label for="memoryItemIcon">Icon</label><input id="memoryItemIcon" class="input" value="${escapeHtml(existing?.icon || '🔑')}" maxlength="4" /></div></div>
        <div class="form-group"><label for="memoryItemLocation">Last known location</label><input id="memoryItemLocation" class="input" value="${escapeHtml(existing?.location || '')}" placeholder="Example: Entryway bowl" /></div>
        <div class="form-group"><label for="memoryItemNote">Notes</label><textarea id="memoryItemNote" class="input" placeholder="Optional details, backup location, or who moved it.">${escapeHtml(existing?.note || '')}</textarea></div>
        <div class="form-group memory-editor-photo-group">
          <label>Picture (optional)</label>
          <p class="subtle memory-editor-photo-help">Add a recognition picture now or leave it empty and add one later.</p>
          ${memoryEditorPreviewMarkup(existing)}
          <div class="form-row memory-editor-photo-actions">
            <button class="btn secondary" type="button" id="memoryEditorTakePhoto">📷 Take new photo</button>
            <button class="btn ghost" type="button" id="memoryEditorChoosePhoto">▧ Choose photo</button>
          </div>
          <button class="link-button memory-editor-remove-photo" type="button" id="removeMemoryEditorPhoto" ${memoryEditorDraftPhoto ? '' : 'hidden'}>Remove selected picture</button>
        </div>
        <button class="btn primary full" type="submit">Save item</button>
      </form>
      ${existing ? `<button class="btn danger full" style="margin-top:10px" id="deleteMemoryItem">Delete item</button>` : ''}`);

    $('#memoryEditorTakePhoto').addEventListener('click', () => {
      cameraInput.dataset.linked = '';
      cameraInput.dataset.linkedEntry = '';
      cameraInput.dataset.remindItem = '';
      cameraInput.dataset.remindDraft = '1';
      galleryInput.dataset.remindItem = '';
      galleryInput.dataset.remindDraft = '';
      cameraInput.click();
    });
    $('#memoryEditorChoosePhoto').addEventListener('click', () => {
      cameraInput.dataset.remindDraft = '';
      galleryInput.dataset.remindItem = '';
      galleryInput.dataset.remindDraft = '1';
      galleryInput.click();
    });
    $('#removeMemoryEditorPhoto').addEventListener('click', () => {
      memoryEditorDraftPhoto = null;
      refreshMemoryEditorPhotoPreview(existing);
    });

    $('#memoryItemForm').addEventListener('submit', event => {
      event.preventDefault();
      const at = new Date().toISOString();
      let item;
      if (existing) {
        item = existing;
        item.name = $('#memoryItemName').value.trim();
        item.icon = $('#memoryItemIcon').value.trim() || '📍';
        item.location = $('#memoryItemLocation').value.trim();
        item.note = $('#memoryItemNote').value.trim();
        item.updatedAt = at;
      } else {
        item = { id: uid('memory'), name: $('#memoryItemName').value.trim(), icon: $('#memoryItemIcon').value.trim() || '📍', location: $('#memoryItemLocation').value.trim(), note: $('#memoryItemNote').value.trim(), createdAt: at, updatedAt: at, photos: [] };
        state.remindItems.push(item);
      }
      if (memoryEditorDraftPhoto) {
        const captured = new Date(memoryEditorDraftPhoto.capturedAt || Date.now());
        addRemindItemPhoto(item, memoryEditorDraftPhoto.dataUrl, Number.isNaN(captured.getTime()) ? new Date() : captured);
      }
      expandedRemindItemId = item.id;
      memoryEditorDraftPhoto = null;
      save(); closeModal(); render(); toast('Remembered item saved.');
    });
    $('#deleteMemoryItem')?.addEventListener('click', () => deleteRemindItem(existing.id));
  }

  function deleteRemindItem(id) {
    const item = state.remindItems.find(entry => entry.id === id);
    if (!item) return;
    openModal(`${modalHeader('Delete item', `Remove ${escapeHtml(item.name)} and its saved local photos?`)}<div class="form-row"><button class="btn danger" id="confirmDeleteMemory">Delete item</button><button class="btn ghost" data-close>Cancel</button></div>`);
    $('#confirmDeleteMemory').addEventListener('click', () => {
      (item.photos || []).forEach(photo => deleteArchivedPhoto(photo.dataUrl));
      state.remindItems = state.remindItems.filter(entry => entry.id !== id);
      if (expandedRemindItemId === id) expandedRemindItemId = '';
      save(); closeModal(); render(); toast('Remembered item deleted.');
    });
  }

  function startRemindItemPhoto(id, fromGallery) {
    const item = state.remindItems.find(entry => entry.id === id);
    if (!item) return;
    cameraInput.dataset.linked = '';
    cameraInput.dataset.linkedEntry = '';
    cameraInput.dataset.remindItem = id;
    galleryInput.dataset.remindItem = id;
    (fromGallery ? galleryInput : cameraInput).click();
  }

  function addRemindItemPhoto(item, dataUrl, captured = new Date()) {
    item.photos = Array.isArray(item.photos) ? item.photos : [];
    const id = uid('memory-photo');
    item.photos.push({ id, dataUrl: archivePhotoData(dataUrl, id), capturedAt: captured.toISOString() });
    item.updatedAt = captured.toISOString();
    expandedRemindItemId = item.id;
  }

  function openRoutineReorder() {
    const rows = state.routines.map((item, index) => `<div class="report-line" data-reorder-row="${item.id}"><div><b>${escapeHtml(item.icon)} ${escapeHtml(item.name)}</b><div class="routine-meta">Position ${index + 1} of ${state.routines.length}</div></div><div class="chip-row"><button class="btn small ghost" data-move-routine="${item.id}" data-direction="-1" ${index === 0 ? 'disabled' : ''} aria-label="Move ${escapeHtml(item.name)} up">↑</button><button class="btn small ghost" data-move-routine="${item.id}" data-direction="1" ${index === state.routines.length - 1 ? 'disabled' : ''} aria-label="Move ${escapeHtml(item.name)} down">↓</button></div></div>`).join('');
    openModal(`${modalHeader('Reorder Today', 'Move items into the order that is easiest to scan and use.')}<div class="report-list">${rows || '<p class="subtle">No Today items yet.</p>'}</div><button class="btn primary full" data-close>Done</button>`);
    $$('[data-move-routine]').forEach(button => button.addEventListener('click', () => {
      const index = state.routines.findIndex(item => item.id === button.dataset.moveRoutine);
      const next = index + Number(button.dataset.direction);
      if (index < 0 || next < 0 || next >= state.routines.length) return;
      [state.routines[index], state.routines[next]] = [state.routines[next], state.routines[index]];
      save(); closeModal(); render(); openRoutineReorder();
    }));
  }

  function openAddRoutine() {
    openModal(`${modalHeader('Add a trackable item', 'Habits, medications, maintenance, meals, and one-time tasks use the same simple controls.')}
      <form id="routineForm">
        <div class="form-group"><label for="routineName">Name</label><input id="routineName" class="input" placeholder="Example: Feed the cat" required /></div>
        <div class="form-row"><div class="form-group"><label for="routineType">Type</label><select id="routineType" class="input"><option value="habit">Habit</option><option value="medication">Medication</option><option value="personal-care">Personal care</option><option value="meal">Meal</option><option value="maintenance">Maintenance</option><option value="task">One-time task</option><option value="count">Count</option></select></div><div class="form-group"><label for="routineIcon">Icon</label><input id="routineIcon" class="input" value="✓" maxlength="4" /></div></div>
        <div class="form-row"><div class="form-group"><label for="routineSchedule">When</label><input id="routineSchedule" class="input" placeholder="Morning, 8:00 AM, Tuesday…" /></div><div class="form-group"><label for="routineTarget">Times per day</label><input id="routineTarget" class="input" type="number" min="1" max="20" value="1" /></div></div>
        <button class="btn primary full" type="submit">Add to tracker</button>
      </form>
      <button class="btn secondary full" style="margin-top:9px" id="addMedicationDetailed">＋ Add medication with dosage and supply</button>`);
    $('#routineForm').addEventListener('submit', event => {
      event.preventDefault();
      const type = $('#routineType').value;
      const target = Math.max(1, Number($('#routineTarget').value) || 1);
      state.routines.push({
        id: uid('routine'),
        icon: $('#routineIcon').value || '✓',
        name: $('#routineName').value.trim(),
        type,
        schedule: $('#routineSchedule').value.trim() || 'Flexible',
        target,
        count: 0,
        status: 'pending',
        detail: type === 'count' ? `0 of ${target} recorded` : 'No details yet',
      });
      save(); closeModal(); render(); toast('Tracker item added.');
    });
    $('#addMedicationDetailed').addEventListener('click', openAddMedication);
  }

  function openAddMedication() {
    openModal(`${modalHeader('Add medication', 'Multiple medications and times are supported.')}
      <form id="medicationForm">
        <div class="form-group"><label for="medName">Medication label</label><input id="medName" class="input" placeholder="Use the label preferred by the patient" required /></div>
        <div class="form-row"><div class="form-group"><label for="medDose">Dosage label</label><input id="medDose" class="input" placeholder="Example: 1 tablet" /></div><div class="form-group"><label for="medTime">Reminder time</label><input id="medTime" class="input" type="time" value="08:00" /></div></div>
        <div class="form-row"><div class="form-group"><label for="medSupply">Supply remaining (days)</label><input id="medSupply" class="input" type="number" min="0" value="30" /></div><div class="form-group"><label for="medInstructions">Instructions shown</label><input id="medInstructions" class="input" placeholder="Example: With food" /></div></div>
        <button class="btn primary full" type="submit">Add medication</button>
      </form>`);
    $('#medicationForm').addEventListener('submit', event => {
      event.preventDefault();
      const medication = { id: uid('med'), name: $('#medName').value.trim(), dosage: $('#medDose').value.trim(), times: [$('#medTime').value], instructions: $('#medInstructions').value.trim(), supplyDays: Number($('#medSupply').value), active: true };
      state.medications.push(medication);
      state.routines.push({ id: uid('routine'), icon: '💊', name: medication.name, type: 'medication', schedule: formatTimeInput($('#medTime').value), target: 1, count: 0, status: 'pending', detail: [medication.dosage, medication.instructions].filter(Boolean).join(' · ') || 'Medication' });
      save(); closeModal(); render(); toast('Medication added.');
    });
  }

  function formatTimeInput(value) {
    const [h, m] = value.split(':').map(Number);
    const d = new Date(); d.setHours(h, m, 0, 0);
    return d.toLocaleTimeString(currentLocale(), { hour: 'numeric', minute: '2-digit' });
  }

  function bindLongPress(element, callback, delay = 520) {
    let timer = null;
    let held = false;
    const cancel = () => {
      if (timer) clearTimeout(timer);
      timer = null;
    };
    element.addEventListener('pointerdown', event => {
      if (event.pointerType === 'mouse' && event.button !== 0) return;
      const button = event.target.closest('button');
      if (event.target.closest('select, input, textarea') || (button && !button.classList.contains('supply-copy'))) return;
      held = false;
      timer = setTimeout(() => {
        held = true;
        element.dataset.longPressed = 'true';
        navigator.vibrate?.(18);
        callback();
      }, delay);
    });
    ['pointerup','pointercancel','pointerleave'].forEach(type => element.addEventListener(type, cancel));
    element.addEventListener('click', event => {
      if (held || element.dataset.longPressed === 'true') {
        event.preventDefault();
        event.stopPropagation();
        element.dataset.longPressed = '';
        held = false;
      }
    }, true);
  }

  function openSupplyEditor(id = '') {
    const item = state.supplies.find(supply => supply.id === id) || {
      id: uid('supply'),
      name: '',
      icon: '📦',
      state: 'check',
      note: '',
    };
    const isNew = !state.supplies.some(supply => supply.id === item.id);
    openModal(`${modalHeader(isNew ? 'Add preparation item' : 'Edit preparation item', 'View or change the item used in Prepare next week.')}
      <form id="supplyEditorForm">
        <div class="form-row">
          <div class="form-group"><label for="supplyIcon">Icon</label><input id="supplyIcon" class="input" value="${escapeHtml(item.icon || '📦')}" maxlength="4" /></div>
          <div class="form-group"><label for="supplyName">Item name</label><input id="supplyName" class="input" value="${escapeHtml(item.name)}" required /></div>
        </div>
        <div class="form-group"><label for="supplyState">Status</label><select id="supplyState" class="input"><option value="enough" ${item.state === 'enough' ? 'selected' : ''}>Enough</option><option value="low" ${item.state === 'low' ? 'selected' : ''}>Low</option><option value="check" ${item.state === 'check' ? 'selected' : ''}>Unsure</option></select></div>
        <div class="form-group"><label for="supplyNote">Note</label><textarea id="supplyNote" class="input" placeholder="Quantity, brand, store, refill details, or anything needed next week…">${escapeHtml(item.note || '')}</textarea></div>
        <div class="form-row">
          ${isNew ? '<span></span>' : '<button id="deleteSupply" class="btn danger" type="button">Delete item</button>'}
          <button class="btn primary" type="submit">Save item</button>
        </div>
      </form>`);
    $('#supplyEditorForm').addEventListener('submit', event => {
      event.preventDefault();
      item.icon = $('#supplyIcon').value.trim() || '📦';
      item.name = $('#supplyName').value.trim();
      item.state = $('#supplyState').value;
      item.note = $('#supplyNote').value.trim();
      if (isNew) state.supplies.push(item);
      save();
      openPrepareWeek();
      toast(isNew ? 'Preparation item added.' : 'Preparation item updated.');
    });
    $('#deleteSupply')?.addEventListener('click', () => {
      if (!confirm(`Delete ${item.name}?`)) return;
      state.supplies = state.supplies.filter(supply => supply.id !== item.id);
      save();
      openPrepareWeek();
      toast('Preparation item deleted.');
    });
  }

  function openPrepareWeek() {
    openModal(`${modalHeader('Prepare next week', 'Check supplies and turn anything low into a preparation task.')}
      <div class="section-head compact-head">
        <p class="subtle hold-hint">Tap and hold an item to view or edit it.</p>
        <button id="addSupplyItem" class="link-button" type="button">＋ Add preparation item</button>
      </div>
      <div id="supplyList" class="routine-list">${state.supplies.map(item => `
        <div class="routine-row supply-row" data-supply-hold="${item.id}">
          <div class="routine-icon">${item.icon}</div>
          <button class="supply-copy" type="button" data-edit-supply="${item.id}" aria-label="Edit ${escapeHtml(item.name)}">
            <div class="routine-title">${escapeHtml(item.name)}</div>
            <div class="routine-meta">${escapeHtml(item.note || 'No note')}</div>
          </button>
          <select class="input supply-state-select" data-supply="${item.id}" aria-label="${escapeHtml(item.name)} status"><option value="enough" ${item.state === 'enough' ? 'selected' : ''}>Enough</option><option value="low" ${item.state === 'low' ? 'selected' : ''}>Low</option><option value="check" ${item.state === 'check' ? 'selected' : ''}>Unsure</option></select>
        </div>`).join('')}</div>
      <div class="form-group" style="margin-top:14px"><label for="weekNote">Anything else needed next week?</label><textarea id="weekNote" class="input" placeholder="Appointments, transportation, groceries, refills, help needed…">${escapeHtml(prepareWeekDraftNote)}</textarea></div>
      <button id="savePreparation" class="btn primary full">Save preparation check</button>`);
    $('#weekNote')?.addEventListener('input', event => { prepareWeekDraftNote = event.target.value; });
    $$('[data-supply]').forEach(select => select.addEventListener('change', () => {
      const item = state.supplies.find(supply => supply.id === select.dataset.supply);
      if (item) {
        item.state = select.value;
        save();
      }
    }));
    $$('[data-edit-supply]').forEach(button => button.addEventListener('click', () => openSupplyEditor(button.dataset.editSupply)));
    $$('[data-supply-hold]').forEach(row => bindLongPress(row, () => openSupplyEditor(row.dataset.supplyHold)));
    $('#addSupplyItem').addEventListener('click', () => openSupplyEditor());
    $('#savePreparation').addEventListener('click', () => {
      const note = prepareWeekDraftNote.trim();
      if (note) state.notes.push({ id: uid('note'), at: new Date().toISOString(), text: note, source: 'weekly-preparation' });
      prepareWeekDraftNote = '';
      save(); closeModal(); render(); toast('Next-week preparation saved.');
    });
  }

  function openReviewQueue() {
    const suggestions = state.timeline.filter(e => e.source === 'suggested');
    const missing = contextualPhotos();
    openModal(`${modalHeader('Quick review', `${suggestions.length + missing.length} item${suggestions.length + missing.length === 1 ? '' : 's'} need attention.`)}
      <div class="report-list">
        ${suggestions.map(entry => `<div class="report-line"><div><b>${escapeHtml(entry.title)}</b><div class="routine-meta">${entry.confidence}% confidence · ${timeLabel(new Date(entry.start))}</div></div><button class="btn small secondary" data-review-entry="${entry.id}">Review</button></div>`).join('')}
        ${missing.map(photo => `<div class="report-line"><div><b>Photo at ${escapeHtml(photo.timeLabel)}</b><div class="routine-meta">Context not provided</div></div><button class="btn small secondary" data-review-photo="${photo.id}">Add context</button></div>`).join('')}
        ${!suggestions.length && !missing.length ? '<div class="empty-state"><div class="empty-icon">✓</div><b>Everything is reviewed</b></div>' : ''}
      </div>`);
    $$('[data-review-entry]').forEach(button => button.addEventListener('click', () => openEntryReview(button.dataset.reviewEntry)));
    $$('[data-review-photo]').forEach(button => button.addEventListener('click', () => openPhotoContext(button.dataset.reviewPhoto)));
  }

  function openEntryReview(id, otMode = false) {
    const entry = state.timeline.find(e => e.id === id);
    if (!entry) return;
    const start = new Date(entry.start);
    const originalDuration = Math.max(5 * 60000, Date.parse(entry.end || entry.start) - start.getTime());
    const categories = ['Household task','Personal care','Eating','Medication','Work / school','Appointment','Transportation','Physical activity','Rest','Social','Leisure','Other', entry.category].filter((value, index, array) => value && array.indexOf(value) === index);
    openModal(`${modalHeader(entry.title, 'Edit the recorded activity, time, context, or attached evidence.')}
      <div class="form-group"><label for="entryTitle">Activity</label><input id="entryTitle" class="input" value="${escapeHtml(entry.title)}" /></div>
      <div class="form-row"><div class="form-group"><label for="entryDate">Date</label><input id="entryDate" class="input" type="date" value="${localDateKey(start)}" /></div><div class="form-group"><label for="entryTime">Time</label><input id="entryTime" class="input" type="time" value="${pad(start.getHours())}:${pad(start.getMinutes())}" /></div></div>
      <div class="form-group"><label for="entryCategory">Context / category</label><select id="entryCategory" class="input">${categories.map(c => `<option ${c === entry.category ? 'selected' : ''}>${escapeHtml(c)}</option>`).join('')}</select></div>
      <div class="form-group"><label for="entryNotes">Notes / context</label><textarea id="entryNotes" class="input">${escapeHtml(entry.notes || '')}</textarea></div>
      ${(entry.photoIds || []).length ? `<div class="chip-row" style="margin-bottom:14px"><span class="badge">📷 ${(entry.photoIds || []).length} attached</span></div>` : ''}
      <div class="quick-grid">
        <button class="quick-action" data-entry-action="save"><span>✓</span>Save changes</button>
        <button class="quick-action" data-entry-action="photo"><span>📷</span>Add photo</button>
        <button class="quick-action" data-entry-action="remove"><span>×</span>Delete event</button>
      </div>`);
    $$('[data-entry-action]').forEach(button => button.addEventListener('click', () => {
      const action = button.dataset.entryAction;
      if (action === 'save') {
        entry.title = $('#entryTitle').value.trim() || entry.title;
        entry.notes = $('#entryNotes').value.trim();
        entry.category = $('#entryCategory').value;
        const [year, month, day] = $('#entryDate').value.split('-').map(Number);
        const [hour, minute] = $('#entryTime').value.split(':').map(Number);
        const nextStart = new Date(start);
        if ([year,month,day,hour,minute].every(Number.isFinite)) nextStart.setFullYear(year, month - 1, day), nextStart.setHours(hour, minute, 0, 0);
        entry.start = nextStart.toISOString();
        entry.end = new Date(nextStart.getTime() + originalDuration).toISOString();
        entry.source = otMode ? 'therapist-confirmed' : (entry.source === 'suggested' ? 'confirmed' : entry.source);
        entry.confidence = 100;
        (entry.photoIds || []).forEach(photoId => {
          const photo = state.photos.find(p => p.id === photoId);
          if (photo) { photo.category = entry.category; photo.capturedAt = entry.start; photo.timeLabel = timeLabel(nextStart); photo.dateLabel = dateLabel(nextStart); }
        });
      } else if (action === 'remove') {
        state.timeline = state.timeline.filter(e => e.id !== entry.id);
        state.photos.forEach(photo => { if (photo.timelineEntryId === entry.id) photo.timelineEntryId = ''; });
      } else if (action === 'photo') {
        cameraInput.dataset.linkedEntry = entry.id;
        closeModal(); cameraInput.click(); return;
      }
      save(); closeModal(); render(); toast(action === 'remove' ? 'Timeline event deleted.' : 'Timeline updated.');
    }));
  }

  function openPhotoContext(id, otMode = false) {
    const photo = state.photos.find(p => p.id === id);
    if (!photo) return;
    openModal(`${modalHeader('Activity photo', `${photo.timeLabel} · ${photo.dateLabel}`)}
      <img src="${photo.dataUrl}" alt="Captured activity" style="width:100%;max-height:340px;object-fit:contain;border-radius:15px;background:var(--surface-2);margin-bottom:14px" />
      <div class="form-group"><label for="photoCategory">Activity category</label><select id="photoCategory" class="input">${['Unclassified activity','Surface cleaning','Household task','Personal care','Eating','Medication','Work / school','Appointment','Transportation','Physical activity','Rest','Social','Leisure','Other'].map(c => `<option ${c === photo.category ? 'selected' : ''}>${c}</option>`).join('')}</select></div>
      <div class="form-group"><label for="photoContext">What was happening?</label><textarea id="photoContext" class="input" placeholder="Leave blank to show “see picture / add context” in the report.">${escapeHtml(photo.context || '')}</textarea></div>
      <div class="form-row"><button id="savePhotoContext" class="btn primary">Save context</button><button id="deletePhoto" class="btn danger">Delete photo</button></div>
      ${otMode ? '<p class="subtle" style="margin-top:12px">Context added here will be marked as therapist-added, not patient-provided.</p>' : ''}`);
    $('#savePhotoContext').addEventListener('click', () => {
      photo.category = $('#photoCategory').value;
      photo.context = $('#photoContext').value.trim();
      photo.contextSource = photo.context ? (otMode ? 'therapist' : 'patient') : 'missing';
      const linked = state.timeline.find(e => e.id === photo.timelineEntryId);
      if (linked && photo.context) { linked.title = photo.context; linked.category = photo.category; linked.notes = `Photo context supplied by ${photo.contextSource}`; }
      save(); closeModal(); render(); toast(photo.context ? 'Photo context saved.' : 'Photo kept without context.');
    });
    $('#deletePhoto').addEventListener('click', () => {
      deleteArchivedPhoto(photo.dataUrl);
      state.photos = state.photos.filter(p => p.id !== id);
      state.timeline.forEach(e => { if (e.photoIds) e.photoIds = e.photoIds.filter(pid => pid !== id); });
      save(); closeModal(); render(); toast('Photo removed.');
    });
  }

  async function fileToCompressedDataUrl(file) {
    const raw = await new Promise((resolve, reject) => {
      const reader = new FileReader(); reader.onload = () => resolve(reader.result); reader.onerror = reject; reader.readAsDataURL(file);
    });
    const image = await new Promise((resolve, reject) => {
      const img = new Image(); img.onload = () => resolve(img); img.onerror = reject; img.src = raw;
    });
    const max = 1280;
    const scale = Math.min(1, max / Math.max(image.width, image.height));
    const canvas = document.createElement('canvas');
    canvas.width = Math.round(image.width * scale); canvas.height = Math.round(image.height * scale);
    canvas.getContext('2d').drawImage(image, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL('image/jpeg', .78);
  }

  function addPhotoRecord(dataUrl, captured = new Date(), linkedRoutine = null, linkedEntry = null) {
    const id = uid('photo');
    const photo = {
      id,
      capturedAt: captured.toISOString(),
      timeLabel: timeLabel(captured),
      dateLabel: dateLabel(captured),
      dataUrl: archivePhotoData(dataUrl, id),
      category: linkedRoutine?.name || linkedEntry?.category || 'Unclassified activity',
      context: '',
      contextSource: 'missing',
      timelineEntryId: linkedEntry?.id || '',
    };
    state.photos.push(photo);
    if (linkedEntry) {
      linkedEntry.photoIds = [...(linkedEntry.photoIds || []), photo.id];
    } else {
      const end = new Date(captured.getTime() + 15 * 60000);
      const entry = { id: uid('timeline'), start: captured.toISOString(), end: end.toISOString(), title: linkedRoutine?.name || 'Activity photo', category: photo.category, source: 'photo', confidence: 100, notes: 'Context not provided — see picture / add context', photoIds: [photo.id] };
      state.timeline.push(entry);
      photo.timelineEntryId = entry.id;
    }
    if (linkedRoutine) {
      linkedRoutine.status = linkedRoutine.status === 'done' ? 'done' : 'partial';
      linkedRoutine.detail = 'Photo recorded · completion not yet confirmed';
    }
    return photo;
  }

  function finishPhotoCapture(photo) {
    cameraInput.value = '';
    galleryInput.value = '';
    cameraInput.dataset.linked = '';
    cameraInput.dataset.linkedEntry = '';
    cameraInput.dataset.remindItem = '';
    galleryInput.dataset.remindItem = '';
    cameraInput.dataset.remindDraft = '';
    galleryInput.dataset.remindDraft = '';
    save();
    render();
    toast('Photo timestamped. Context can be added now or later.');
    if (photo) openPhotoContext(photo.id);
  }

  async function handlePhotoFiles(files) {
    const isMemoryEditorDraft = cameraInput.dataset.remindDraft === '1' || galleryInput.dataset.remindDraft === '1';
    if (isMemoryEditorDraft) {
      const file = files[0];
      if (file) {
        try {
          memoryEditorDraftPhoto = { dataUrl: await fileToCompressedDataUrl(file), capturedAt: new Date().toISOString() };
          refreshMemoryEditorPhotoPreview();
          toast('Picture selected. It will be saved with the item.');
        } catch (error) {
          console.error(error);
          toast('A photo could not be processed.');
        }
      }
      cameraInput.value = '';
      galleryInput.value = '';
      cameraInput.dataset.remindDraft = '';
      galleryInput.dataset.remindDraft = '';
      return;
    }
    const remindItemId = cameraInput.dataset.remindItem || galleryInput.dataset.remindItem || '';
    if (remindItemId) {
      const item = state.remindItems.find(entry => entry.id === remindItemId);
      if (!item) return;
      for (const file of files) {
        try { addRemindItemPhoto(item, await fileToCompressedDataUrl(file), new Date()); }
        catch (error) { console.error(error); toast('A photo could not be processed.'); }
      }
      cameraInput.value = '';
      galleryInput.value = '';
      cameraInput.dataset.remindItem = '';
      galleryInput.dataset.remindItem = '';
      cameraInput.dataset.remindDraft = '';
      galleryInput.dataset.remindDraft = '';
      state.route = 'items';
      save(); render(); toast('Remembered item photo saved.');
      return;
    }
    let latest = null;
    for (const file of files) {
      try {
        const captured = new Date();
        const dataUrl = await fileToCompressedDataUrl(file);
        const linkedRoutine = state.routines.find(r => r.id === cameraInput.dataset.linked);
        const linkedEntry = state.timeline.find(e => e.id === cameraInput.dataset.linkedEntry);
        latest = addPhotoRecord(dataUrl, captured, linkedRoutine, linkedEntry);
      } catch (error) {
        console.error(error);
        toast('A photo could not be processed.');
      }
    }
    finishPhotoCapture(latest);
  }

  window.OTPocketReceiveNativePhoto = (dataUrl, capturedAt) => {
    try {
      const captured = capturedAt ? new Date(capturedAt) : new Date();
      const photo = addPhotoRecord(dataUrl, Number.isNaN(captured.getTime()) ? new Date() : captured);
      state.mode = 'patient';
      state.route = 'capture';
      finishPhotoCapture(photo);
    } catch (error) {
      console.error(error);
      toast('The Android photo could not be added.');
    }
  };

  function printReport() {
    const report = buildWeekReport();
    const jobName = `Pocket OT weekly report - ${report.label}`;
    document.body.classList.add('printing-report');
    const cleanup = () => document.body.classList.remove('printing-report');
    requestAnimationFrame(() => {
      try {
        if (isNativeApp && nativeBridge?.printCurrentReport) {
          toast('Opening Android print and Save as PDF…');
          nativeBridge.printCurrentReport(jobName);
          setTimeout(cleanup, 1800);
          return;
        }
        window.print();
      } catch (error) {
        console.error(error);
        toast('Print / PDF could not open.');
      } finally {
        if (!isNativeApp) setTimeout(cleanup, 300);
      }
    });
  }

  function exportCSV() {
    const contentLanguage = reportLanguage();
    const localize = value => translateDynamic(value, contentLanguage);
    const report = buildWeekReport();
    const rows = [[localize('Date'),localize('Start'),localize('Activity'),localize('Category'),localize('Source'),localize('Context')]];
    reportTimelineEvents(report).forEach(entry => rows.push([
      trackingDayKey(entry.at),
      timeLabel(new Date(entry.at)),
      entry.title,
      entry.kind === 'update' ? localize('Tracker updates') : 'Activity',
      entry.source,
      entry.meta || '',
    ]));
    const csv = rows.map(row => row.map(value => `"${String(value).replace(/"/g, '""')}"`).join(',')).join('\n');
    downloadBlob(new Blob([csv], { type: 'text/csv;charset=utf-8' }), `ot-pocket-week-${report.key}.csv`);
  }

  function exportBackup() {
    if (isNativeApp && nativeBridge?.exportFullBackup) {
      try {
        const fileName = `ot-pocket-backup-${localDateKey()}.zip`;
        const result = nativeBridge.exportFullBackup(fileName, JSON.stringify(state));
        if (!result) throw new Error('Native full backup failed.');
        toast('Full backup saved to Downloads / Pocket OT.');
        return;
      } catch (error) {
        console.error(error);
        toast('Full backup could not be saved.');
        return;
      }
    }
    downloadBlob(new Blob([JSON.stringify(state, null, 2)], { type: 'application/json' }), `ot-pocket-backup-${localDateKey()}.json`);
  }

  function looksLikePocketOtState(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
    const markers = [
      'profile', 'settings', 'routines', 'medications', 'routineUpdates',
      'remindItems', 'timeline', 'photos', 'notes', 'supplies',
      'weeklyHistory', 'patients', 'setupCompleted', 'dataModelVersion'
    ];
    return markers.some(key => Object.prototype.hasOwnProperty.call(value, key));
  }

  function unwrapPocketOtBackup(value) {
    let parsed = value;
    // Some export/share tools double-encode JSON as a quoted JSON string.
    for (let depth = 0; depth < 2 && typeof parsed === 'string'; depth += 1) {
      const text = parsed.replace(/^\uFEFF/, '').trim();
      if (!text) throw new Error('Backup file is empty.');
      parsed = JSON.parse(text);
    }
    if (looksLikePocketOtState(parsed)) return parsed;

    // Accept wrapper formats used by generic backup/export utilities.
    for (const key of ['state', 'data', 'profileData', 'pocketOt', 'pocketOT']) {
      let candidate = parsed?.[key];
      if (typeof candidate === 'string') {
        try { candidate = JSON.parse(candidate.replace(/^\uFEFF/, '').trim()); } catch (_) { candidate = null; }
      }
      if (looksLikePocketOtState(candidate)) return candidate;
    }

    // Last-resort compatibility: find one nested object/string that is clearly Pocket OT state.
    if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
      for (const candidateRaw of Object.values(parsed)) {
        let candidate = candidateRaw;
        if (typeof candidate === 'string' && candidate.trim().startsWith('{')) {
          try { candidate = JSON.parse(candidate.replace(/^\uFEFF/, '').trim()); } catch (_) { continue; }
        }
        if (looksLikePocketOtState(candidate)) return candidate;
      }
    }
    throw new Error('File does not look like Pocket OT backup data.');
  }

  function normalizeImportedPocketOtState(source) {
    // Clone so compatibility normalization never mutates the FileReader object directly.
    const parsed = JSON.parse(JSON.stringify(source));
    const arrayFields = [
      'routines', 'medications', 'routineUpdates', 'remindItems', 'timeline',
      'photos', 'notes', 'supplies', 'weeklyHistory', 'patients'
    ];
    arrayFields.forEach(key => {
      if (!Array.isArray(parsed[key])) parsed[key] = [];
    });
    parsed.remindItems = parsed.remindItems.map(item => ({
      ...(item && typeof item === 'object' ? item : {}),
      photos: Array.isArray(item?.photos) ? item.photos : [],
    }));
    if (!parsed.profile || typeof parsed.profile !== 'object' || Array.isArray(parsed.profile)) parsed.profile = {};
    if (!parsed.settings || typeof parsed.settings !== 'object' || Array.isArray(parsed.settings)) parsed.settings = {};

    // Old exports predate these flags. Do not accidentally turn a real imported
    // profile into the Alex demonstration profile just because a flag is absent.
    if (parsed.isDemo === undefined) parsed.isDemo = false;
    if (parsed.setupCompleted === undefined) {
      parsed.setupCompleted = !!(parsed.profile.name || parsed.profile.preferredName || parsed.routines.length || parsed.timeline.length || parsed.photos.length);
    }
    parsed.legacyDetected = false;
    return parsed;
  }

  async function importBackupFile(file) {
    if (!file) return;
    const previousState = state;
    const previousLanguage = uiLanguage;
    try {
      const raw = (await file.text()).replace(/^\uFEFF/, '').trim();
      if (!raw) throw new Error('Backup file is empty.');
      if (raw.startsWith('PK\u0003\u0004')) {
        throw new Error('This is a ZIP backup. Use the full ZIP restore option in a newer Pocket OT build.');
      }
      let decoded;
      try {
        decoded = JSON.parse(raw);
      } catch (parseError) {
        throw new Error(`Invalid JSON: ${parseError.message || 'could not parse file'}`);
      }
      const parsed = normalizeImportedPocketOtState(unwrapPocketOtBackup(decoded));
      const migrated = migrateEmbeddedPhotos(parsed);
      const restored = hydrateState(parsed);
      state = restored;
      uiLanguage = normalizeLanguage(state.settings?.appLanguage || PHONE_LANGUAGE);
      if (!save()) {
        state = previousState;
        uiLanguage = previousLanguage;
        throw new Error('Restored state could not be saved to native storage.');
      }
      render();
      const entryCount = (state.timeline?.length || 0) + (state.routineUpdates?.length || 0);
      const photoCount = state.photos?.length || 0;
      toast(`Pocket OT backup restored · ${entryCount} entries · ${photoCount} photos${migrated ? ` · ${migrated} photos migrated` : ''}.`);
    } catch (error) {
      state = previousState;
      uiLanguage = previousLanguage;
      console.error(error);
      const reason = String(error?.message || 'Unknown restore error').slice(0, 180);
      toast(`Backup not loaded: ${reason} Current profile was not replaced.`);
    } finally {
      backupInput.value = '';
    }
  }

  function downloadBlob(blob, name) {
    if (isNativeApp && nativeBridge?.saveBase64File) {
      const reader = new FileReader();
      reader.onloadend = () => {
        try {
          nativeBridge.saveBase64File(name, blob.type || 'application/octet-stream', reader.result);
          toast('Export saved to Downloads / Pocket OT.');
        } catch (error) {
          console.error(error);
          toast('The Android export could not be saved.');
        }
      };
      reader.readAsDataURL(blob);
      return;
    }
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a'); anchor.href = url; anchor.download = name; anchor.click();
    setTimeout(() => URL.revokeObjectURL(url), 500);
  }


  function openProfileEditor() {
    openModal(`${modalHeader('Profile', 'Identity and planner settings used throughout reports and greetings.')}
      <form id="profileForm">
        <div class="form-group"><label for="profileName">Full name or patient label</label><input id="profileName" class="input" value="${escapeHtml(state.profile.name)}" required /></div>
        <div class="form-group"><label for="profilePreferredName">Preferred first name</label><input id="profilePreferredName" class="input" value="${escapeHtml(state.profile.preferredName || '')}" /></div>
        <div class="form-group"><label for="profileMode">Profile use</label><select id="profileMode" class="input"><option value="personal" ${state.profile.useMode === 'personal' ? 'selected' : ''}>Personal use</option><option value="ot" ${state.profile.useMode === 'ot' ? 'selected' : ''}>Working with an OT</option></select></div>
        <div class="form-group"><label for="profileTherapist">Occupational therapist / center</label><input id="profileTherapist" class="input" value="${escapeHtml(state.profile.therapist || '')}" /></div>
        <div class="form-row"><div class="form-group"><label for="profileDayStart">Day begins</label><select id="profileDayStart" class="input">${plannerHourOptions(state.profile.dayStartsAt)}</select></div><div class="form-group"><label for="profileDayEnd">Day ends</label><select id="profileDayEnd" class="input">${plannerHourOptions(state.profile.dayEndsAt, true)}</select></div></div>
        <button class="btn primary full" type="submit">Save profile</button>
      </form>`);
    $('#profileForm').addEventListener('submit', event => {
      event.preventDefault();
      const oldName = state.profile.name;
      state.profile.name = $('#profileName').value.trim();
      state.profile.preferredName = $('#profilePreferredName').value.trim() || state.profile.name.split(/\s+/)[0];
      state.profile.useMode = $('#profileMode').value;
      state.profile.therapist = $('#profileTherapist').value.trim() || (state.profile.useMode === 'personal' ? 'Personal use' : 'Not assigned');
      state.profile.dayStartsAt = Number($('#profileDayStart').value);
      state.profile.dayEndsAt = Number($('#profileDayEnd').value);
      const localPatient = state.patients.find(patient => patient.id === state.profile.id) || state.patients.find(patient => patient.local) || state.patients.find(patient => patient.name === oldName);
      if (localPatient) localPatient.name = state.profile.name;
      state.isDemo = false;
      save(); closeModal(); render(); toast('Profile updated.');
    });
  }

  function restartProfileSetup() {
    if (!confirm('Start a new profile? Export a backup first if you need the current local data.')) return;
    try { nativeBridge?.clearPhotoArchive?.(); } catch (error) { console.warn(error); }
    state = buildInitialState();
    onboardingDraft = {
      name: '', preferredName: '', useMode: 'personal', therapist: '', dayStartsAt: 6, dayEndsAt: 27,
      reminders: true, missingEntryPrompts: true, photoContextReminder: true, quickCaptureNotification: false,
      routines: ['teethMorning', 'teethEvening', 'shower', 'meals', 'water', 'surface', 'litterbox', 'weekPrep'],
      medicationName: '', medicationDose: '', medicationTime: '08:00', language: normalizeLanguage(state.settings?.appLanguage || PHONE_LANGUAGE),
    };
    onboardingStep = 1;
    save(); closeModal(); render();
  }

  function formatStorageBytes(value) {
    const bytes = Math.max(0, Number(value) || 0);
    if (bytes < 1024) return `${Math.round(bytes)} B`;
    if (bytes < 1024 ** 2) return `${(bytes / 1024).toFixed(1)} KB`;
    if (bytes < 1024 ** 3) return `${(bytes / 1024 ** 2).toFixed(1)} MB`;
    return `${(bytes / 1024 ** 3).toFixed(2)} GB`;
  }

  function nativePhotoArchiveStatus() {
    if (!isNativeApp || !nativeBridge?.getPhotoArchiveStats) return '';
    try {
      const stats = JSON.parse(nativeBridge.getPhotoArchiveStats() || '{}');
      return `<div class="callout"><strong>Photo archive</strong>${Number(stats.count || 0).toLocaleString(currentLocale())} saved photo${Number(stats.count || 0) === 1 ? '' : 's'} · ${formatStorageBytes(stats.bytes)} used · ${formatStorageBytes(stats.freeBytes)} device space available.</div>`;
    } catch (error) {
      console.warn('Could not read photo archive statistics', error);
      return '';
    }
  }

  function settingsNativeControls(exactAlarmReady) {
    return isNativeApp ? `
      <button id="quickNotificationButton" class="btn secondary">${state.settings.quickCaptureNotification ? 'Refresh quick notification' : 'Show quick notification'}</button>
      <button id="hideQuickNotificationButton" class="btn ghost">Hide quick notification</button>
      <button id="testReminderButton" class="btn secondary">Test reminder in 1 minute</button>
      <button id="exactAlarmButton" class="btn ghost">${exactAlarmReady ? 'Exact alarms ready' : 'Allow exact alarms'}</button>` : `
      <button id="installButton" class="btn ghost">Install app</button>`;
  }

  function renderSettings() {
    const exactAlarmReady = isNativeApp ? (() => { try { return nativeBridge.canScheduleExactAlarms(); } catch { return false; } })() : false;
    const nativeButtons = settingsNativeControls(exactAlarmReady);
    const archiveStatus = nativePhotoArchiveStatus();
    const foundation = isNativeApp
      ? `<div class="callout settings-foundation"><strong>Android foundation active</strong>Offline app files, private local storage, native voice recognition, hourly check-ins, camera capture, actionable notifications, alarm restoration after reboot, and Android Downloads export are enabled. Passive activity recognition and clinic synchronization remain later production layers.</div>`
      : `<div class="callout settings-foundation"><strong>Web mode</strong>Install the Android APK for native reminders, camera shortcuts, reboot recovery, and offline operation without a PC.</div>`;

    return `<section class="settings-page">
      <div class="settings-page-head">
        <div><div class="eyebrow">Preferences</div><h1>Settings</h1><p class="subtle">Profile, languages, reminders, notifications, and local data.</p></div>
      </div>

      <div class="settings-layout">
        <section class="card settings-card settings-profile-card">
          <div class="settings-section-head"><div><h2>Profile & planner</h2><p class="subtle">Identity and schedule used throughout the app.</p></div></div>
          <div class="profile-summary"><div class="profile-avatar">${escapeHtml((state.profile.preferredName || state.profile.name || '?').slice(0,1).toUpperCase())}</div><div><b>${escapeHtml(state.profile.name)}</b><div class="routine-meta">${state.isDemo ? 'Demonstration profile' : (state.profile.useMode === 'ot' ? `Working with ${escapeHtml(state.profile.therapist)}` : 'Personal profile')}</div></div><button id="editProfileButton" class="btn small secondary">Edit</button></div>
        </section>

        <section class="card settings-card">
          <div class="settings-section-head"><div><h2>Languages</h2><p class="subtle">Choose app, report, and notification languages independently.</p></div></div>
          <div class="settings-language-block">
            <div class="form-group"><label for="appLanguage">App language</label><select id="appLanguage" class="input"><option value="en" ${uiLanguage === 'en' ? 'selected' : ''}>English</option><option value="fr-CA" ${uiLanguage === 'fr-CA' ? 'selected' : ''}>Français (Canada)</option></select></div>
            <div class="form-row"><div class="form-group"><label for="reportLanguage">Report language</label><select id="reportLanguage" class="input"><option value="app" ${state.settings.reportLanguage === 'app' ? 'selected' : ''}>Follow app language</option><option value="en" ${state.settings.reportLanguage === 'en' ? 'selected' : ''}>English</option><option value="fr-CA" ${state.settings.reportLanguage === 'fr-CA' ? 'selected' : ''}>Français (Canada)</option></select></div><div class="form-group"><label for="notificationLanguage">Notification language</label><select id="notificationLanguage" class="input"><option value="app" ${state.settings.notificationLanguage === 'app' ? 'selected' : ''}>Follow app language</option><option value="en" ${state.settings.notificationLanguage === 'en' ? 'selected' : ''}>English</option><option value="fr-CA" ${state.settings.notificationLanguage === 'fr-CA' ? 'selected' : ''}>Français (Canada)</option></select></div></div>
          </div>
        </section>

        <section class="card settings-card">
          <div class="settings-section-head"><div><h2>Routine prompts</h2><p class="subtle">Control how often Pocket OT asks for missing information.</p></div></div>
          <div class="settings-switch-list">
            <div class="switch-row"><div><b>Reminders</b><div class="routine-meta">Scheduled routine prompts</div></div><button class="switch ${state.settings.reminders ? 'on' : ''}" data-setting="reminders" aria-label="Toggle reminders"></button></div>
            <div class="switch-row"><div><b>Ask about missing periods</b><div class="routine-meta">Targeted prompts only when useful</div></div><button class="switch ${state.settings.missingEntryPrompts ? 'on' : ''}" data-setting="missingEntryPrompts" aria-label="Toggle missing entry prompts"></button></div>
            <div class="switch-row"><div><b>Photo context reminder</b><div class="routine-meta">Review unlabeled photos later</div></div><button class="switch ${state.settings.photoContextReminder ? 'on' : ''}" data-setting="photoContextReminder" aria-label="Toggle photo context prompts"></button></div>
          </div>
        </section>

        <section class="card settings-card settings-hourly-card">
          <div class="settings-section-head"><div><h2>Hourly activity check-ins</h2><p class="subtle">Ask what is happening throughout the active day.</p></div><button class="switch ${state.settings.hourlyCheckIns ? 'on' : ''}" data-setting="hourlyCheckIns" aria-label="Toggle hourly activity check-ins" ${isNativeApp ? '' : 'disabled'}></button></div>
          <div id="hourlySettingsPanel" class="hourly-settings-panel ${state.settings.hourlyCheckIns ? '' : 'hidden'}">
            <div class="form-group"><label for="hourlyInterval">Check-in frequency</label><select id="hourlyInterval" class="input"><option value="30" ${Number(state.settings.hourlyIntervalMinutes) === 30 ? 'selected' : ''}>Every 30 minutes</option><option value="60" ${Number(state.settings.hourlyIntervalMinutes || 60) === 60 ? 'selected' : ''}>Every hour</option><option value="120" ${Number(state.settings.hourlyIntervalMinutes) === 120 ? 'selected' : ''}>Every 2 hours</option></select></div>
            <div class="form-row"><div class="form-group"><label for="hourlyStart">Check-ins start</label><input id="hourlyStart" class="input" type="time" value="${state.settings.hourlyStart || '06:00'}" /></div><div class="form-group"><label for="hourlyEnd">Check-ins end</label><input id="hourlyEnd" class="input" type="time" value="${state.settings.hourlyEnd || '03:00'}" /></div></div>
            <div class="switch-row"><div><b>Skip when an activity was recorded recently</b><div class="routine-meta">Avoid asking again after a recent photo, text, voice, or completion.</div></div><button class="switch ${state.settings.hourlySkipRecent !== false ? 'on' : ''}" data-setting="hourlySkipRecent" aria-label="Toggle recent-entry suppression"></button></div>
            <div class="form-group settings-last-field"><label for="hourlyRecentMinutes">Recent-entry window</label><select id="hourlyRecentMinutes" class="input"><option value="30" ${Number(state.settings.hourlyRecentMinutes) === 30 ? 'selected' : ''}>30 min</option><option value="50" ${Number(state.settings.hourlyRecentMinutes || 50) === 50 ? 'selected' : ''}>50 min</option><option value="90" ${Number(state.settings.hourlyRecentMinutes) === 90 ? 'selected' : ''}>90 min</option></select></div>
            <button id="testHourlyButton" class="btn secondary full" type="button">Test hourly check-in now</button>
            <div class="routine-meta settings-note">Uses exact alarms when Android allows them; otherwise delivery may be slightly delayed.</div>
          </div>
          ${isNativeApp ? '' : '<div class="routine-meta settings-note">Install the Android APK to enable hourly background check-ins.</div>'}
        </section>

        <section class="card settings-card">
          <div class="settings-section-head"><div><h2>Quiet hours</h2><p class="subtle">Keep prompts outside the selected rest period.</p></div></div>
          <div class="form-row"><div class="form-group"><label for="quietStart">Quiet hours start</label><input id="quietStart" class="input" type="time" value="${state.settings.quietStart}" /></div><div class="form-group"><label for="quietEnd">Quiet hours end</label><input id="quietEnd" class="input" type="time" value="${state.settings.quietEnd}" /></div></div>
        </section>

        <section class="card settings-card settings-actions-card">
          <div class="settings-section-head"><div><h2>App & data</h2><p class="subtle">Permissions, exports, testing controls, and profile reset.</p></div></div>
          ${archiveStatus}
          <div class="settings-action-grid">
            <button id="notifyPermission" class="btn secondary">Enable notifications</button>
            <button id="backupButton" class="btn secondary">Export backup</button>
            <button id="restoreBackupButton" class="btn secondary">Import old JSON backup</button>
            ${nativeButtons}
            <button id="newProfileButton" class="btn danger">Start a new profile</button>
            <button id="loadDemoButton" class="btn ghost">Load demonstration profile</button>
          </div>
          ${foundation}
        </section>
      </div>
    </section>`;
  }

  function bindSettingsEvents() {
    $('#appLanguage')?.addEventListener('change', event => {
      uiLanguage = normalizeLanguage(event.target.value);
      state.settings.appLanguage = uiLanguage;
      try { nativeBridge?.setPreferredLanguage?.(state.settings.notificationLanguage === 'app' ? uiLanguage : state.settings.notificationLanguage); } catch (error) { console.warn(error); }
      save(); render(); toast('Language changed.');
    });
    $('#reportLanguage')?.addEventListener('change', event => { state.settings.reportLanguage = event.target.value; save(); });
    $('#notificationLanguage')?.addEventListener('change', event => {
      state.settings.notificationLanguage = event.target.value;
      const resolved = event.target.value === 'app' ? uiLanguage : normalizeLanguage(event.target.value);
      try { nativeBridge?.setPreferredLanguage?.(resolved); } catch (error) { console.warn(error); }
      save();
    });
    $$('[data-setting]').forEach(button => button.addEventListener('click', () => {
      const key = button.dataset.setting;
      state.settings[key] = !state.settings[key];
      button.classList.toggle('on', state.settings[key]);
      if (key === 'hourlyCheckIns') {
        const panel = $('#hourlySettingsPanel');
        if (panel) panel.classList.toggle('hidden', !state.settings.hourlyCheckIns);
        if (state.settings.hourlyCheckIns && isNativeApp) nativeBridge.requestNotificationPermission();
        applyHourlyCheckInSettings();
        toast(state.settings.hourlyCheckIns ? 'Hourly check-ins enabled.' : 'Hourly check-ins disabled.');
      } else if (key === 'hourlySkipRecent') {
        applyHourlyCheckInSettings();
      }
      save();
    }));
    $('#hourlyInterval')?.addEventListener('change', event => { state.settings.hourlyIntervalMinutes = Number(event.target.value); save(); applyHourlyCheckInSettings(); toast('Hourly check-in settings updated.'); });
    $('#hourlyStart')?.addEventListener('change', event => { state.settings.hourlyStart = event.target.value; save(); applyHourlyCheckInSettings(); });
    $('#hourlyEnd')?.addEventListener('change', event => { state.settings.hourlyEnd = event.target.value; save(); applyHourlyCheckInSettings(); });
    $('#hourlyRecentMinutes')?.addEventListener('change', event => { state.settings.hourlyRecentMinutes = Number(event.target.value); save(); applyHourlyCheckInSettings(); });
    $('#testHourlyButton')?.addEventListener('click', () => {
      nativeBridge.requestNotificationPermission();
      nativeBridge.showHourlyCheckInNow();
      toast('An hourly check-in notification was shown.');
    });
    $('#quietStart')?.addEventListener('change', event => { state.settings.quietStart = event.target.value; save(); });
    $('#quietEnd')?.addEventListener('change', event => { state.settings.quietEnd = event.target.value; save(); });
    $('#backupButton')?.addEventListener('click', exportBackup);
    $('#restoreBackupButton')?.addEventListener('click', () => backupInput.click());
    backupInput?.addEventListener('change', () => importBackupFile(backupInput.files?.[0]));
    $('#notifyPermission')?.addEventListener('click', async () => {
      if (isNativeApp) {
        nativeBridge.requestNotificationPermission();
        toast('Android notification permission requested.');
        return;
      }
      if (!('Notification' in window)) return toast('Notifications are not supported in this browser.');
      const permission = await Notification.requestPermission();
      if (permission === 'granted') new Notification('Pocket OT', { body: 'Notifications are enabled.' });
    });
    $('#quickNotificationButton')?.addEventListener('click', () => {
      nativeBridge.requestNotificationPermission();
      nativeBridge.showQuickCaptureNotification();
      state.settings.quickCaptureNotification = true;
      save();
      toast('Quick Photo / Text / Voice notification enabled.');
    });
    $('#hideQuickNotificationButton')?.addEventListener('click', () => {
      nativeBridge.hideQuickCaptureNotification();
      state.settings.quickCaptureNotification = false;
      save();
      toast('Quick notification hidden.');
    });
    $('#testReminderButton')?.addEventListener('click', () => {
      nativeBridge.requestNotificationPermission();
      nativeBridge.scheduleTestReminder(60);
      toast('A native reminder is scheduled in one minute.');
    });
    $('#exactAlarmButton')?.addEventListener('click', () => {
      if (nativeBridge.canScheduleExactAlarms()) return toast('Exact alarms are already allowed.');
      nativeBridge.openExactAlarmSettings();
    });
    $('#installButton')?.addEventListener('click', async () => {
      if (window.deferredInstallPrompt) { window.deferredInstallPrompt.prompt(); await window.deferredInstallPrompt.userChoice; }
      else toast('Use your browser menu and choose “Install app” or “Add to Home screen.”');
    });
    $('#editProfileButton')?.addEventListener('click', openProfileEditor);
    $('#newProfileButton')?.addEventListener('click', restartProfileSetup);
    $('#loadDemoButton')?.addEventListener('click', () => {
      if (!confirm('Replace the current local profile with the Alex demonstration data? Export a backup first if needed.')) return;
      const keepLanguage = uiLanguage;
      state = buildDemoState();
      state.settings.appLanguage = keepLanguage;
      state.settings.reportLanguage = 'app';
      state.settings.notificationLanguage = 'app';
      navigationStack.length = 0;
      lastContentRoute = 'today';
      save(); render(); toast('Demonstration profile loaded.');
    });
  }

  function openSettings() {
    if (state.route === 'settings') return;
    setRoute('settings');
  }

  function addNativeCompletion(detail = {}) {
    const timestamp = detail.timestamp ? new Date(detail.timestamp) : new Date();
    const start = Number.isNaN(timestamp.getTime()) ? new Date() : timestamp;
    const end = new Date(start.getTime() + 15 * 60000);
    const label = detail.label?.trim() || 'Reminder completed';
    state.timeline.push({
      id: uid('timeline'),
      start: start.toISOString(),
      end: end.toISOString(),
      title: label,
      category: 'Quick completion',
      source: 'notification',
      confidence: 100,
      notes: 'Recorded from Android notification action',
    });
    state.mode = 'patient';
    state.route = 'timeline';
    save();
    render();
    toast(`${label} recorded from the notification.`);
  }

  function addNativeTextEntry(detail = {}) {
    const text = String(detail.text || '').trim();
    if (!text) return false;
    const timestamp = detail.timestamp ? new Date(detail.timestamp) : new Date();
    const start = Number.isNaN(timestamp.getTime()) ? new Date() : timestamp;
    state.timeline.push({
      id: uid('timeline'),
      start: start.toISOString(),
      end: new Date(start.getTime() + 15 * 60000).toISOString(),
      title: text,
      category: 'Other',
      source: 'notification-text',
      confidence: 100,
      notes: 'Entered with Android notification quick reply',
    });
    state.notes.push({ id: uid('note'), at: start.toISOString(), text, source: 'notification-text' });
    state.mode = 'patient';
    state.route = 'timeline';
    save();
    render();
    toast('Activity saved from the notification.');
    return true;
  }

  function handleNativeAction(detail = {}) {
    const action = detail.action || 'open';
    if (action === 'done') return addNativeCompletion(detail);
    if (action === 'text' && addNativeTextEntry(detail)) return;
    state.mode = 'patient';
    if (action === 'text') {
      state.route = 'capture';
      save();
      render();
      setTimeout(() => openQuickText(), 80);
      return;
    }
    if (action === 'voice') {
      state.route = 'capture';
      save();
      render();
      setTimeout(() => openVoiceNote({ autoStart: true }), 100);
      return;
    }
    state.route = action === 'open' ? 'today' : state.route;
    save();
    render();
  }

  function consumePendingNativeActions() {
    if (!isNativeApp || !nativeBridge?.consumePendingActions) return;
    try {
      const pending = JSON.parse(nativeBridge.consumePendingActions() || '[]');
      pending.forEach(handleNativeAction);
    } catch (error) {
      console.warn('Could not restore notification actions', error);
    }
  }

  window.addEventListener('otPocketNativeAction', event => handleNativeAction(event.detail || {}));

  document.addEventListener('click', event => {
    const nav = event.target.closest('.nav-item');
    if (nav) setRoute(nav.dataset.route);
  });
  $('#modeSwitch').addEventListener('click', () => {
    state.mode = state.mode === 'patient' ? 'ot' : 'patient';
    if (state.mode === 'ot') state.route = 'today';
    save(); render();
  });
  $('#settingsButton').addEventListener('click', () => { if (state.route === 'settings') navigateBack(); else openSettings(); });
  cameraInput.addEventListener('change', () => handlePhotoFiles([...cameraInput.files]));
  galleryInput.addEventListener('change', () => handlePhotoFiles([...galleryInput.files]));

  let swipeStart = null;
  main.addEventListener('pointerdown', event => {
    if (event.pointerType === 'mouse' || !state.setupCompleted || state.mode !== 'patient' || state.route === 'settings') return;
    if (event.clientX < 28 || event.clientX > window.innerWidth - 28) return;
    if (event.target.closest('input, textarea, select, button, a, [contenteditable="true"], .modal')) return;
    swipeStart = { x: event.clientX, y: event.clientY, at: performance.now() };
  }, { passive: true });
  main.addEventListener('pointerup', event => {
    if (!swipeStart) return;
    const start = swipeStart;
    swipeStart = null;
    const dx = event.clientX - start.x;
    const dy = event.clientY - start.y;
    if (performance.now() - start.at > 650 || Math.abs(dx) < 72 || Math.abs(dx) < Math.abs(dy) * 1.4) return;
    const index = PATIENT_ROUTES.indexOf(state.route);
    if (index < 0) return;
    const nextIndex = dx < 0 ? index + 1 : index - 1;
    if (nextIndex >= 0 && nextIndex < PATIENT_ROUTES.length) setRoute(PATIENT_ROUTES[nextIndex]);
  }, { passive: true });
  main.addEventListener('pointercancel', () => { swipeStart = null; }, { passive: true });

  window.addEventListener('beforeinstallprompt', event => { event.preventDefault(); window.deferredInstallPrompt = event; });
  if (!isNativeApp && 'serviceWorker' in navigator && location.protocol !== 'file:') window.addEventListener('load', () => navigator.serviceWorker.register('./sw.js').catch(console.warn));

  render();
  applyHourlyCheckInSettings();
  syncNativeActivityTimestamp();
  setTimeout(consumePendingNativeActions, 120);

  function syncKeyboardViewport() {
    const viewport = window.visualViewport;
    const height = viewport ? viewport.height : window.innerHeight;
    const keyboardOpen = viewport ? (window.innerHeight - viewport.height > 140) : false;
    document.documentElement.style.setProperty('--visual-viewport-height', `${Math.round(height)}px`);
    document.body.classList.toggle('keyboard-open', keyboardOpen);
  }
  window.visualViewport?.addEventListener('resize', syncKeyboardViewport);
  window.visualViewport?.addEventListener('scroll', syncKeyboardViewport);
  window.addEventListener('resize', syncKeyboardViewport);
  document.addEventListener('focusin', event => {
    if (!event.target.matches('input,textarea,select,[contenteditable="true"]')) return;
    setTimeout(() => event.target.scrollIntoView({ block: 'center', behavior: 'smooth' }), 160);
  });
  syncKeyboardViewport();
})();
