package ca.otpocket.app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Durable native metadata store for Pocket OT.
 *
 * Photo bytes deliberately do not live in this database.  They are archived as
 * individual private files by {@link PhotoArchive}; only their file references
 * remain in the JSON application state.
 */
public final class NativeStorage extends SQLiteOpenHelper {
    private static final String DB_NAME = "pocket_ot.db";
    private static final int DB_VERSION = 1;
    private static final String TABLE_STATE = "app_state";
    private static final int STATE_ROW_ID = 1;

    NativeStorage(Context context) {
        super(context.getApplicationContext(), DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_STATE + " ("
                + "id INTEGER PRIMARY KEY, "
                + "json TEXT NOT NULL, "
                + "updated_at INTEGER NOT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Schema v1. Future migrations must preserve the single durable state row.
    }

    synchronized String loadStateJson() {
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor cursor = db.query(
                TABLE_STATE,
                new String[]{"json"},
                "id=?",
                new String[]{String.valueOf(STATE_ROW_ID)},
                null,
                null,
                null,
                "1")) {
            if (!cursor.moveToFirst()) return "";
            String json = cursor.getString(0);
            return json == null ? "" : json;
        }
    }

    synchronized boolean saveStateJson(String json) {
        if (json == null || json.isBlank()) return false;
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("id", STATE_ROW_ID);
        values.put("json", json);
        values.put("updated_at", System.currentTimeMillis());
        return db.insertWithOnConflict(
                TABLE_STATE,
                null,
                values,
                SQLiteDatabase.CONFLICT_REPLACE) != -1;
    }

    synchronized void clearState() {
        getWritableDatabase().delete(
                TABLE_STATE,
                "id=?",
                new String[]{String.valueOf(STATE_ROW_ID)});
    }
}
