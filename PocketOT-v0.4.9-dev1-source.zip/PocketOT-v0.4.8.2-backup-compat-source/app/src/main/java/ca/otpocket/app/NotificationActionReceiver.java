package ca.otpocket.app;

import android.app.NotificationManager;
import android.app.RemoteInput;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

public final class NotificationActionReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getStringExtra(NotificationHelper.EXTRA_NATIVE_ACTION);
        String key = intent.getStringExtra(NotificationHelper.EXTRA_KEY);
        String title = intent.getStringExtra(NotificationHelper.EXTRA_TITLE);
        String message = intent.getStringExtra(NotificationHelper.EXTRA_MESSAGE);
        int notificationId = intent.getIntExtra(
                NotificationHelper.EXTRA_NOTIFICATION_ID,
                ReminderScheduler.stableId(key));
        if (key == null) key = "quick-action";
        if (title == null || title.isBlank()) title = AppLanguage.text(context, "Activity", "Activité");

        NotificationManager manager = context.getSystemService(NotificationManager.class);

        if (NotificationHelper.ACTION_TEXT.equals(action)) {
            Bundle results = RemoteInput.getResultsFromIntent(intent);
            CharSequence reply = results == null ? null : results.getCharSequence(NotificationHelper.REMOTE_INPUT_TEXT);
            String text = reply == null ? "" : reply.toString().trim();
            if (!text.isBlank()) {
                long timestamp = System.currentTimeMillis();
                PendingActionStore.append(context, "text", title, key, timestamp, text);
                HourlyCheckInScheduler.markActivityRecorded(context, timestamp);
                manager.cancel(notificationId);
                NotificationHelper.showSaved(
                        context,
                        AppLanguage.text(context, "Activity text recorded.", "Texte de l’activité enregistré."));
            }
            return;
        }

        if (NotificationHelper.ACTION_DONE.equals(action)) {
            long timestamp = System.currentTimeMillis();
            PendingActionStore.append(context, "done", title, key, timestamp);
            HourlyCheckInScheduler.markActivityRecorded(context, timestamp);
            manager.cancel(notificationId);
            NotificationHelper.showSaved(
                    context,
                    AppLanguage.isFrench(context)
                            ? title + " enregistré comme fait."
                            : title + " recorded as done.");
        } else if (NotificationHelper.ACTION_LATER.equals(action)) {
            long later = System.currentTimeMillis() + 30L * 60L * 1000L;
            String snoozeKey = key + "-snooze-" + later;
            ReminderScheduler.schedule(
                    context,
                    snoozeKey,
                    title,
                    message == null
                            ? AppLanguage.text(context, "What were you doing?", "Que faisiez-vous?")
                            : message,
                    later,
                    true);
            manager.cancel(notificationId);
            NotificationHelper.showSaved(
                    context,
                    AppLanguage.text(context,
                            "Reminder moved 30 minutes later.",
                            "Rappel reporté de 30 minutes."));
        }
    }
}
