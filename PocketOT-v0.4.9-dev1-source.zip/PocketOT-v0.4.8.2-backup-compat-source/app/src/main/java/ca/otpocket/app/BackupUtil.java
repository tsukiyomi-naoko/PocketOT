package ca.otpocket.app;

import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Streaming backup writer. Photo bytes are never assembled into one in-memory JSON string. */
public final class BackupUtil {
    private BackupUtil() {}

    public static String exportFullBackup(Context context, String fileName, String stateJson) throws Exception {
        String safeName = sanitize(fileName == null || fileName.isBlank()
                ? "ot-pocket-backup.zip"
                : fileName);
        if (!safeName.toLowerCase().endsWith(".zip")) safeName += ".zip";

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
            values.put(MediaStore.Downloads.MIME_TYPE, "application/zip");
            values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Pocket OT");
            values.put(MediaStore.Downloads.IS_PENDING, 1);
            Uri uri = context.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new IllegalStateException("Unable to create backup file.");
            boolean complete = false;
            try (OutputStream output = context.getContentResolver().openOutputStream(uri)) {
                if (output == null) throw new IllegalStateException("Unable to open backup file.");
                writeZip(context, output, stateJson);
                complete = true;
            } finally {
                values.clear();
                values.put(MediaStore.Downloads.IS_PENDING, 0);
                context.getContentResolver().update(uri, values, null, null);
                if (!complete) {
                    // Keep the failed item visible rather than risking a hidden MediaStore row;
                    // callers report the error and the next export uses a new filename.
                }
            }
            return uri.toString();
        }

        File directory = new File(context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "Pocket OT");
        if (!directory.exists() && !directory.mkdirs()) throw new IllegalStateException("Unable to create backup folder.");
        File destination = new File(directory, safeName);
        try (FileOutputStream output = new FileOutputStream(destination, false)) {
            writeZip(context, output, stateJson);
        }
        return destination.getAbsolutePath();
    }

    private static void writeZip(Context context, OutputStream rawOutput, String stateJson) throws Exception {
        try (ZipOutputStream zip = new ZipOutputStream(rawOutput)) {
            JSONObject manifest = new JSONObject();
            manifest.put("format", "pocket-ot-backup");
            manifest.put("formatVersion", 1);
            manifest.put("appVersion", "0.4.8.2");
            manifest.put("createdAt", System.currentTimeMillis());
            writeTextEntry(zip, "manifest.json", manifest.toString(2));
            writeTextEntry(zip, "state.json", stateJson == null ? "{}" : stateJson);

            File root = new File(context.getFilesDir(), "photo_archive");
            File[] files = root.listFiles();
            if (files == null) return;
            byte[] buffer = new byte[64 * 1024];
            for (File file : files) {
                if (!file.isFile() || file.getName().endsWith(".tmp")) continue;
                ZipEntry entry = new ZipEntry("photos/" + file.getName());
                entry.setTime(file.lastModified());
                zip.putNextEntry(entry);
                try (BufferedInputStream input = new BufferedInputStream(new FileInputStream(file))) {
                    int read;
                    while ((read = input.read(buffer)) != -1) zip.write(buffer, 0, read);
                }
                zip.closeEntry();
            }
        }
    }

    private static void writeTextEntry(ZipOutputStream zip, String name, String text) throws Exception {
        zip.putNextEntry(new ZipEntry(name));
        zip.write(text.getBytes(StandardCharsets.UTF_8));
        zip.closeEntry();
    }

    private static String sanitize(String name) {
        String value = name == null || name.isBlank() ? "ot-pocket-backup.zip" : name;
        return value.replaceAll("[^A-Za-z0-9._() -]", "_");
    }
}
