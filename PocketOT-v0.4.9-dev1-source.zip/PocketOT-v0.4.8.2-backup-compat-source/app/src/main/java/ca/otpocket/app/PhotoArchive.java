package ca.otpocket.app;

import android.content.Context;
import android.net.Uri;
import android.util.Base64;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Locale;

/** Stores Pocket OT photos as individual private files rather than WebView data URLs. */
public final class PhotoArchive {
    static final String WEB_HOST = "pocketot.local";
    private static final String WEB_PREFIX = "/photos/";
    private static final String DIRECTORY = "photo_archive";

    private final Context context;
    private final File root;

    PhotoArchive(Context context) {
        this.context = context.getApplicationContext();
        this.root = new File(this.context.getFilesDir(), DIRECTORY);
    }

    synchronized String saveDataUrl(String requestedId, String dataUrl) throws IOException {
        if (dataUrl == null || !dataUrl.startsWith("data:")) {
            return dataUrl == null ? "" : dataUrl;
        }
        int comma = dataUrl.indexOf(',');
        if (comma <= 5) throw new IOException("Invalid image data URL.");
        String header = dataUrl.substring(5, comma).toLowerCase(Locale.ROOT);
        if (!header.contains(";base64")) throw new IOException("Image is not base64 encoded.");

        byte[] bytes;
        try {
            bytes = Base64.decode(dataUrl.substring(comma + 1), Base64.DEFAULT);
        } catch (IllegalArgumentException error) {
            throw new IOException("Invalid image encoding.", error);
        }
        if (bytes.length == 0) throw new IOException("Image is empty.");

        String extension = header.startsWith("image/png") ? ".png"
                : header.startsWith("image/webp") ? ".webp"
                : ".jpg";
        String safeId = sanitizeId(requestedId);
        if (safeId.isBlank()) safeId = "photo_" + System.currentTimeMillis();
        ensureRoot();

        File destination = new File(root, safeId + extension);
        File temp = new File(root, safeId + extension + ".tmp");
        try (FileOutputStream output = new FileOutputStream(temp, false)) {
            output.write(bytes);
            output.flush();
            output.getFD().sync();
        }
        if (destination.exists() && !destination.delete()) {
            temp.delete();
            throw new IOException("Could not replace existing photo.");
        }
        if (!temp.renameTo(destination)) {
            temp.delete();
            throw new IOException("Could not finalize photo archive file.");
        }
        return webUrl(destination);
    }

    synchronized boolean delete(String reference) {
        File file = resolve(reference);
        return file == null || !file.exists() || file.delete();
    }

    synchronized void clear() {
        if (!root.exists()) return;
        File[] files = root.listFiles();
        if (files == null) return;
        for (File file : files) {
            if (file.isFile()) file.delete();
        }
    }

    synchronized String statsJson() {
        long bytes = 0L;
        int count = 0;
        if (root.exists()) {
            File[] files = root.listFiles();
            if (files != null) {
                for (File file : files) {
                    if (!file.isFile() || file.getName().endsWith(".tmp")) continue;
                    count++;
                    bytes += file.length();
                }
            }
        }
        JSONObject object = new JSONObject();
        try {
            object.put("count", count);
            object.put("bytes", bytes);
            object.put("freeBytes", context.getFilesDir().getUsableSpace());
        } catch (Exception ignored) {
        }
        return object.toString();
    }

    synchronized File resolveWebRequest(Uri uri) {
        if (uri == null
                || !"https".equalsIgnoreCase(uri.getScheme())
                || !WEB_HOST.equalsIgnoreCase(uri.getHost())) return null;
        String path = uri.getPath();
        if (path == null || !path.startsWith(WEB_PREFIX)) return null;
        String encodedName = path.substring(WEB_PREFIX.length());
        if (encodedName.isBlank() || encodedName.contains("/")) return null;
        String name = Uri.decode(encodedName);
        if (name.contains("/") || name.contains("\\") || name.contains("..")) return null;
        try {
            return checkedChild(name);
        } catch (IOException ignored) {
            return null;
        }
    }

    static String mimeType(File file) {
        String name = file == null ? "" : file.getName().toLowerCase(Locale.ROOT);
        if (name.endsWith(".png")) return "image/png";
        if (name.endsWith(".webp")) return "image/webp";
        return "image/jpeg";
    }

    private File resolve(String reference) {
        if (reference == null || reference.isBlank()) return null;
        try {
            Uri uri = Uri.parse(reference);
            if ("https".equalsIgnoreCase(uri.getScheme())
                    && WEB_HOST.equalsIgnoreCase(uri.getHost())) {
                return resolveWebRequest(uri);
            }
            // Accept file:// references from any early v0.4.8 test build so they
            // can still be deleted cleanly after upgrading to the internal URL path.
            if ("file".equalsIgnoreCase(uri.getScheme())) {
                String path = uri.getPath();
                if (path == null) return null;
                File candidate = new File(path).getCanonicalFile();
                File canonicalRoot = root.getCanonicalFile();
                if (!candidate.getPath().startsWith(canonicalRoot.getPath() + File.separator)) return null;
                return candidate;
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    private String webUrl(File file) {
        return "https://" + WEB_HOST + WEB_PREFIX + Uri.encode(file.getName());
    }

    private File checkedChild(String name) throws IOException {
        File canonicalRoot = root.getCanonicalFile();
        File candidate = new File(root, name).getCanonicalFile();
        if (!candidate.getPath().startsWith(canonicalRoot.getPath() + File.separator)) {
            throw new IOException("Invalid photo archive path.");
        }
        return candidate;
    }

    private void ensureRoot() throws IOException {
        if (!root.exists() && !root.mkdirs()) {
            throw new IOException("Could not create photo archive folder.");
        }
    }

    private static String sanitizeId(String value) {
        if (value == null) return "";
        return value.replaceAll("[^A-Za-z0-9._-]", "_");
    }
}
