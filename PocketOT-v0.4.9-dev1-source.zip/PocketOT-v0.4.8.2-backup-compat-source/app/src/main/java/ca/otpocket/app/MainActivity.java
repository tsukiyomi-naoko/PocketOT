package ca.otpocket.app;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.SystemClock;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.ValueCallback;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import android.window.OnBackInvokedDispatcher;

import androidx.core.content.FileProvider;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;

import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class MainActivity extends Activity {
    public static final int REQUEST_NOTIFICATIONS = 301;
    public static final int REQUEST_RECORD_AUDIO = 302;
    private static final int REQUEST_FILE_CHOOSER = 401;
    private static final int REQUEST_DIRECT_CAMERA = 402;

    private WebView webView;
    private PhotoArchive photoArchive;
    private ValueCallback<Uri[]> fileCallback;
    private Uri chooserCameraUri;
    private Uri directCameraUri;
    private boolean pageReady;
    private Intent deferredIntent;
    private int safeTopPx;
    private int safeBottomPx;
    private int safeLeftPx;
    private int safeRightPx;
    private int gestureBottomPx;
    private long lastBackPressedAt;
    private NativeSpeechRecognizer speechRecognition;
    private String pendingSpeechLanguage = "en-CA";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            getWindow().setNavigationBarContrastEnforced(true);
        }
        NotificationHelper.createChannels(this);
        photoArchive = new PhotoArchive(this);
        configureWebView();
        configureBackNavigation();
        configureSpeechRecognition();
        deferredIntent = getIntent();
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    private void configureWebView() {
        webView = new WebView(this);
        webView.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        webView.setBackgroundColor(Color.rgb(243, 246, 244));
        setContentView(webView);
        configureWindowInsets();

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        webView.addJavascriptInterface(new NativeBridge(this, photoArchive), "OTPocketNative");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(
                    WebView view, WebResourceRequest request
            ) {
                File photo = photoArchive.resolveWebRequest(request.getUrl());
                if (photo == null) return super.shouldInterceptRequest(view, request);
                if (!photo.isFile()) {
                    return new WebResourceResponse(
                            "text/plain", "UTF-8", 404, "Not Found",
                            java.util.Collections.emptyMap(),
                            new java.io.ByteArrayInputStream(new byte[0]));
                }
                try {
                    return new WebResourceResponse(
                            PhotoArchive.mimeType(photo),
                            null,
                            new FileInputStream(photo));
                } catch (IOException error) {
                    return new WebResourceResponse(
                            "text/plain", "UTF-8", 500, "Read Error",
                            java.util.Collections.emptyMap(),
                            new java.io.ByteArrayInputStream(new byte[0]));
                }
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                pageReady = true;
                applyCssInsets();
                if (deferredIntent != null) {
                    Intent pending = deferredIntent;
                    deferredIntent = null;
                    handleLaunchIntent(pending);
                }
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                    WebView view,
                    ValueCallback<Uri[]> callback,
                    FileChooserParams params
            ) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    boolean imageChooser = acceptsImagesOnly(params);
                    Intent picker = new Intent(Intent.ACTION_OPEN_DOCUMENT)
                            .addCategory(Intent.CATEGORY_OPENABLE)
                            .setType(imageChooser ? "image/*" : "*/*")
                            .putExtra(Intent.EXTRA_ALLOW_MULTIPLE,
                                    params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);

                    Intent chooser = Intent.createChooser(
                            picker,
                            AppLanguage.text(MainActivity.this,
                                    imageChooser ? "Add activity picture" : "Select Pocket OT backup",
                                    imageChooser ? "Ajouter une photo d’activité" : "Choisir une sauvegarde Pocket OT"));

                    // Only offer the camera for actual image inputs. Backup/document inputs
                    // must remain a normal Android document picker; older Pocket OT JSON
                    // exports are variously reported by providers as application/json,
                    // text/plain, application/octet-stream, or no useful MIME type at all.
                    if (imageChooser) {
                        Intent camera = createCameraIntent(false);
                        chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{camera});
                    }

                    startActivityForResult(chooser, REQUEST_FILE_CHOOSER);
                    return true;
                } catch (Exception error) {
                    if (fileCallback != null) fileCallback.onReceiveValue(null);
                    fileCallback = null;
                    Toast.makeText(
                            MainActivity.this,
                            AppLanguage.text(MainActivity.this,
                                    "File picker could not open.",
                                    "Impossible d’ouvrir le sélecteur de fichiers."),
                            Toast.LENGTH_LONG).show();
                    return false;
                }
            }
        });
    }

    private boolean acceptsImagesOnly(WebChromeClient.FileChooserParams params) {
        String[] acceptTypes = params == null ? null : params.getAcceptTypes();
        if (acceptTypes == null || acceptTypes.length == 0) return false;
        boolean sawType = false;
        for (String raw : acceptTypes) {
            if (raw == null || raw.isBlank()) continue;
            for (String part : raw.split(",")) {
                String type = part == null ? "" : part.trim().toLowerCase(Locale.ROOT);
                if (type.isEmpty()) continue;
                sawType = true;
                if (!(type.startsWith("image/") || type.matches("\\.(png|jpe?g|webp|gif|heic|heif)"))) {
                    return false;
                }
            }
        }
        return sawType;
    }

    private void configureSpeechRecognition() {
        speechRecognition = new NativeSpeechRecognizer(this, new NativeSpeechRecognizer.Listener() {
            @Override
            public void onState(String state) {
                dispatchVoiceEvent("state", "", state, 0, "");
            }

            @Override
            public void onPartial(String text) {
                dispatchVoiceEvent("partial", text, "listening", 0, "");
            }

            @Override
            public void onResult(String text) {
                dispatchVoiceEvent("result", text, "complete", 0, "");
            }

            @Override
            public void onError(int code, String key) {
                dispatchVoiceEvent("error", "", "error", code, voiceErrorMessage(key));
            }
        });
    }

    private String voiceErrorMessage(String key) {
        return switch (key) {
            case "permission" -> AppLanguage.text(this,
                    "Microphone permission is required for voice recognition.",
                    "L’autorisation du microphone est requise pour la reconnaissance vocale.");
            case "unavailable" -> AppLanguage.text(this,
                    "No Android speech recognition service is available on this phone.",
                    "Aucun service de reconnaissance vocale Android n’est disponible sur ce téléphone.");
            case "no-speech", "no-match" -> AppLanguage.text(this,
                    "No speech was recognized. Try again or type the note.",
                    "Aucune parole n’a été reconnue. Réessayez ou saisissez la note.");
            case "busy" -> AppLanguage.text(this,
                    "Voice recognition is busy. Wait a moment and try again.",
                    "La reconnaissance vocale est occupée. Attendez un moment et réessayez.");
            case "network", "network-timeout", "server", "server-disconnected" -> AppLanguage.text(this,
                    "Speech recognition could not reach its service. Try again or use text.",
                    "La reconnaissance vocale n’a pas pu joindre son service. Réessayez ou utilisez le texte.");
            case "language-not-supported", "language-unavailable" -> AppLanguage.text(this,
                    "The selected recognition language is not installed on this phone.",
                    "La langue de reconnaissance sélectionnée n’est pas installée sur ce téléphone.");
            case "audio" -> AppLanguage.text(this,
                    "The microphone audio could not be read.",
                    "Le son du microphone n’a pas pu être lu.");
            case "too-many-requests" -> AppLanguage.text(this,
                    "Too many voice requests were made. Wait briefly and try again.",
                    "Trop de demandes vocales ont été faites. Attendez un peu et réessayez.");
            default -> AppLanguage.text(this,
                    "Voice recognition could not start. You can type instead.",
                    "La reconnaissance vocale n’a pas pu démarrer. Vous pouvez utiliser le texte.");
        };
    }

    public boolean isVoiceRecognitionAvailable() {
        return speechRecognition != null && speechRecognition.isAvailable();
    }

    public void startVoiceRecognition(String language) {
        runOnUiThread(() -> {
            pendingSpeechLanguage = language == null ? "en-CA" : language;
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(
                        new String[]{Manifest.permission.RECORD_AUDIO},
                        REQUEST_RECORD_AUDIO);
                dispatchVoiceEvent("state", "", "permission", 0, "");
                return;
            }
            if (speechRecognition == null || !speechRecognition.isAvailable()) {
                dispatchVoiceEvent(
                        "error", "", "error", 0, voiceErrorMessage("unavailable"));
                return;
            }
            speechRecognition.start(pendingSpeechLanguage);
        });
    }

    public void stopVoiceRecognition() {
        runOnUiThread(() -> {
            if (speechRecognition != null) speechRecognition.stop();
        });
    }

    public void cancelVoiceRecognition() {
        runOnUiThread(() -> {
            if (speechRecognition != null) speechRecognition.cancel();
        });
    }

    public void printCurrentReport(String requestedJobName) {
        runOnUiThread(() -> {
            if (webView == null) {
                Toast.makeText(
                        this,
                        AppLanguage.text(this,
                                "The report is not ready to print.",
                                "Le rapport n’est pas prêt à être imprimé."),
                        Toast.LENGTH_LONG).show();
                return;
            }
            PrintManager printManager =
                    (PrintManager) getSystemService(Context.PRINT_SERVICE);
            if (printManager == null) {
                Toast.makeText(
                        this,
                        AppLanguage.text(this,
                                "Android printing is not available on this device.",
                                "L’impression Android n’est pas disponible sur cet appareil."),
                        Toast.LENGTH_LONG).show();
                return;
            }
            String jobName = requestedJobName == null || requestedJobName.isBlank()
                    ? "Pocket OT weekly report"
                    : requestedJobName;
            try {
                printManager.print(
                        jobName,
                        webView.createPrintDocumentAdapter(jobName),
                        null);
            } catch (Exception error) {
                Toast.makeText(
                        this,
                        AppLanguage.text(this,
                                "Print / PDF could not open: ",
                                "Impossible d’ouvrir l’impression / PDF : ")
                                + error.getMessage(),
                        Toast.LENGTH_LONG).show();
            }
        });
    }

    private void dispatchVoiceEvent(
            String type,
            String text,
            String state,
            int errorCode,
            String message
    ) {
        if (!pageReady || webView == null) return;
        String script = "window.dispatchEvent(new CustomEvent('otPocketVoice',{detail:{type:"
                + JSONObject.quote(type)
                + ",text:" + JSONObject.quote(text == null ? "" : text)
                + ",state:" + JSONObject.quote(state == null ? "" : state)
                + ",errorCode:" + errorCode
                + ",message:" + JSONObject.quote(message == null ? "" : message)
                + "}}));";
        webView.evaluateJavascript(script, null);
    }

    private void configureWindowInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(webView, (view, windowInsets) -> {
            Insets statusBars = windowInsets.getInsets(WindowInsetsCompat.Type.statusBars());
            Insets cutout = windowInsets.getInsets(WindowInsetsCompat.Type.displayCutout());
            Insets navigationBars = windowInsets.getInsets(WindowInsetsCompat.Type.navigationBars());

            // WindowInsets are physical pixels, while WebView CSS uses density-independent
            // CSS pixels. Passing raw device pixels caused the large top gap on high-density
            // phones. Convert every inset before exposing it to the page.
            safeTopPx = toCssPixels(Math.max(statusBars.top, cutout.top));

            boolean gestureNavigation = isGestureNavigation(navigationBars);
            gestureBottomPx = gestureNavigation ? toCssPixels(navigationBars.bottom) : 0;
            safeBottomPx = gestureNavigation ? 0 : toCssPixels(navigationBars.bottom);
            safeLeftPx = gestureNavigation ? 0 : toCssPixels(navigationBars.left);
            safeRightPx = gestureNavigation ? 0 : toCssPixels(navigationBars.right);

            applyCssInsets();
            return windowInsets;
        });
        ViewCompat.requestApplyInsets(webView);
    }

    private int toCssPixels(int physicalPixels) {
        float density = getResources().getDisplayMetrics().density;
        if (density <= 0f) return physicalPixels;
        return Math.max(0, Math.round(physicalPixels / density));
    }

    private boolean isGestureNavigation(Insets navigationBars) {
        int resourceId = getResources().getIdentifier(
                "config_navBarInteractionMode", "integer", "android");
        if (resourceId > 0) {
            try {
                return getResources().getInteger(resourceId) == 2;
            } catch (Exception ignored) {
            }
        }

        int fortyDp = Math.round(40f * getResources().getDisplayMetrics().density);
        return navigationBars.bottom > 0 && navigationBars.bottom < fortyDp
                && navigationBars.left == 0 && navigationBars.right == 0;
    }

    private void applyCssInsets() {
        if (!pageReady || webView == null) return;
        String script = "document.documentElement.style.setProperty('--native-safe-top','"
                + safeTopPx + "px');"
                + "document.documentElement.style.setProperty('--native-safe-bottom','"
                + safeBottomPx + "px');"
                + "document.documentElement.style.setProperty('--native-safe-left','"
                + safeLeftPx + "px');"
                + "document.documentElement.style.setProperty('--native-safe-right','"
                + safeRightPx + "px');"
                + "document.documentElement.style.setProperty('--native-gesture-bottom','"
                + gestureBottomPx + "px');";
        webView.evaluateJavascript(script, null);
    }

    private Intent createCameraIntent(boolean direct) throws IOException {
        Uri uri = createImageUri(direct ? "direct" : "chooser");
        if (direct) directCameraUri = uri;
        else chooserCameraUri = uri;
        return new Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                .putExtra(MediaStore.EXTRA_OUTPUT, uri)
                .addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                        | Intent.FLAG_GRANT_READ_URI_PERMISSION);
    }

    private Uri createImageUri(String prefix) throws IOException {
        File directory = new File(
                getExternalFilesDir(Environment.DIRECTORY_PICTURES), "captures");
        if (!directory.exists() && !directory.mkdirs()) {
            throw new IOException("Unable to create capture folder.");
        }
        String stamp = new SimpleDateFormat(
                "yyyyMMdd_HHmmss", Locale.CANADA).format(new Date());
        File file = File.createTempFile(prefix + "_" + stamp + "_", ".jpg", directory);
        return FileProvider.getUriForFile(
                this, getPackageName() + ".files", file);
    }

    private void launchDirectCamera() {
        try {
            startActivityForResult(createCameraIntent(true), REQUEST_DIRECT_CAMERA);
        } catch (Exception error) {
            Toast.makeText(
                    this,
                    AppLanguage.text(this,
                            "Camera could not open: ",
                            "Impossible d’ouvrir la caméra : ") + error.getMessage(),
                    Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (pageReady) handleLaunchIntent(intent);
        else deferredIntent = intent;
    }

    private void handleLaunchIntent(Intent intent) {
        if (intent == null) return;
        String action = intent.getStringExtra(NotificationHelper.EXTRA_NATIVE_ACTION);
        String title = intent.getStringExtra(NotificationHelper.EXTRA_TITLE);
        String key = intent.getStringExtra(NotificationHelper.EXTRA_KEY);
        int notificationId = intent.getIntExtra(NotificationHelper.EXTRA_NOTIFICATION_ID, 0);
        if (notificationId > 0 && notificationId != NotificationHelper.QUICK_NOTIFICATION_ID) {
            getSystemService(NotificationManager.class).cancel(notificationId);
        }
        if (NotificationHelper.ACTION_PHOTO.equals(action)) {
            launchDirectCamera();
            intent.removeExtra(NotificationHelper.EXTRA_NATIVE_ACTION);
            return;
        }
        if (action == null || action.isBlank()) action = "open";
        dispatchAction(
                action,
                title == null ? "" : title,
                key == null ? "" : key,
                System.currentTimeMillis());
        intent.removeExtra(NotificationHelper.EXTRA_NATIVE_ACTION);
    }

    private void dispatchAction(String action, String label, String key, long timestamp) {
        String script = "window.dispatchEvent(new CustomEvent('otPocketNativeAction',{detail:{action:"
                + JSONObject.quote(action)
                + ",label:" + JSONObject.quote(label)
                + ",reminderKey:" + JSONObject.quote(key)
                + ",timestamp:" + timestamp + "}}));";
        webView.evaluateJavascript(script, null);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_FILE_CHOOSER) {
            if (fileCallback == null) return;
            Uri[] results = null;
            if (resultCode == RESULT_OK) {
                if (data == null || (data.getData() == null && data.getClipData() == null)) {
                    if (chooserCameraUri != null) results = new Uri[]{chooserCameraUri};
                } else {
                    results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
                }
            }
            fileCallback.onReceiveValue(results);
            fileCallback = null;
            chooserCameraUri = null;
            return;
        }

        if (requestCode == REQUEST_DIRECT_CAMERA
                && resultCode == RESULT_OK
                && directCameraUri != null) {
            try {
                String dataUrl = ImageUtil.toCompressedDataUrl(this, directCameraUri);
                String capturedAt = new SimpleDateFormat(
                        "yyyy-MM-dd'T'HH:mm:ss.SSSXXX",
                        Locale.CANADA).format(new Date());
                String script = "window.OTPocketReceiveNativePhoto && window.OTPocketReceiveNativePhoto("
                        + JSONObject.quote(dataUrl) + ","
                        + JSONObject.quote(capturedAt) + ");";
                webView.evaluateJavascript(script, null);
            } catch (Exception error) {
                Toast.makeText(
                        this,
                        AppLanguage.text(this,
                                "The photo could not be processed.",
                                "La photo n’a pas pu être traitée."),
                        Toast.LENGTH_LONG).show();
            } finally {
                directCameraUri = null;
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_RECORD_AUDIO) {
            boolean granted = grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            if (granted) startVoiceRecognition(pendingSpeechLanguage);
            else dispatchVoiceEvent(
                    "error", "", "error", 0, voiceErrorMessage("permission"));
        }
    }

    private void configureBackNavigation() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    OnBackInvokedDispatcher.PRIORITY_DEFAULT,
                    this::handleBackNavigation);
        }
    }

    private void handleBackNavigation() {
        if (webView == null || !pageReady) {
            handleRootBack();
            return;
        }
        webView.evaluateJavascript(
                "Boolean(window.OTPocketHandleBack && window.OTPocketHandleBack())",
                handled -> runOnUiThread(() -> {
                    if (!"true".equals(handled)) handleRootBack();
                }));
    }

    private void handleRootBack() {
        long now = SystemClock.elapsedRealtime();
        if (now - lastBackPressedAt <= 2000L) {
            finish();
            return;
        }
        lastBackPressedAt = now;
        Toast.makeText(
                this,
                AppLanguage.text(this,
                        "Swipe back again to exit Pocket OT.",
                        "Balayez de nouveau vers l’arrière pour quitter Pocket OT."),
                Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onBackPressed() {
        handleBackNavigation();
    }

    @Override
    protected void onDestroy() {
        if (speechRecognition != null) speechRecognition.destroy();
        if (webView != null) {
            webView.removeJavascriptInterface("OTPocketNative");
            webView.destroy();
        }
        super.onDestroy();
    }
}
