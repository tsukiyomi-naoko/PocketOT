package ca.otpocket.app;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;

import java.util.ArrayList;
import java.util.Locale;

/**
 * Short-form speech recognition for activity notes.
 *
 * The recognizer is created for one listening session and destroyed after a
 * result, error, cancellation, or Activity teardown. On Android 12+ the
 * on-device recognizer is preferred when available, with one automatic
 * fallback to the system recognizer when the requested language is not
 * installed on-device.
 */
public final class NativeSpeechRecognizer implements RecognitionListener {
    public interface Listener {
        void onState(String state);
        void onPartial(String text);
        void onResult(String text);
        void onError(int code, String key);
    }

    private final MainActivity activity;
    private final Listener listener;
    private SpeechRecognizer recognizer;
    private String language = "en-CA";
    private boolean usingOnDevice;
    private boolean allowNetworkFallback;
    private boolean active;
    private boolean cancelled;

    NativeSpeechRecognizer(MainActivity activity, Listener listener) {
        this.activity = activity;
        this.listener = listener;
    }

    public boolean isAvailable() {
        boolean standard = SpeechRecognizer.isRecognitionAvailable(activity);
        boolean onDevice = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                && SpeechRecognizer.isOnDeviceRecognitionAvailable(activity);
        return standard || onDevice;
    }

    public boolean isListening() {
        return active;
    }

    public void start(String requestedLanguage) {
        language = normalizeLanguage(requestedLanguage);
        cancelled = false;
        boolean onDevice = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                && SpeechRecognizer.isOnDeviceRecognitionAvailable(activity);
        startInternal(onDevice, onDevice);
    }

    private void startInternal(boolean preferOnDevice, boolean allowFallback) {
        destroyRecognizer();
        if (!isAvailable()) {
            listener.onError(SpeechRecognizer.ERROR_CLIENT, "unavailable");
            return;
        }

        try {
            usingOnDevice = preferOnDevice;
            allowNetworkFallback = allowFallback;
            recognizer = preferOnDevice
                    ? SpeechRecognizer.createOnDeviceSpeechRecognizer(activity)
                    : SpeechRecognizer.createSpeechRecognizer(activity);
            recognizer.setRecognitionListener(this);

            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, language)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, language)
                    .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                    .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, activity.getPackageName());
            if (preferOnDevice) intent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);

            active = true;
            listener.onState("starting");
            recognizer.startListening(intent);
        } catch (Exception error) {
            destroyRecognizer();
            listener.onError(SpeechRecognizer.ERROR_CLIENT, "start-failed");
        }
    }

    public void stop() {
        if (recognizer == null || !active) return;
        try {
            listener.onState("processing");
            recognizer.stopListening();
        } catch (Exception error) {
            destroyRecognizer();
            listener.onError(SpeechRecognizer.ERROR_CLIENT, "stop-failed");
        }
    }

    public void cancel() {
        cancelled = true;
        if (recognizer != null) {
            try {
                recognizer.cancel();
            } catch (Exception ignored) {
            }
        }
        destroyRecognizer();
        listener.onState("cancelled");
    }

    public void destroy() {
        cancelled = true;
        destroyRecognizer();
    }

    private void destroyRecognizer() {
        active = false;
        if (recognizer != null) {
            try {
                recognizer.destroy();
            } catch (Exception ignored) {
            }
            recognizer = null;
        }
    }

    private void fallbackToSystemRecognizer() {
        String retryLanguage = language;
        destroyRecognizer();
        activity.getWindow().getDecorView().post(() -> {
            if (cancelled) return;
            language = retryLanguage;
            listener.onState("fallback");
            startInternal(false, false);
        });
    }

    private static String normalizeLanguage(String tag) {
        if (tag == null || tag.isBlank()) return "en-CA";
        String lower = tag.toLowerCase(Locale.ROOT);
        if (lower.startsWith("fr")) return "fr-CA";
        if (lower.startsWith("en-us")) return "en-US";
        if (lower.startsWith("en-gb")) return "en-GB";
        return "en-CA";
    }

    private static String firstResult(Bundle results) {
        if (results == null) return "";
        ArrayList<String> candidates = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        return candidates == null || candidates.isEmpty() || candidates.get(0) == null
                ? ""
                : candidates.get(0).trim();
    }

    private static boolean isLanguageError(int code) {
        return code == SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED
                || code == SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE;
    }

    private static String errorKey(int code) {
        return switch (code) {
            case SpeechRecognizer.ERROR_AUDIO -> "audio";
            case SpeechRecognizer.ERROR_CLIENT -> "client";
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "permission";
            case SpeechRecognizer.ERROR_NETWORK -> "network";
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "network-timeout";
            case SpeechRecognizer.ERROR_NO_MATCH -> "no-match";
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "busy";
            case SpeechRecognizer.ERROR_SERVER -> "server";
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "no-speech";
            case SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED -> "language-not-supported";
            case SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE -> "language-unavailable";
            case SpeechRecognizer.ERROR_TOO_MANY_REQUESTS -> "too-many-requests";
            case SpeechRecognizer.ERROR_SERVER_DISCONNECTED -> "server-disconnected";
            default -> "unknown";
        };
    }

    @Override
    public void onReadyForSpeech(Bundle params) {
        listener.onState("ready");
    }

    @Override
    public void onBeginningOfSpeech() {
        listener.onState("listening");
    }

    @Override
    public void onRmsChanged(float rmsdB) {
        // The web UI intentionally avoids a continuously animated level meter.
    }

    @Override
    public void onBufferReceived(byte[] buffer) {
    }

    @Override
    public void onEndOfSpeech() {
        listener.onState("processing");
    }

    @Override
    public void onError(int error) {
        if (cancelled) return;
        if (usingOnDevice && allowNetworkFallback && isLanguageError(error)
                && SpeechRecognizer.isRecognitionAvailable(activity)) {
            fallbackToSystemRecognizer();
            return;
        }
        destroyRecognizer();
        listener.onError(error, errorKey(error));
    }

    @Override
    public void onResults(Bundle results) {
        String text = firstResult(results);
        destroyRecognizer();
        if (text.isBlank()) listener.onError(SpeechRecognizer.ERROR_NO_MATCH, "no-match");
        else listener.onResult(text);
    }

    @Override
    public void onPartialResults(Bundle partialResults) {
        String text = firstResult(partialResults);
        if (!text.isBlank()) listener.onPartial(text);
    }

    @Override
    public void onEvent(int eventType, Bundle params) {
    }
}
