package ca.otpocket.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class PendingActionStore {
    private static final String PREFS = "ot_native_actions";
    private static final String KEY = "queue";

    private PendingActionStore() {}

    public static synchronized void append(Context context, String action, String label, String reminderKey, long timestamp) {
        append(context, action, label, reminderKey, timestamp, "");
    }

    public static synchronized void append(Context context, String action, String label, String reminderKey, long timestamp, String text) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        JSONArray array;
        try {
            array = new JSONArray(prefs.getString(KEY, "[]"));
        } catch (JSONException ignored) {
            array = new JSONArray();
        }
        JSONObject item = new JSONObject();
        try {
            item.put("action", action);
            item.put("label", label == null ? "" : label);
            item.put("reminderKey", reminderKey == null ? "" : reminderKey);
            item.put("timestamp", timestamp);
            if (text != null && !text.isBlank()) item.put("text", text.trim());
            array.put(item);
        } catch (JSONException ignored) {
            return;
        }
        prefs.edit().putString(KEY, array.toString()).apply();
    }

    public static synchronized String consume(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String value = prefs.getString(KEY, "[]");
        prefs.edit().putString(KEY, "[]").apply();
        return value == null ? "[]" : value;
    }
}
