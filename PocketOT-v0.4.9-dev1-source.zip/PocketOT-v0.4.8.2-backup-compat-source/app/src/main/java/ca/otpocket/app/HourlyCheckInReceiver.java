package ca.otpocket.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public final class HourlyCheckInReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        HourlyCheckInScheduler.onAlarm(context);
    }
}
