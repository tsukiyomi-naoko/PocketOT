package ca.otpocket.app;

import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public final class ExportUtil {
    private ExportUtil() {}

    public static String saveBase64(Context context, String fileName, String mimeType, String encoded) throws Exception {
        String safeName = sanitize(fileName);
        String base64 = encoded;
        int comma = base64.indexOf(',');
        if (comma >= 0) base64 = base64.substring(comma + 1);
        byte[] bytes = Base64.decode(base64, Base64.DEFAULT);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
            values.put(MediaStore.Downloads.MIME_TYPE, mimeType == null ? "application/octet-stream" : mimeType);
            values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Pocket OT");
            values.put(MediaStore.Downloads.IS_PENDING, 1);
            Uri uri = context.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new IllegalStateException("Unable to create exported file.");
            try (OutputStream output = context.getContentResolver().openOutputStream(uri)) {
                if (output == null) throw new IllegalStateException("Unable to open exported file.");
                output.write(bytes);
            }
            values.clear();
            values.put(MediaStore.Downloads.IS_PENDING, 0);
            context.getContentResolver().update(uri, values, null, null);
            return uri.toString();
        }

        File directory = new File(context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "Pocket OT");
        if (!directory.exists() && !directory.mkdirs()) throw new IllegalStateException("Unable to create export folder.");
        File file = new File(directory, safeName);
        try (FileOutputStream output = new FileOutputStream(file)) {
            output.write(bytes);
        }
        return file.getAbsolutePath();
    }

    private static String sanitize(String name) {
        String value = name == null || name.isBlank() ? "ot-pocket-export" : name;
        return value.replaceAll("[^A-Za-z0-9._() -]", "_");
    }
}
