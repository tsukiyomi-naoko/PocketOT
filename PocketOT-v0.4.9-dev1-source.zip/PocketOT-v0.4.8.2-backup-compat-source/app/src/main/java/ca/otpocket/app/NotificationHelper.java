package ca.otpocket.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;

public final class NotificationHelper {
    public static final String CHANNEL_REMINDERS = "ot_reminders";
    public static final String CHANNEL_STATUS = "ot_status";
    public static final String EXTRA_NATIVE_ACTION = "native_action";
    public static final String EXTRA_KEY = "reminder_key";
    public static final String EXTRA_TITLE = "reminder_title";
    public static final String EXTRA_MESSAGE = "reminder_message";
    public static final String EXTRA_NOTIFICATION_ID = "notification_id";
    public static final String REMOTE_INPUT_TEXT = "quick_reply_text";
    public static final String ACTION_PHOTO = "photo";
    public static final String ACTION_TEXT = "text";
    public static final String ACTION_VOICE = "voice";
    public static final String ACTION_DONE = "done";
    public static final String ACTION_LATER = "later";
    private static final String QUICK_KEY = "quick-capture";
    public static final int QUICK_NOTIFICATION_ID = 71001;
    public static final int HOURLY_NOTIFICATION_ID = 71002;

    private NotificationHelper() {}

    public static void createChannels(Context context) {
        NotificationManager manager = context.getSystemService(NotificationManager.class);
        NotificationChannel reminders = new NotificationChannel(
                CHANNEL_REMINDERS,
                context.getString(R.string.notification_channel_reminders),
                NotificationManager.IMPORTANCE_HIGH
        );
        reminders.setDescription(context.getString(R.string.notification_channel_reminders_description));
        reminders.enableVibration(true);
        reminders.setLightColor(Color.rgb(46, 102, 87));

        NotificationChannel status = new NotificationChannel(
                CHANNEL_STATUS,
                context.getString(R.string.notification_channel_status),
                NotificationManager.IMPORTANCE_LOW
        );
        manager.createNotificationChannel(reminders);
        manager.createNotificationChannel(status);
    }

    public static void showReminder(Context context, String key, String title, String message) {
        showRoutineReminder(context, ReminderScheduler.stableId(key), key, title, message, false);
    }

    public static void showQuickCapture(Context context) {
        showCaptureNotification(
                context,
                QUICK_NOTIFICATION_ID,
                QUICK_KEY,
                AppLanguage.text(context, "Quick record", "Saisie rapide"),
                AppLanguage.text(context,
                        "Photo, text, or voice without searching for the app.",
                        "Photo, texte ou voix sans devoir chercher l’application."),
                true
        );
    }

    public static void showHourlyCheckIn(Context context) {
        showCaptureNotification(
                context,
                HOURLY_NOTIFICATION_ID,
                HourlyCheckInScheduler.REMINDER_KEY,
                AppLanguage.text(context, "What are you doing?", "Que faites-vous?"),
                AppLanguage.text(context,
                        "Record this hour with a photo, text, or voice note.",
                        "Consignez cette heure avec une photo, du texte ou une note vocale."),
                false
        );
    }

    public static void hideQuickCapture(Context context) {
        context.getSystemService(NotificationManager.class).cancel(QUICK_NOTIFICATION_ID);
    }

    private static void showRoutineReminder(Context context, int id, String key, String title, String message, boolean ongoing) {
        createChannels(context);

        Notification.Builder builder = baseBuilder(context, id, key, title, message, ongoing)
                .addAction(new Notification.Action.Builder(
                        R.drawable.ic_photo,
                        AppLanguage.text(context, "Photo", "Photo"),
                        activityAction(context, key, ACTION_PHOTO, title, id, 2)).build())
                .addAction(textReplyAction(context, key, title, message, id, 3))
                .addAction(new Notification.Action.Builder(
                        R.drawable.ic_voice,
                        AppLanguage.text(context, "Voice", "Voix"),
                        activityAction(context, key, ACTION_VOICE, title, id, 4)).build())
                .addAction(new Notification.Action.Builder(
                        R.drawable.ic_done,
                        AppLanguage.text(context, "Done", "Fait"),
                        broadcastAction(context, key, ACTION_DONE, title, message, id, 5, false)).build())
                .addAction(new Notification.Action.Builder(
                        R.drawable.ic_later,
                        AppLanguage.text(context, "Later", "Plus tard"),
                        broadcastAction(context, key, ACTION_LATER, title, message, id, 6, false)).build());

        context.getSystemService(NotificationManager.class).notify(id, builder.build());
    }

    private static void showCaptureNotification(Context context, int id, String key, String title, String message, boolean ongoing) {
        createChannels(context);

        Notification.Builder builder = baseBuilder(context, id, key, title, message, ongoing)
                // Android normally surfaces the first three actions most prominently.
                .addAction(new Notification.Action.Builder(
                        R.drawable.ic_photo,
                        AppLanguage.text(context, "Photo", "Photo"),
                        activityAction(context, key, ACTION_PHOTO, title, id, 2)).build())
                .addAction(textReplyAction(context, key, title, message, id, 3))
                .addAction(new Notification.Action.Builder(
                        R.drawable.ic_voice,
                        AppLanguage.text(context, "Voice", "Voix"),
                        activityAction(context, key, ACTION_VOICE, title, id, 4)).build())
                .addAction(new Notification.Action.Builder(
                        R.drawable.ic_later,
                        AppLanguage.text(context, "Later", "Plus tard"),
                        broadcastAction(context, key, ACTION_LATER, title, message, id, 5, false)).build());

        context.getSystemService(NotificationManager.class).notify(id, builder.build());
    }

    private static Notification.Builder baseBuilder(Context context, int id, String key, String title, String message, boolean ongoing) {
        PendingIntent open = activityAction(context, key, "open", title, id, 1);
        return new Notification.Builder(context, CHANNEL_REMINDERS)
                .setSmallIcon(R.drawable.ic_notification)
                .setColor(context.getColor(R.color.ot_primary))
                .setContentTitle(title)
                .setContentText(message)
                .setStyle(new Notification.BigTextStyle().bigText(message))
                .setContentIntent(open)
                .setAutoCancel(!ongoing)
                .setOngoing(ongoing)
                .setCategory(Notification.CATEGORY_REMINDER)
                .setVisibility(Notification.VISIBILITY_PRIVATE)
                .setOnlyAlertOnce(ongoing);
    }

    private static Notification.Action textReplyAction(
            Context context,
            String key,
            String title,
            String message,
            int notificationId,
            int salt
    ) {
        RemoteInput input = new RemoteInput.Builder(REMOTE_INPUT_TEXT)
                .setLabel(AppLanguage.text(context, "What are you doing?", "Que faites-vous?"))
                .build();
        PendingIntent pendingIntent = broadcastAction(
                context, key, ACTION_TEXT, title, message, notificationId, salt, true);
        return new Notification.Action.Builder(
                R.drawable.ic_text,
                AppLanguage.text(context, "Text", "Texte"),
                pendingIntent)
                .addRemoteInput(input)
                .setAllowGeneratedReplies(true)
                .build();
    }

    public static void showSaved(Context context, String message) {
        createChannels(context);
        Notification notification = new Notification.Builder(context, CHANNEL_STATUS)
                .setSmallIcon(R.drawable.ic_done)
                .setColor(context.getColor(R.color.ot_primary))
                .setContentTitle("Pocket OT")
                .setContentText(message)
                .setAutoCancel(true)
                .setTimeoutAfter(5000L)
                .build();
        context.getSystemService(NotificationManager.class)
                .notify((int) (System.currentTimeMillis() & 0x7FFFFFFF), notification);
    }

    private static PendingIntent activityAction(Context context, String key, String action, String title, int notificationId, int salt) {
        Intent intent = new Intent(context, MainActivity.class)
                .setAction("ca.otpocket.app.OPEN." + action + "." + key)
                .putExtra(EXTRA_NATIVE_ACTION, action)
                .putExtra(EXTRA_KEY, key)
                .putExtra(EXTRA_TITLE, title)
                .putExtra(EXTRA_NOTIFICATION_ID, notificationId)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(
                context,
                ReminderScheduler.stableId(key + ":" + salt),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
    }

    private static PendingIntent broadcastAction(
            Context context,
            String key,
            String action,
            String title,
            String message,
            int id,
            int salt,
            boolean mutable
    ) {
        Intent intent = new Intent(context, NotificationActionReceiver.class)
                .setAction("ca.otpocket.app.ACTION." + action + "." + key)
                .putExtra(EXTRA_NATIVE_ACTION, action)
                .putExtra(EXTRA_KEY, key)
                .putExtra(EXTRA_TITLE, title)
                .putExtra(EXTRA_MESSAGE, message)
                .putExtra(EXTRA_NOTIFICATION_ID, id);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT
                | (mutable ? PendingIntent.FLAG_MUTABLE : PendingIntent.FLAG_IMMUTABLE);
        return PendingIntent.getBroadcast(
                context,
                ReminderScheduler.stableId(key + ":" + salt),
                intent,
                flags
        );
    }
}
