package ca.otpocket.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONException;
import org.json.JSONObject;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

/** Schedules one user-facing activity check-in at a time and reschedules after delivery. */
public final class HourlyCheckInScheduler {
    public static final String ACTION_HOURLY_CHECK_IN = "ca.otpocket.app.HOURLY_CHECK_IN";
    public static final String REMINDER_KEY = "hourly-activity-check-in";

    private static final String PREFS = "ot_hourly_checkins";
    private static final String KEY_ENABLED = "enabled";
    private static final String KEY_INTERVAL = "interval_minutes";
    private static final String KEY_START = "active_start";
    private static final String KEY_END = "active_end";
    private static final String KEY_SKIP_RECENT = "skip_recent";
    private static final String KEY_RECENT_MINUTES = "recent_minutes";
    private static final String KEY_LAST_ACTIVITY = "last_activity_at";
    private static final String KEY_NEXT_TRIGGER = "next_trigger";

    private static final int REQUEST_CODE = 73510;
    private static final DateTimeFormatter TIME_FORMAT = DateTimeFormatter.ofPattern("HH:mm");

    private HourlyCheckInScheduler() {}

    public static void configure(
            Context context,
            boolean enabled,
            int intervalMinutes,
            String activeStart,
            String activeEnd,
            boolean skipRecent,
            int recentMinutes
    ) {
        SharedPreferences prefs = prefs(context);
        prefs.edit()
                .putBoolean(KEY_ENABLED, enabled)
                .putInt(KEY_INTERVAL, clamp(intervalMinutes, 15, 720))
                .putString(KEY_START, normalizeTime(activeStart, "06:00"))
                .putString(KEY_END, normalizeTime(activeEnd, "03:00"))
                .putBoolean(KEY_SKIP_RECENT, skipRecent)
                .putInt(KEY_RECENT_MINUTES, clamp(recentMinutes, 5, 720))
                .apply();

        if (enabled) scheduleNext(context, System.currentTimeMillis());
        else cancel(context);
    }

    public static void restore(Context context) {
        if (isEnabled(context)) scheduleNext(context, System.currentTimeMillis());
        else cancelAlarmOnly(context);
    }

    public static void onAlarm(Context context) {
        if (!isEnabled(context)) {
            cancelAlarmOnly(context);
            return;
        }

        long now = System.currentTimeMillis();
        if (!shouldSkipBecauseRecent(context, now)) {
            NotificationHelper.showHourlyCheckIn(context);
        }
        scheduleNext(context, now + 1_000L);
    }

    public static void showNow(Context context) {
        NotificationHelper.showHourlyCheckIn(context);
    }

    public static void markActivityRecorded(Context context, long timestamp) {
        prefs(context).edit().putLong(KEY_LAST_ACTIVITY, Math.max(0L, timestamp)).apply();
    }

    public static boolean isEnabled(Context context) {
        return prefs(context).getBoolean(KEY_ENABLED, false);
    }

    public static void cancel(Context context) {
        cancelAlarmOnly(context);
        prefs(context).edit().putBoolean(KEY_ENABLED, false).remove(KEY_NEXT_TRIGGER).apply();
        context.getSystemService(android.app.NotificationManager.class)
                .cancel(NotificationHelper.HOURLY_NOTIFICATION_ID);
    }

    public static String statusJson(Context context) {
        SharedPreferences prefs = prefs(context);
        JSONObject object = new JSONObject();
        try {
            object.put("enabled", prefs.getBoolean(KEY_ENABLED, false));
            object.put("intervalMinutes", prefs.getInt(KEY_INTERVAL, 60));
            object.put("activeStart", prefs.getString(KEY_START, "06:00"));
            object.put("activeEnd", prefs.getString(KEY_END, "03:00"));
            object.put("skipRecent", prefs.getBoolean(KEY_SKIP_RECENT, true));
            object.put("recentMinutes", prefs.getInt(KEY_RECENT_MINUTES, 50));
            object.put("lastActivityAt", prefs.getLong(KEY_LAST_ACTIVITY, 0L));
            object.put("nextTriggerAt", prefs.getLong(KEY_NEXT_TRIGGER, 0L));
            object.put("exact", ReminderScheduler.canScheduleExact(context));
        } catch (JSONException ignored) {
        }
        return object.toString();
    }

    private static void scheduleNext(Context context, long afterMillis) {
        SharedPreferences prefs = prefs(context);
        if (!prefs.getBoolean(KEY_ENABLED, false)) return;

        int interval = prefs.getInt(KEY_INTERVAL, 60);
        String start = prefs.getString(KEY_START, "06:00");
        String end = prefs.getString(KEY_END, "03:00");
        long trigger = nextTriggerAfter(afterMillis, interval, start, end);

        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pendingIntent = pendingIntent(context);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarmManager.canScheduleExactAlarms()) {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pendingIntent);
        } else {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pendingIntent);
        }
        prefs.edit().putLong(KEY_NEXT_TRIGGER, trigger).apply();
    }

    private static long nextTriggerAfter(long afterMillis, int intervalMinutes, String startValue, String endValue) {
        ZoneId zone = ZoneId.systemDefault();
        ZonedDateTime after = Instant.ofEpochMilli(afterMillis).atZone(zone);
        LocalTime startTime = parseTime(startValue, LocalTime.of(6, 0));
        LocalTime endTime = parseTime(endValue, LocalTime.of(3, 0));
        int interval = clamp(intervalMinutes, 15, 720);

        ZonedDateTime best = null;
        LocalDate base = after.toLocalDate();
        for (int offset = -1; offset <= 3; offset++) {
            LocalDate date = base.plusDays(offset);
            ZonedDateTime windowStart = ZonedDateTime.of(LocalDateTime.of(date, startTime), zone);
            ZonedDateTime windowEnd = ZonedDateTime.of(LocalDateTime.of(date, endTime), zone);
            if (!endTime.isAfter(startTime)) windowEnd = windowEnd.plusDays(1);

            ZonedDateTime slot = windowStart;
            while (slot.isBefore(windowEnd)) {
                if (slot.isAfter(after) && (best == null || slot.isBefore(best))) best = slot;
                if (best != null && !slot.isBefore(best)) break;
                slot = slot.plusMinutes(interval);
            }
        }

        if (best == null) {
            best = ZonedDateTime.of(LocalDateTime.of(base.plusDays(1), startTime), zone);
            if (!best.isAfter(after)) best = best.plusDays(1);
        }
        return best.toInstant().toEpochMilli();
    }

    private static boolean shouldSkipBecauseRecent(Context context, long now) {
        SharedPreferences prefs = prefs(context);
        if (!prefs.getBoolean(KEY_SKIP_RECENT, true)) return false;
        long last = prefs.getLong(KEY_LAST_ACTIVITY, 0L);
        long threshold = prefs.getInt(KEY_RECENT_MINUTES, 50) * 60_000L;
        return last > 0 && now >= last && now - last < threshold;
    }

    private static PendingIntent pendingIntent(Context context) {
        Intent intent = new Intent(context, HourlyCheckInReceiver.class)
                .setAction(ACTION_HOURLY_CHECK_IN);
        return PendingIntent.getBroadcast(
                context,
                REQUEST_CODE,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
    }

    private static void cancelAlarmOnly(Context context) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        alarmManager.cancel(pendingIntent(context));
    }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private static String normalizeTime(String value, String fallback) {
        try {
            return LocalTime.parse(value, TIME_FORMAT).format(TIME_FORMAT);
        } catch (DateTimeParseException | NullPointerException ignored) {
            return fallback;
        }
    }

    private static LocalTime parseTime(String value, LocalTime fallback) {
        try {
            return LocalTime.parse(value, TIME_FORMAT);
        } catch (DateTimeParseException | NullPointerException ignored) {
            return fallback;
        }
    }
}
