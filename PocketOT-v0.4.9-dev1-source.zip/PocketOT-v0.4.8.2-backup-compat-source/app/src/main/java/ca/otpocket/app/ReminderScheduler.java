package ca.otpocket.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Map;

public final class ReminderScheduler {
    private static final String PREFS = "ot_reminders";
    private static final String PREFIX = "reminder:";

    private ReminderScheduler() {}

    public static void schedule(Context context, String key, String title, String message, long triggerAtMillis, boolean persist) {
        long trigger = Math.max(triggerAtMillis, System.currentTimeMillis() + 1000L);
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pendingIntent = reminderPendingIntent(context, key, title, message);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarmManager.canScheduleExactAlarms()) {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pendingIntent);
        } else {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pendingIntent);
        }

        if (persist) save(context, key, title, message, trigger);
    }

    public static void cancel(Context context, String key) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        alarmManager.cancel(reminderPendingIntent(context, key, "", ""));
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(PREFIX + key).apply();
    }

    public static void restoreAll(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        long now = System.currentTimeMillis();
        for (Map.Entry<String, ?> entry : prefs.getAll().entrySet()) {
            if (!entry.getKey().startsWith(PREFIX) || !(entry.getValue() instanceof String)) continue;
            try {
                JSONObject value = new JSONObject((String) entry.getValue());
                String key = value.getString("key");
                String title = value.optString("title", "Pocket OT reminder");
                String message = value.optString("message", "What were you doing?");
                long trigger = value.getLong("trigger");
                if (trigger > now) schedule(context, key, title, message, trigger, false);
                else prefs.edit().remove(entry.getKey()).apply();
            } catch (JSONException ignored) {
                prefs.edit().remove(entry.getKey()).apply();
            }
        }
    }

    public static boolean canScheduleExact(Context context) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.S || alarmManager.canScheduleExactAlarms();
    }

    private static PendingIntent reminderPendingIntent(Context context, String key, String title, String message) {
        Intent intent = new Intent(context, ReminderReceiver.class)
                .setAction("ca.otpocket.app.REMINDER." + key)
                .putExtra(NotificationHelper.EXTRA_KEY, key)
                .putExtra(NotificationHelper.EXTRA_TITLE, title)
                .putExtra(NotificationHelper.EXTRA_MESSAGE, message);
        return PendingIntent.getBroadcast(
                context,
                stableId(key),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
    }

    private static void save(Context context, String key, String title, String message, long trigger) {
        JSONObject value = new JSONObject();
        try {
            value.put("key", key);
            value.put("title", title);
            value.put("message", message);
            value.put("trigger", trigger);
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    .edit()
                    .putString(PREFIX + key, value.toString())
                    .apply();
        } catch (JSONException ignored) {
        }
    }

    public static int stableId(String value) {
        int hash = value == null ? 1 : value.hashCode();
        if (hash == Integer.MIN_VALUE) hash = 1;
        return Math.abs(hash);
    }
}
