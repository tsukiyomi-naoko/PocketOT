package ca.otpocket.app;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

public final class NativeBridge {
    private final MainActivity activity;
    private final NativeStorage storage;
    private final PhotoArchive photoArchive;

    NativeBridge(MainActivity activity, PhotoArchive photoArchive) {
        this.activity = activity;
        this.storage = new NativeStorage(activity);
        this.photoArchive = photoArchive;
    }

    @JavascriptInterface
    public boolean isNative() {
        return true;
    }

    @JavascriptInterface
    public String getVersion() {
        return "0.4.8.2-dev";
    }


    @JavascriptInterface
    public String loadStateJson() {
        try {
            return storage.loadStateJson();
        } catch (Exception error) {
            return "";
        }
    }

    @JavascriptInterface
    public boolean saveStateJson(String json) {
        try {
            return storage.saveStateJson(json);
        } catch (Exception error) {
            return false;
        }
    }

    @JavascriptInterface
    public String storePhotoDataUrl(String photoId, String dataUrl) {
        try {
            return photoArchive.saveDataUrl(photoId, dataUrl);
        } catch (Exception error) {
            return "";
        }
    }

    @JavascriptInterface
    public boolean deleteArchivedPhoto(String reference) {
        return photoArchive.delete(reference);
    }

    @JavascriptInterface
    public void clearPhotoArchive() {
        photoArchive.clear();
    }

    @JavascriptInterface
    public String getPhotoArchiveStats() {
        return photoArchive.statsJson();
    }

    @JavascriptInterface
    public String getDeviceLanguage() {
        return AppLanguage.deviceLanguage();
    }

    @JavascriptInterface
    public String getPreferredLanguage() {
        return AppLanguage.get(activity);
    }

    @JavascriptInterface
    public void setPreferredLanguage(String language) {
        activity.runOnUiThread(() -> AppLanguage.set(activity, language));
    }

    @JavascriptInterface
    public void requestNotificationPermission() {
        activity.runOnUiThread(() -> {
            NotificationHelper.createChannels(activity);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                    && activity.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                activity.requestPermissions(
                        new String[]{Manifest.permission.POST_NOTIFICATIONS},
                        MainActivity.REQUEST_NOTIFICATIONS);
            } else {
                Toast.makeText(
                        activity,
                        AppLanguage.text(activity,
                                "Notifications are enabled.",
                                "Les notifications sont activées."),
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    @JavascriptInterface
    public boolean isVoiceRecognitionAvailable() {
        return activity.isVoiceRecognitionAvailable();
    }

    @JavascriptInterface
    public void startVoiceRecognition(String language) {
        activity.startVoiceRecognition(language);
    }

    @JavascriptInterface
    public void stopVoiceRecognition() {
        activity.stopVoiceRecognition();
    }

    @JavascriptInterface
    public void cancelVoiceRecognition() {
        activity.cancelVoiceRecognition();
    }

    @JavascriptInterface
    public void showQuickCaptureNotification() {
        activity.runOnUiThread(() -> NotificationHelper.showQuickCapture(activity));
    }

    @JavascriptInterface
    public void hideQuickCaptureNotification() {
        activity.runOnUiThread(() -> NotificationHelper.hideQuickCapture(activity));
    }

    @JavascriptInterface
    public void configureHourlyCheckIns(
            boolean enabled,
            int intervalMinutes,
            String activeStart,
            String activeEnd,
            boolean skipRecent,
            int recentMinutes
    ) {
        HourlyCheckInScheduler.configure(
                activity,
                enabled,
                intervalMinutes,
                activeStart,
                activeEnd,
                skipRecent,
                recentMinutes);
    }

    @JavascriptInterface
    public String getHourlyCheckInStatus() {
        return HourlyCheckInScheduler.statusJson(activity);
    }

    @JavascriptInterface
    public void showHourlyCheckInNow() {
        activity.runOnUiThread(() -> HourlyCheckInScheduler.showNow(activity));
    }

    @JavascriptInterface
    public void markActivityRecorded(long timestamp) {
        HourlyCheckInScheduler.markActivityRecorded(activity, timestamp);
    }

    @JavascriptInterface
    public void scheduleReminder(
            String key,
            String title,
            String message,
            long triggerAtMillis
    ) {
        ReminderScheduler.schedule(
                activity, key, title, message, triggerAtMillis, true);
    }

    @JavascriptInterface
    public void scheduleTestReminder(int seconds) {
        long trigger = System.currentTimeMillis() + Math.max(5, seconds) * 1000L;
        ReminderScheduler.schedule(
                activity,
                "test-reminder",
                AppLanguage.text(activity,
                        "What are you doing?",
                        "Que faites-vous?"),
                AppLanguage.text(activity,
                        "No entry was made recently. Add a photo, text, or voice note.",
                        "Aucune entrée récente. Ajoutez une photo, du texte ou une note vocale."),
                trigger,
                true
        );
    }

    @JavascriptInterface
    public void cancelReminder(String key) {
        ReminderScheduler.cancel(activity, key);
    }

    @JavascriptInterface
    public boolean canScheduleExactAlarms() {
        return ReminderScheduler.canScheduleExact(activity);
    }

    @JavascriptInterface
    public void openExactAlarmSettings() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return;
        activity.runOnUiThread(() -> {
            Intent intent = new Intent(
                    Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                    Uri.parse("package:" + activity.getPackageName()));
            activity.startActivity(intent);
        });
    }

    @JavascriptInterface
    public String consumePendingActions() {
        return PendingActionStore.consume(activity);
    }

    @JavascriptInterface
    public void printCurrentReport(String jobName) {
        activity.printCurrentReport(jobName);
    }

    @JavascriptInterface
    public String exportFullBackup(String fileName, String stateJson) {
        try {
            String result = BackupUtil.exportFullBackup(activity, fileName, stateJson);
            activity.runOnUiThread(() -> Toast.makeText(
                    activity,
                    AppLanguage.text(activity,
                            "Full backup saved to Downloads/Pocket OT",
                            "Sauvegarde complète enregistrée dans Téléchargements/Pocket OT"),
                    Toast.LENGTH_LONG).show());
            return result;
        } catch (Exception error) {
            activity.runOnUiThread(() -> Toast.makeText(
                    activity,
                    AppLanguage.text(activity,
                            "Backup failed: ",
                            "Échec de la sauvegarde : ") + error.getMessage(),
                    Toast.LENGTH_LONG).show());
            return "";
        }
    }

    @JavascriptInterface
    public String saveBase64File(String fileName, String mimeType, String data) {
        try {
            String result = ExportUtil.saveBase64(
                    activity, fileName, mimeType, data);
            activity.runOnUiThread(() -> Toast.makeText(
                    activity,
                    AppLanguage.text(activity,
                            "Saved to Downloads/Pocket OT",
                            "Enregistré dans Téléchargements/Pocket OT"),
                    Toast.LENGTH_LONG).show());
            return result;
        } catch (Exception error) {
            activity.runOnUiThread(() -> Toast.makeText(
                    activity,
                    AppLanguage.text(activity,
                            "Export failed: ",
                            "Échec de l’exportation : ") + error.getMessage(),
                    Toast.LENGTH_LONG).show());
            return "";
        }
    }
}
