package ca.otpocket.app;

import android.app.LocaleManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.LocaleList;

import java.util.Locale;

public final class AppLanguage {
    private static final String PREFS = "ot_pocket_language";
    private static final String KEY_LANGUAGE = "language";

    private AppLanguage() {}

    public static String normalize(String tag) {
        if (tag != null && tag.toLowerCase(Locale.ROOT).startsWith("fr")) return "fr-CA";
        return "en";
    }

    public static String deviceLanguage() {
        Locale locale = Locale.getDefault();
        return normalize(locale == null ? "en" : locale.toLanguageTag());
    }

    public static String get(Context context) {
        SharedPreferences preferences = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        return normalize(preferences.getString(KEY_LANGUAGE, deviceLanguage()));
    }

    public static void set(Context context, String language) {
        String normalized = normalize(language);
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_LANGUAGE, normalized)
                .apply();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            LocaleManager manager = context.getSystemService(LocaleManager.class);
            if (manager != null) manager.setApplicationLocales(LocaleList.forLanguageTags(normalized));
        }
    }

    public static boolean isFrench(Context context) {
        return "fr-CA".equals(get(context));
    }

    public static String text(Context context, String english, String french) {
        return isFrench(context) ? french : english;
    }
}
