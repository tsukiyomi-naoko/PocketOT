package ca.otpocket.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public final class ReminderReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String key = intent.getStringExtra(NotificationHelper.EXTRA_KEY);
        String title = intent.getStringExtra(NotificationHelper.EXTRA_TITLE);
        String message = intent.getStringExtra(NotificationHelper.EXTRA_MESSAGE);
        if (key == null) key = "reminder-" + System.currentTimeMillis();
        if (title == null || title.isBlank()) title = AppLanguage.text(context, "Pocket OT reminder", "Rappel Pocket OT");
        if (message == null || message.isBlank()) message = AppLanguage.text(context, "What were you doing?", "Que faisiez-vous?");
        NotificationHelper.showReminder(context, key, title, message);
    }
}
