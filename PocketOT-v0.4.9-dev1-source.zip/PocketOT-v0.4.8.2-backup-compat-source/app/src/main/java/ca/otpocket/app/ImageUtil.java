package ca.otpocket.app;

import android.content.ContentResolver;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.net.Uri;
import android.util.Base64;

import androidx.exifinterface.media.ExifInterface;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

public final class ImageUtil {
    private static final int MAX_DIMENSION = 1280;

    private ImageUtil() {}

    public static String toCompressedDataUrl(Context context, Uri uri) throws IOException {
        ContentResolver resolver = context.getContentResolver();
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        try (InputStream input = resolver.openInputStream(uri)) {
            BitmapFactory.decodeStream(input, null, bounds);
        }

        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = calculateSampleSize(bounds.outWidth, bounds.outHeight, MAX_DIMENSION);
        Bitmap bitmap;
        try (InputStream input = resolver.openInputStream(uri)) {
            bitmap = BitmapFactory.decodeStream(input, null, options);
        }
        if (bitmap == null) throw new IOException("Unable to decode captured image.");

        int orientation = ExifInterface.ORIENTATION_NORMAL;
        try (InputStream input = resolver.openInputStream(uri)) {
            if (input != null) {
                ExifInterface exif = new ExifInterface(input);
                orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
            }
        } catch (Exception ignored) {
        }

        Bitmap oriented = applyOrientation(bitmap, orientation);
        Bitmap scaled = scaleDown(oriented, MAX_DIMENSION);
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        scaled.compress(Bitmap.CompressFormat.JPEG, 78, output);
        String encoded = Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP);

        if (scaled != oriented) scaled.recycle();
        if (oriented != bitmap) oriented.recycle();
        bitmap.recycle();
        return "data:image/jpeg;base64," + encoded;
    }

    private static int calculateSampleSize(int width, int height, int max) {
        int sample = 1;
        while (width / sample > max * 2 || height / sample > max * 2) sample *= 2;
        return sample;
    }

    private static Bitmap scaleDown(Bitmap bitmap, int max) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        float factor = Math.min(1f, (float) max / Math.max(width, height));
        if (factor >= 1f) return bitmap;
        return Bitmap.createScaledBitmap(bitmap, Math.round(width * factor), Math.round(height * factor), true);
    }

    private static Bitmap applyOrientation(Bitmap bitmap, int orientation) {
        Matrix matrix = new Matrix();
        switch (orientation) {
            case ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f);
            case ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f);
            case ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f);
            case ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.preScale(-1f, 1f);
            case ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.preScale(1f, -1f);
            case ExifInterface.ORIENTATION_TRANSPOSE -> {
                matrix.preScale(-1f, 1f);
                matrix.postRotate(270f);
            }
            case ExifInterface.ORIENTATION_TRANSVERSE -> {
                matrix.preScale(-1f, 1f);
                matrix.postRotate(90f);
            }
            default -> {
                return bitmap;
            }
        }
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
    }
}
