-keepclassmembers class ca.otpocket.app.NativeBridge {
    @android.webkit.JavascriptInterface <methods>;
}
