# Native feature behavior

## Reminder notification

Reminder notifications offer four actions:

- **Photo** opens the camera immediately. The result is timestamped and enters the same photo context inbox and report evidence pipeline as an in-app capture.
- **Text** opens OT Pocket directly into the quick-text entry form.
- **Done** records a durable native pending action even when the app is not open. It is merged into the timeline on the next launch.
- **Later** reschedules the reminder for 30 minutes later.

## Reliability

Reminders are stored in Android SharedPreferences and restored by a boot/package-replaced receiver. Android's exact-alarm access is used when permitted; otherwise the app falls back to an idle-compatible inexact alarm rather than losing the reminder.

## Exports

On Android 10 and newer, exports are written through MediaStore to `Downloads/OT Pocket`. No broad storage permission is requested.

## Data

The current UI data remains in private WebView local storage. This is appropriate for interface development and local testing, but the clinical production version must migrate records and media to an encrypted relational store with explicit provenance and audit history.


## Native archive storage (v0.4.8)

Android state is persisted through SQLite and photo bytes are stored as private files under the application sandbox. The WebView receives only lightweight internal photo references. Legacy v0.4.7 Base64 records are migrated transactionally on first launch.
